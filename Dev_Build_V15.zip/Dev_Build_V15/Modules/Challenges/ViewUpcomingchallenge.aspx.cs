﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OracleClient;
using OraAppBlock;
using System.Configuration;
using System.Text.RegularExpressions;

public partial class ViewUpcomingchallenge : System.Web.UI.Page
{
    //Start - 23th Oct 2017 - Bhakti
    BusinessLayer.IRIS_BusinessLayer objClass1_BL = new BusinessLayer.IRIS_BusinessLayer();
    //End - 23th Oct 2017 - Bhakti
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserId"] == null || Convert.ToString(Session["UserId"]) == "")
        {
            Response.Redirect("~/Login.aspx?r=" + CommonFunctions.GetRandomNumber(), false);
        }
        if (!IsPostBack)
        {
            getRoles();
        }
        //if (!IsPostBack)
        //{
        //    FillGrid();
        //}
    }

    public void getRoles()
    {
        string UserId = "";
        string Admin = "";
        if (Session["UserId"] == null || Convert.ToString(Session["UserId"]) == "")
        {
            Response.Redirect("~/Login.aspx?r=" + CommonFunctions.GetRandomNumber(), false);
        }
        else
        {
            UserId = Session["UserId"].ToString();
        }

        if (CommonFunctions.isSuperAdmin1(Session["UserId"].ToString()))
        {
            Admin = Session["UserId"].ToString();
        }

       
    }
    public void AddDynamicDivs()
    {
        try
        {
            
            string status = "U";
            DataSet ds = objClass1_BL.IRIS_GET_CHALLENGE_DASHBOARD(status);            
            if (ds.Tables.Count > 0)
            {
                if (ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        string challengeName = string.Empty;
                        string challengeImage = string.Empty;

                        challengeName = Regex.Replace(row["CHALLENGE_TITLE"].ToString(), "<.*?>", string.Empty);
                        if (challengeName.Length < 200)
                        {
                            //challengeName = challengeName.PadRight(200 - challengeName.Length);
                            // challengeName=challengeName+new string(' ', 200 - challengeName.Length);
                            challengeName = challengeName + new string(' ', 1);
                            int i = 200 - challengeName.Length;
                            while (i > 0)
                            {
                                //challengeName = challengeName + "&nbsp;";
                                challengeName = challengeName + "";
                                i--;
                            }
                        }
                        if (!string.IsNullOrEmpty(row["CHALLENGE_IMAGE"].ToString()))
                        {
                            challengeImage = row["CHALLENGE_IMAGE"].ToString();
                        }
                        else
                        {
                            challengeImage = "IRIS_Innovation_1.png";
                        }
                        Response.Write("<div style='margin:10px 0px 0px 10px; text-align:center; width:24%; display:inline-block; vertical-align: top; overflow-wrap: break-word; word-wrap:break-word;' class='challenge-card'>");
                        Response.Write("<a href='../../modules/challenges/PostChallengeNew.aspx?ChlId=" + row["CHALLENGE_ID"].ToString() + "'>");
                        //Response.Write("<div style='height:264px;'>");
                        Response.Write("<img style='width:120px;'  src='../../images/icons/" + challengeImage + "'/><br />");
                        Response.Write("<span style='color:var(--McCain-Grey, #3B393D);text-align: justify;font-size: 24px;font-style: normal;font-weight: 900;line-height: normal;'>" + challengeName + "</span><br />");
                        //Response.Write("<span style='color:var(--McCain-Grey, #3B393D);text-align: justify;font-size: 12px;font-style: normal;font-weight: 900;line-height: normal;'>Subtitles lorem ipsem  lorem ipsem</span><br />");
                        Response.Write("<div style='position: relative;width: 12vh;border-radius: 0.5vh;justify-content: center;align-items: center;background: var(--Primary-60, #9c27b0);'><a style='color:#FFF;' href='../../modules/challenges/PostChallengeNew.aspx?ChlId=" + row["CHALLENGE_ID"].ToString() + "'>Upcoming");
                        Response.Write("</a></div>");
                        Response.Write("</a>");
                        Response.Write("</div>");
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Session["Error"] = ex.ToString();
            Response.Redirect("~/ErrorPage.aspx");
        }
    }


    //public void AddDynamicDivs()
    //{
    //    try
    //    {
    //        string[] paramArray = new string[3];
    //        paramArray[0] = Session["UserId"].ToString();
    //        if (CommonFunctions.isSuperAdmin1(Session["UserId"].ToString()))
    //        {
    //            paramArray[1] = "Y";
    //        }
    //        else
    //        {
    //            paramArray[1] = "N";
    //        }

    //        if (!string.IsNullOrEmpty(Convert.ToString(Session["User_Type"])))
    //            paramArray[2] = Session["User_Type"].ToString();
    //        else
    //            paramArray[2] = "";
    //        //DataSet ds = objClass1_BL.getUpcomingChallenges(paramArray);//mccain
    //        DataSet ds = objClass1_BL.getUpcomingChallenges1(paramArray);
    //        if (ds.Tables.Count > 0)
    //        {
    //            if (ds.Tables[0].Rows.Count > 0)
    //            {
    //                foreach (DataRow row in ds.Tables[0].Rows)
    //                {
    //                    string challengeName = string.Empty;
    //                    string challengeImage = string.Empty;

    //                    challengeName = Regex.Replace(row["CHALLENGE_TITLE"].ToString(), "<.*?>", string.Empty);
    //                    if (!string.IsNullOrEmpty(row["CHALLENGE_IMAGE"].ToString()))
    //                    {
    //                        challengeImage = row["CHALLENGE_IMAGE"].ToString();
    //                    }
    //                    else
    //                    {
    //                        challengeImage = "IRIS_Innovation_1.png";
    //                    }
    //                    Response.Write("<div style='margin:10px 0px 0px 10px; text-align:center; width:24%; display:inline-block; vertical-align: top; padding:0% 0% 1% 0%; overflow-wrap: break-word; word-wrap:break-word;' class='challenge-card'>");
    //                    Response.Write("<a href='../../modules/challenges/PostChallengeNew.aspx?ChlId=" + row["CHALLENGE_ID"].ToString() + "'>");
    //                    Response.Write("<img style='width:120px;'  src='../../images/icons/" + challengeImage + "'/><br />");
    //                    Response.Write("<span style='color:var(--McCain-Grey, #3B393D);text-align: justify;font-size: 24px;font-style: normal;font-weight: 900;line-height: normal;'>" + challengeName + "</span><br />");
    //                    Response.Write("<span style='color:var(--McCain-Grey, #3B393D);text-align: justify;font-size: 12px;font-style: normal;font-weight: 900;line-height: normal;'>Subtitles lorem ipsem  lorem ipsem</span><br />");
    //                    Response.Write("<div style='position: relative;right: 45px;width: 100px;justify-content: center;align-items: center;border: 1.341px solid var(--Primary-60, #0F62FE);background: var(--Primary-60, #0F62FE);'><a style='color:#FFF;' href='../../modules/challenges/PostChallengeNew.aspx?ChlId=" + row["CHALLENGE_ID"].ToString() + "'>Active");
    //                    Response.Write("</a></div>");
    //                    Response.Write("</a>");
    //                    Response.Write("</div>");
    //                }
    //            }
    //            else
    //            {
    //                Response.Write("<span>No data exist.</span>");
    //            }
    //        }

    //    }
    //    catch (Exception ex)
    //    {
    //        Session["Error"] = ex.ToString();
    //        Response.Redirect("~/ErrorPage.aspx");
    //    }
    //}
    protected void btn_back_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Modules/Challenges/ChallengeHome.aspx");
    }

    //protected void FillGrid()
    //{
    //    try
    //    {
    //        string[] paramArray = new string[3];
    //        paramArray[0] = Session["UserId"].ToString();
    //        if (CommonFunctions.isSuperAdmin(Session["UserId"].ToString()))
    //        {
    //            paramArray[1] = "Y";
    //        }
    //        else
    //        {
    //            paramArray[1] = "N";
    //        }

    //        if (!string.IsNullOrEmpty(Convert.ToString(Session["User_Type"])))
    //            paramArray[2] = Session["User_Type"].ToString();
    //        else
    //            paramArray[2] = "";
    //        DataSet ds = objClass1_BL.getUpcomingChallenges(paramArray);

    //        if (ds.Tables.Count > 0)
    //        {
    //            grdActivechallenges.DataSource = ds;
    //            grdActivechallenges.DataBind();
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        Session["Error"] = ex.ToString();
    //        Response.Redirect("~/ErrorPage.aspx");
    //    }
    //}
    //protected void grdActivechallenges_Rowdatabound(object sender, GridViewRowEventArgs e)
    //{
    //    try
    //    {
    //        if (e.Row.RowType == DataControlRowType.DataRow)
    //        {
    //            System.Web.UI.WebControls.Image img = (System.Web.UI.WebControls.Image)e.Row.FindControl("imgEmp");
    //            string ImagePath = img.ImageUrl;
    //            if (ImagePath == "")
    //            {
    //                img = (System.Web.UI.WebControls.Image)e.Row.FindControl("imgEmp");
    //                img.ImageUrl = "~/images/dasboard2.png";
    //            }

    //            Label lbl = (Label)e.Row.FindControl("hypviewdetail");
    //            DataRowView row = (DataRowView)e.Row.DataItem;
    //            if (row["CHALLENGE_ID"].ToString() != "")
    //                lbl.Text = "<a href=\"ChallengeDetails.aspx?ChlId=" + row["CHALLENGE_ID"].ToString() + "\" class=\"pull-left\"><div class=\"details\"><div class=\"detail_icon\"></div><div class=\"detail_txt padb14\">Details</div></div></a>";

    //            LinkButton lnkbtn = (LinkButton)e.Row.FindControl("lnkDownloadFile");

    //            DataSet ds = objClass1_BL.getChallengeDetails(row["CHALLENGE_ID"].ToString());

    //            if (row["CHALLENGE_ID"].ToString() != "")
    //            {
    //                if (ds.Tables[0].Rows.Count > 0)
    //                {
    //                    lnkbtn.Visible = true;
    //                }
    //                else
    //                {
    //                    lnkbtn.Visible = false;
    //                }
    //            }
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        Session["Error"] = ex.ToString();
    //        Response.Redirect("~/ErrorPage.aspx");
    //    }
    //}
    //protected void grdActivechallenges_RowCommand(object sender, GridViewCommandEventArgs e)
    //{
    //    try
    //    {
    //        if (e.CommandName == "DownloadFile")
    //        {
    //            LinkButton lnkView = (LinkButton)e.CommandSource;
    //            Session["ChallengeId_4DwnloadFile"] = lnkView.CommandArgument;

    //            string fileName = objClass1_BL.getChallengeFileName(Session["ChallengeId_4DwnloadFile"].ToString());

    //            //Start - 11th Dec 2017 - Bhakti
    //            //DownloadFile(fileName);
    //            string flpth = Server.MapPath(ConfigurationManager.AppSettings["challangeDocFilePath"].ToString() + @"\" + HttpUtility.HtmlEncode(fileName));
    //            objClass1_BL.DownloadFile(fileName, flpth);
    //            //End - 11th Dec 2017 - Bhakti
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        Session["Error"] = ex.ToString();
    //        Response.Redirect("~/ErrorPage.aspx?r=" + CommonFunctions.GetRandomNumber(), false);
    //    }
    //    finally
    //    {
    //    }
    //}

    ////Start - 11th Dec 2017 - Bhakti
    ////public void DownloadFile(string fn)
    ////{
    ////    try
    ////    {
    ////        Response.ContentType = "text/plain";
    ////        string flpth = Server.MapPath(ConfigurationManager.AppSettings["challangeDocFilePath"].ToString() + @"\" + HttpUtility.HtmlEncode(fn));
    ////        System.Web.HttpResponse response = System.Web.HttpContext.Current.Response;
    ////        Response.ClearContent();
    ////        Response.Clear();
    ////        Response.ContentType = "text/plain";
    ////        Response.AddHeader("Content-Disposition", "attachment; filename=" + HttpUtility.HtmlEncode(fn) + ";");
    ////        Response.TransmitFile(flpth);
    ////        HttpContext.Current.Response.Flush();
    ////        HttpContext.Current.Response.SuppressContent = true;
    ////        HttpContext.Current.ApplicationInstance.CompleteRequest();
    ////    }
    ////    catch (Exception ex)
    ////    {
    ////        Session["Error"] = ex.ToString();
    ////        Response.Redirect("~/ErrorPage.aspx?r=" + CommonFunctions.GetRandomNumber(), false);
    ////    }
    ////    finally
    ////    {
    ////    }
    ////}
    ////End - 11th Dec 2017 - Bhakti
}

