﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Reflection;
using System.Data;
using OraAppBlock;
using BusinessLayer;
namespace LogError
{
    public class LogError
    {
        //Start - 13th Nov  2017 - Bhakti
        BusinessLayer.IRIS_BusinessLayer objClass1_BL = new BusinessLayer.IRIS_BusinessLayer();
        //End - 13th Nov 2017 - Bhakti

        public LogError(DateTime P_LOG_DATE, string p_USER_ID, string P_Error_Msg)
        {
            LogErr(P_LOG_DATE, p_USER_ID, P_Error_Msg);
        }
        public void LogErr(DateTime P_LOG_DATE, string p_USER_ID, string P_Error_Msg)
        {
            try
            {
                

                objClass1_BL.IRIS_INSERT_ERROR(P_LOG_DATE, p_USER_ID, P_Error_Msg);
                
            }
            catch (Exception ex)
            {
                HttpContext.Current.Session["Error"] = ex.ToString();
                HttpContext.Current.Response.Redirect("~/ErrorPage.aspx");
            }
            finally
            {
                
            }
        }
    }
}
