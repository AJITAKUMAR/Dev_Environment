﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.Common;
using System.Configuration;
using BusinessEntity;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Text;
using System.Collections;
using System.IO;
using System.Security.Cryptography;
using System.Data.SqlClient;
using OraAppBlock;

/// <summary>
/// Summary description for CommonFunctions
/// </summary>
public class CommonFunctions
{
    public CommonFunctions()
    {
        //
        // TODO: Add constructor logic here
        //

    }

   
    public static SqlConnection OpenConnetion1()
    {
        string strConnectionString = getConnectionString1();
        return new SqlConnection(strConnectionString);

    }

    

   

    public static void FillDropdown(ListBox DropdownName, DataView SourceTable, string TextField, string ValueField, string DefaultItem, string NoData)
    {
        DropdownName.Items.Clear();
        if (SourceTable != null)
        {
            if (SourceTable.Table.Rows.Count > 0)
            {
                DropdownName.DataSource = SourceTable;
                DropdownName.DataTextField = TextField;
                DropdownName.DataValueField = ValueField;
                DropdownName.DataBind();
                //DropdownName.Items.Insert(0, new ListItem(DefaultItem, "-1"));
                return;
            }
            //DropdownName.Items.Insert(0, new ListItem(NoData, "-1"));
            //return;
        }
        //DropdownName.Items.Insert(0, new ListItem(NoData, "-1"));
        //return;
    }

    //added by vinayak
    public static void fillDDL(DataTable dt, DropDownList ddl, bool blIsAll)
    {
        string str = string.Empty;
        ddl.Items.Clear();
        if (dt.Rows.Count > 0)
        {
            foreach (DataRow dr in dt.Rows)
            {
                str = RpadNBSP(Convert.ToInt32(dr["Len_To_Add"].ToString()), "&nbsp;");
                //ListItem li = new ListItem(dr["codeValue"].ToString() + HttpServerUtility.UrlTokenDecode(str) + " - " + dr["codeDesc"].ToString(), dr["codeValue"].ToString());
                //ListItem li = new ListItem(dr["codeValue"].ToString() + System.Web.HttpUtility.HtmlDecode(str) + " - " + dr["codeDesc"].ToString(), dr["codeValue"].ToString());
                ListItem li = new ListItem(dr["codeValue"].ToString() + HttpContext.Current.Server.HtmlDecode(str) + " - " + dr["codeDesc"].ToString(), dr["codeValue"].ToString());
                ddl.Items.Add(li);
            }
        }

        ListItem lst = new ListItem("--Select--", " ");
        ddl.Items.Insert(0, lst);

        if (blIsAll && dt.Rows.Count > 0)
        {
            lst = new ListItem("ALL", "ALL");
            ddl.Items.Insert(1, lst);
        }
    }

    public static void fillCheckBoxList(DataTable dt, CheckBoxList chk)
    {
        string str = string.Empty;
        chk.Items.Clear();
        if (dt.Rows.Count > 0)
        {
            foreach (DataRow dr in dt.Rows)
            {
                str = RpadNBSP(Convert.ToInt32(dr["Len_To_Add"].ToString()), "&nbsp;");
                ListItem li = new ListItem(dr["codeValue"].ToString() + HttpContext.Current.Server.HtmlDecode(str) + " - " + dr["codeDesc"].ToString(), dr["codeValue"].ToString());
                chk.Items.Add(li);
            }
        }
    }

    public static string RpadNBSP(int iLen, string strToPad)
    {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < iLen; i++)
            sb.Append(strToPad);

        return sb.ToString();
    }

   

    

    

    

    
    

    public static void FillDropdown(DropDownList DropdownName, DataView SourceTable, string TextField, string ValueField, string DefaultItem, string NoData)
    {
        DropdownName.Items.Clear();        

        if (SourceTable.Table.Rows.Count > 0)
        {
            DropdownName.DataSource = SourceTable;
            DropdownName.DataTextField = TextField;
            DropdownName.DataValueField = ValueField;
            DropdownName.DataBind();
            //return;
        }
        DropdownName.Items.Insert(0, new ListItem(DefaultItem, " "));

    }


    
    //McCain

    public static string getConnectionString1()
    {
        string strConnectionString = ConfigurationManager.ConnectionStrings["constr"].ToString();
        //string strConnectionString = EnCryptDecrypt.CryptorEngine.Decrypt(ConfigurationManager.ConnectionStrings["ConString"].ToString(), true);
        return strConnectionString;
    }






    public static string getUATConnectionString()
    {
        //string strConnectionString = ConfigurationManager.ConnectionStrings["ConString"].ToString();
        string strConnectionString = EnCryptDecrypt.CryptorEngine.Decrypt(ConfigurationManager.ConnectionStrings["ConString"].ToString(), true);
        return strConnectionString;
    }

    public static string getDevConnectionString()
    {
        //string strConnectionString = ConfigurationManager.ConnectionStrings["ConString"].ToString();
        string strConnectionString = EnCryptDecrypt.CryptorEngine.Decrypt(ConfigurationManager.ConnectionStrings["ConString"].ToString(), true);
        return strConnectionString;
    }
       
    //McCain
    public static bool isSuperAdmin1(string sEmpID)
    {
        if (isAdmin1(sEmpID))
            return true;

        return false;
    }

    //McCain
    private static bool isAdmin1(string sEmpID)
    {
        string strSql;
        string strConnectionString = CommonFunctions.getConnectionString1();
        SqlConnection pConn = new SqlConnection();
        pConn = CommonFunctions.OpenConnetion1();
        pConn.Open();
        try
        {
            strSql = "SELECT EMPCODE,EMPNAME,EMPEMAIL FROM iris_admin_master where EMPEMAIL='" + sEmpID + "' ";
            DataSet ds = OracleHelper.ExecuteDataset1(pConn, CommandType.Text, strSql);
            if (ds.Tables[0].Rows.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
                
            
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            pConn.Close();
        }
    }


   

    


    //added VY - 05-Oxt-15
    public static bool isStringInString(string sMainStringCommaSeparated, string sSubString)
    {
        ArrayList al = new ArrayList();
        al.AddRange(sMainStringCommaSeparated.Split(','));
        if (al.IndexOf(sSubString) > -1)
            return true;

        return false;
    }

    public static string GetRandomNumber()
    {
        RandomNumberGenerator rng = new RNGCryptoServiceProvider();
        byte[] tokenData = new byte[32];
        rng.GetBytes(tokenData);
        return Convert.ToBase64String(tokenData);
    }
}