﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;


public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //string patemillist = "abc@xyz.com,bbc@co.uk";
        //string mainlist = patemillist.Replace(" ", string.Empty).Replace(",", ";");

        //string path = "/fm/Templates/testTemplate/css/article.jpg";
        //string newpath = path.Replace("/fm", string.Empty).Replace("/", "\\");

        DateTime starting = new DateTime();
        starting = DateTime.ParseExact("24/09/2024", "dd-MM-yyyy", null);
        DateTime ending = new DateTime();
        ending = DateTime.ParseExact("28/09/2024", "dd-MM-yyyy", null);

        DateTime[] dates = GetDatesBetween(starting, ending).ToArray();

    }
    public DateTime[] GetDatesBetween(DateTime startDate, DateTime endDate)
    {
        List<DateTime> allDates = new List<DateTime>();
        for (DateTime date = startDate; date <= endDate; date = date.AddDays(1))
            allDates.Add(date);
        return allDates.ToArray();
    }
}