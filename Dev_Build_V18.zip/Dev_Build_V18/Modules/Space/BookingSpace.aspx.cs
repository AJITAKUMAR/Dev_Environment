﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

public partial class Modules_Space_BookingSpace : System.Web.UI.Page
{
    BusinessLayer.IRIS_BusinessLayer objClass1_BL = new BusinessLayer.IRIS_BusinessLayer();
    string activityid = "";
    string path = "";
    string ideasub_date;
    protected void Page_Load(object sender, EventArgs e)
    {
        path = HttpContext.Current.Request.Url.AbsolutePath;
        lblerrmessage.Visible = false;
        try
        {
            if (Session["UserId"] == null || Convert.ToString(Session["UserId"]) == "")
            {
                Response.Redirect("~/Login.aspx?r=" + CommonFunctions.GetRandomNumber(), false);
            }
            if ((Request.QueryString["ChlId"] != null))
            {
                activityid = Request.QueryString["ChlId"].ToString();
            }
            if (!IsPostBack)
            {
                //activityid = Session["RequestSpaceId"].ToString();
                

            }
            LoadActivityDetails();
        }
        catch (Exception ex)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
                Session["Error"] = Session["Error"] + ex.ToString();
            else
                Session["Error"] = ex.ToString();
            Response.Redirect("~/ErrorPage.aspx");
        }
        finally
        {

        }

        txtactvityid.Enabled = false;
        txtactivatyname.Enabled = false;
        controldisable();
        


    }
    public void controldisable()
    {
        txtContent.Enabled = false;
        //ddlspacebooking.Enabled = false;
        //txtstartdate.Enabled = false;
        //txtEnddate.Enabled = false;
        txtparticipants.Enabled = false;
    }
    public void LoadActivityDetails()
    {
        try
        {
            string EmpId = Session["UserId"].ToString();
            DataSet ds = new DataSet();
            if (Session["Admin"] != null || Convert.ToString(Session["Admin"]) != "")
            {
                ds = objClass1_BL.GET_SPACE_DASHBOARD_DETAILS_A(EmpId, activityid);
                
            }
            else
            {
                ds = objClass1_BL.GET_SPACE_DASHBOARD_DETAILS(EmpId, activityid);

            }  
            
            if (ds.Tables[0].Rows.Count > 0)
            {
                if (txtactvityid.Text == "")// data assigne in null case??????????????????
                {
                    txtactvityid.Text = ds.Tables[0].Rows[0]["ACTIVITYID"].ToString();
                    txtactivatyname.Text = ds.Tables[0].Rows[0]["ACTIVITY_NAME"].ToString();
                    txtContent.Text = ds.Tables[0].Rows[0]["DESCRIPTION"].ToString();
                    if (ds.Tables[0].Rows[0]["SPACE"].ToString() != "")
                    {
                        ddlspacebooking.SelectedItem.Text = ds.Tables[0].Rows[0]["SPACE"].ToString();
                    }
                    txtstartdate.Text = ds.Tables[0].Rows[0]["START_DATE"].ToString();                    
                    txtEnddate.Text = ds.Tables[0].Rows[0]["END_DATE"].ToString();
                    txtparticipants.Text = ds.Tables[0].Rows[0]["PARTICIPANTS"].ToString();
                }
                ideasub_date = ds.Tables[0].Rows[0]["START_DATE"].ToString();// data assigne every time when the page is load??????????

            }
        }
        catch (Exception ex)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }

        }
        finally
        {

        }
    }

    public DateTime[] GetDatesBetween(DateTime startDate, DateTime endDate)
    {
        List<DateTime> allDates = new List<DateTime>();
        for (DateTime date = startDate; date <= endDate; date = date.AddDays(1))
            allDates.Add(date);
        return allDates.ToArray();
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            //DateTime dt1;
            //DateTime dt2;

            //Session["Admin"] = "";
            //Session["Admin"] = null;

            //DateTime today = DateTime.Now;
            //int year = today.Year;
            //int month = today.Month;
            //int day = today.Day;
            //string s = "/";
            //string currentdate = string.Concat(day,s, month,s, year);
            //string startdate = txtstartdate.Text;

            //if (DateTime.TryParse(startdate, out dt1) && DateTime.TryParse(currentdate, out dt2))
            //{
            //    if (dt1.Date >= dt2.Date)
            //    {

            //    }
            //    else
            //    {
            //        lblerrmessage.Text = "Enter Valied Start Date.!";
            //        lblerrmessage.Visible = true;
            //        return;
            //    }
            //}



            //if (startdate < currentdate)
            //{

            //}
            //int cmp = currentdate.CompareTo(txtstartdate.Text);
            //if (cmp > 0)
            //{
            //    lblerrmessage.Text = "Enter Valid Start Date.!";
            //    lblerrmessage.Visible = true;
            //    return;
            //}
            //------------------------
            //else
            //{
            //    objClass1_BL.AlertBox("Error1.", this);
            //    return;
            //}
            //else if (String.Compare(txtstartdate.Text, ideasub_date) > 0)
            //{
            //    string strdate1 = ideasub_date;
            //}

            //if (String.Compare(txtstartdate.Text, ideasub_date) == 0)
            //{
            //    string strdate = ideasub_date;
            //}            
            //else
            //{
            //    objClass1_BL.AlertBox("Date format not correct.", this);
            //    return;
            //}

            string sdate = DateTime.ParseExact(txtstartdate.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture)
                       .ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
            string edate = DateTime.ParseExact(txtEnddate.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture)
                    .ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);

            DataSet ds1 = new DataSet();
            string space = "";
            ds1 = objClass1_BL.CHECK_SPACE_ALREADY_BOOKING(sdate, edate, ddlspacebooking.SelectedItem.Text);

            if (ds1.Tables[0].Rows.Count > 0)
            {
                int count = 0;

                foreach (DataRow row in ds1.Tables[0].Rows)
                {
                    DateTime d1, d2, id1, id2;
                    string db_startdate1 = DateTime.ParseExact(ds1.Tables[0].Rows[count]["START_DATE"].ToString(), "dd/MM/yyyy", CultureInfo.InvariantCulture)
                        .ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                    string db_enddate2 = DateTime.ParseExact(ds1.Tables[0].Rows[count]["END_DATE"].ToString(), "dd/MM/yyyy", CultureInfo.InvariantCulture)
                        .ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);

                    string inp_startdate1 = sdate;
                    string inp_enddate1 = edate;


                    d1 = DateTime.ParseExact(db_startdate1, "MM/dd/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    d2 = DateTime.ParseExact(db_enddate2, "MM/dd/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    id1 = DateTime.ParseExact(inp_startdate1, "MM/dd/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    id2 = DateTime.ParseExact(inp_enddate1, "MM/dd/yyyy", System.Globalization.CultureInfo.InvariantCulture);

                    DateTime starting = new DateTime();
                    starting = DateTime.ParseExact(id1.ToString("dd-MM-yyyy"), "dd-MM-yyyy", null);
                    DateTime ending = new DateTime();
                    ending = DateTime.ParseExact(id2.ToString("dd-MM-yyyy"), "dd-MM-yyyy", null);

                    DateTime[] dates = GetDatesBetween(starting, ending).ToArray();
                    if (id1 > d2)// check condition input start date and database end date // insert willk happen??????????
                    {
                        string str = "do not check any condition";
                    }
                    else
                    {
                        if (dates.Length > 0)
                        {
                            objClass1_BL.AlertBox("Space Not available for same date. Please Change the date.", this);
                            return;
                        }
                        //if (id1 == d2) //raise error
                        //{
                        //    objClass1_BL.AlertBox("Space Not available please change the date.", this);
                        //    return;
                        //}

                    }

                    count++;
                }
            }



            string[] paramArray = new string[9];
            paramArray[0] = txtactvityid.Text;
            paramArray[1] = txtactivatyname.Text;
            paramArray[2] = txttypeofactivity.Text;
            paramArray[3] = txtContent.Text;
            paramArray[4] = txtstartdate.Text;
            paramArray[5] = txtEnddate.Text;
            paramArray[6] = ddlspacebooking.SelectedItem.Text;           
            paramArray[7] = txtparticipants.Text;
            paramArray[8] = "602";

            int getid = objClass1_BL.INSERT_POST_BOOKING_SPACE(paramArray);
            if (getid > 0)
            {
                try
                {
                    DataSet ds = objClass1_BL.GET_IIDEADETAILS(txtactvityid.Text);
                    DataTable dt = ds.Tables[0];
                    string listemail = dt.Rows[0]["PEOPLE_NAME"].ToString();
                    string main_list = listemail.Replace(" ", string.Empty).Replace(",", ";");

                    int ideaId = Convert.ToInt32(txtactvityid.Text);
                    objClass1_BL.Mail_IdeaSubmitted_TheMix(ideaId, HttpContext.Current.Session["UserId"].ToString(), "TheMix : Your Space Request is Submited.!", "Space_Allocation_Request.html", main_list.Trim());
                    HttpContext.Current.Session["SuccessMessage"] = "Space Booking Data Saved Successfully.!";
                    HttpContext.Current.Response.Redirect("~/Modules/Message/SuccessMessage.aspx", false);
                }
                catch (Exception ex) 
                {
                    HttpContext.Current.Session["SuccessMessage"] = "Space Booking Data Saved Successfully. Email send fail Contract System Admin.!";
                    HttpContext.Current.Response.Redirect("~/Modules/Message/SuccessMessage.aspx", false);
                }
                
                //ScriptManager.RegisterStartupScript(Page, GetType(), "LHS9", "alert('Space Booking Data Saved Successfully...!');", true);
            }

        }
        catch (Exception ex)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }
        }
        finally
        {

        }
    }

    public void clearcontrol()
    {
        txttypeofactivity.Text = "";
        txtContent.Text = "";
        txtstartdate.Text = "";
        txtEnddate.Text = "";
        ddlspacebooking.SelectedValue = "0";
        txtparticipants.Text = "";
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Session["Admin"] = "";
        Session["Admin"] = null;
        if (Session["postbackurl"] != null || Convert.ToString(Session["postbackurl"]) != "")
        {
            HttpContext.Current.Response.Redirect(Session["postbackurl"].ToString());
        }
        HttpContext.Current.Response.Redirect("~/HomePage.aspx");
    }

    //protected void txtEnddate_TextChanged(object sender, EventArgs e)
    //{
    //    try
    //    {
    //        if (ddlspacebooking.SelectedValue == "0")
    //        {
    //            lblerrmessage.Text = "Please Select Space !";
    //            lblerrmessage.Visible = true;
    //            txtstartdate.Text = "";
    //            txtEnddate.Text = "";
    //            return;
    //        }
    //        if (txtstartdate.Text == "")
    //        {
    //            lblerrmessage.Text = "Please Select Start Date!";
    //            lblerrmessage.Visible = true;
    //            txtstartdate.Text = "";
    //            txtEnddate.Text = "";
    //            return;                
    //        }

    //        DataSet Ideads = objClass1_BL.GET_SPACE_DETAILS(ddlspacebooking.SelectedItem.Text);
    //        DataTable dt = Ideads.Tables[0];
    //        if (dt.Rows.Count > 0)
    //        {
    //            string Sdate = dt.Rows[0]["START_DATE"].ToString();
    //            string Edate = dt.Rows[0]["END_DATE"].ToString();

    //            int cmp = Edate.CompareTo(txtstartdate.Text);
    //            if (cmp > 0)
    //            {
    //                lblerrmessage.Text = "Slot not availabe in same date";
    //                lblerrmessage.Visible = true;
    //                txtstartdate.Text = "";
    //                txtEnddate.Text = "";

    //            }
    //        }




    //    }
    //    catch (Exception ex)
    //    {
    //        if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
    //        {
    //            Session["Error"] = Session["Error"] + ex.ToString();
    //        }
    //        else
    //        {
    //            Session["Error"] = ex.ToString();
    //            Response.Redirect("~/ErrorPage.aspx");
    //        }
    //    }
    //    finally
    //    {

    //    }
    //}

    //protected void btnedit_Click(object sender, EventArgs e)
    //{
    //    controlenable();
    //}
    //public void controlenable()
    //{
    //    txtContent.Enabled = true;
    //    ddlspacebooking.Enabled = true;
    //    txtstartdate.Enabled = true;
    //    txtEnddate.Enabled = true;
    //    txtparticipants.Enabled = true;
    //}
}