﻿using AjaxControlToolkit.HTMLEditor.ToolbarButton;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using System.Collections;


public partial class Modules_Events_viewevent : System.Web.UI.Page
{
    BusinessLayer.IRIS_BusinessLayer objClass1_BL = new BusinessLayer.IRIS_BusinessLayer();
    string path = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        path = HttpContext.Current.Request.Url.AbsolutePath;
        if (Session["UserId"] == null || Convert.ToString(Session["UserId"]) == "")
        {
            Response.Redirect("~/Login.aspx?r=" + CommonFunctions.GetRandomNumber(), false);
        }       
        try
        {
            if (!IsPostBack)
            {
                if (Session["UserId"] == null || Convert.ToString(Session["UserId"]) == "")
                {
                    Response.Redirect("~/Login.aspx?r=" + CommonFunctions.GetRandomNumber(), false);
                }
                grViewIdea.PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["ViewMyIdea_grViewIdea"].ToString());
                BindGrid();
                HttpContext.Current.Session["RequestPath"] = "";
                HttpContext.Current.Session["RequestPath"] = null;

            }


        }
        catch (Exception ex)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }
        }
        finally
        {
        }
    }


    private void BindGrid()
    {
        try
        {
            string EmpId = Session["UserId"].ToString();
            string AllEvent = "";            
            //DataSet ds = new DataSet();
            //ds = objClass1_BL.IRIS_BY_FILTER_GET_EVENT(Empid);
            DataSet ds = objClass1_BL.GET_EVENT_DETAILS(EmpId, AllEvent);
            grViewIdea.DataSource = ds.Tables[0];
            grViewIdea.DataBind();
        }
        catch (Exception ex)
        {
            Session["Error"] = ex.ToString();
            Response.Redirect("~/ErrorPage.aspx");
        }
        finally
        {
        }

    }

    protected void grViewIdea_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grViewIdea.PageIndex = e.NewPageIndex;
        BindGrid();
    }


    protected void grViewIdea_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Select" || e.CommandName == "vieweventdetails")
        {
            Session["selectedideaid"] = "";
            Session["selectedideaid"] = null;
            Session["postbackurl"] = "";
            Session["postbackurl"] = null;
            int rowIndexId = Convert.ToInt32(e.CommandArgument);
            HttpContext.Current.Session["selectedideaid"] = rowIndexId;
            HttpContext.Current.Session["postbackurl"] = path;
            Response.Redirect("~/Modules/Events/PostEvents.aspx");

        }

    }
    protected void grViewIdea_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //try
        //{
        //    if (e.Row.RowType == DataControlRowType.DataRow)
        //    {
        //        Label lblstr = (Label)e.Row.FindControl("lblStatus");
        //        string statustext = ((Label)(e.Row.Cells[4].FindControl("lblStatus"))).Text;

        //        if (statustext == "Approved")
        //        {
        //            e.Row.Cells[6].BackColor = Color.Green;
        //            e.Row.Cells[6].ForeColor = Color.White;
        //        }
        //        else if (statustext == "Pending")
        //        {
        //            e.Row.Cells[6].BackColor = Color.Orange;
        //            e.Row.Cells[6].ForeColor = Color.White;
        //        }
        //        else if (statustext == "Rejected")
        //        {
        //            e.Row.Cells[6].BackColor = Color.Red;
        //            e.Row.Cells[6].ForeColor = Color.White;
        //        }
        //        else
        //        {
        //            e.Row.Cells[6].BackColor = Color.Orange;
        //            e.Row.Cells[6].ForeColor = Color.White;
        //        }


        //    }
        //}
        //catch (Exception ex)
        //{
        //    Session["Error"] = ex.ToString();
        //    Response.Redirect("~/ErrorPage.aspx");
        //}
    }


    //public void AddDynamicDivs()
    //{

    //    try
    //    {

    //        //DataSet ds = objClass1_BL.getPastChallenges(paramArray);//mccain
    //        //DataSet ds = objClass1_BL.getPastChallenges1(paramArray);
    //        string EmpId = Session["UserId"].ToString();
    //        string AllEvent = "";
    //        DataSet ds = objClass1_BL.GET_EVENT_DETAILS(EmpId,AllEvent);
    //        if (ds.Tables.Count > 0)
    //        {
    //            if (ds.Tables[0].Rows.Count > 0)
    //            {
    //                foreach (DataRow row in ds.Tables[0].Rows)
    //                {
    //                    string challengeName = string.Empty;
    //                    string challengeImage = string.Empty;
    //                    HttpContext.Current.Session["RequestPath"] = "";
    //                    HttpContext.Current.Session["RequestPath"] = path;

    //                    challengeName = Regex.Replace(row["EVENT_TYPE"].ToString(), "<.*?>", string.Empty);
    //                    if (challengeName.Length < 200)
    //                    {
    //                        //challengeName = challengeName.PadRight(200 - challengeName.Length);
    //                        // challengeName=challengeName+new string(' ', 200 - challengeName.Length);
    //                        challengeName = challengeName + new string(' ', 1);
    //                        int i = 200 - challengeName.Length;
    //                        while (i > 0)
    //                        {
    //                            //challengeName = challengeName + "&nbsp;";
    //                            challengeName = challengeName + "";
    //                            i--;
    //                        }
    //                    }
    //                    if (!string.IsNullOrEmpty(row["EVENT_IMAGE"].ToString()))
    //                    {
    //                        challengeImage = row["EVENT_IMAGE"].ToString();
    //                    }
    //                    else
    //                    {
    //                        challengeImage = "Event.png";
    //                    }
    //                    Response.Write("<div style='margin:10px 0px 0px 10px; text-align:center; width:24%; display:inline-block; vertical-align: top; overflow-wrap: break-word; word-wrap:break-word;' class='challenge-card'>");
    //                    Response.Write("<a href='../../modules/Events/PostEvents.aspx?ChlId=" + row["EVENT_ID"].ToString() + "'>");
    //                    //Response.Write("<div style='height:264px;'>");
    //                    Response.Write("<img style='width:120px;'  src='../../images/icons/" + challengeImage + "'/><br />");
    //                    Response.Write("<span class='classdynamicdiv'>" + challengeName + "</span>");
    //                    //Response.Write("</div>");                       
    //                    Response.Write("</a>");
    //                    Response.Write("</div>");
    //                }

    //            }
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        Session["Error"] = ex.ToString();
    //        Response.Redirect("~/ErrorPage.aspx");
    //    }
    //}

    protected void btn_back_Click(object sender, EventArgs e)
    {
        HttpContext.Current.Session["RequestPath"] = "";
        HttpContext.Current.Session["RequestPath"] = null;
        Session["selectedideaid"] = "";
        Session["selectedideaid"] = null;
        Session["postbackurl"] = "";
        Session["postbackurl"] = null;
        Response.Redirect("~/Modules/Events/EventHome.aspx");
    }
}