﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class FAQs : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            btn_previous.Visible = false;
            faq_container2.Visible = false;
            btn_next.Attributes.Add("style","left: 975px;");
        }

    }
    protected void btn_previous_Click(object sender, EventArgs e)
    {
        btn_previous.Visible = false;
        faq_container2.Visible = false;
        btn_next.Visible = true;
        faq_container1.Visible = true;
        btn_next.Attributes.Add("style", "left: 975px;");
    }
    protected void btn_next_Click(object sender, EventArgs e)
    {
        btn_previous.Visible = true;
        faq_container2.Visible = true;
        faq_container1.Visible = false;
        btn_next.Attributes.Add("style", "left: 910px;");
    }



    
}