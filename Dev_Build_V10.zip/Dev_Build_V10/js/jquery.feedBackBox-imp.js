
; (function ($) {
    $.fn.extend({
        feedBackBox: function (options) {

            // default options
            this.defaultOptions = {
                title: 'Guidelines',
                titleMessage: 'Guidelines',
                userName: '',
                isUsernameEnabled: true,
                message: '',
               
                successMessage: 'Thank your for your feedback.',
                errorMessage: 'Something wen\'t wrong!'
            };

            var settings = $.extend(true, {}, this.defaultOptions, options);

            return this.each(function () {
                var $this = $(this);
                var thisSettings = $.extend({}, settings);

                var diableUsername;
                if (!thisSettings.isUsernameEnabled) {
                    diableUsername = 'disabled="disabled"';
                }

                // add feedback box
                $this.html('<div id="fpi_feedback"><div id="fpi_title" class="rotate"><h2>'
                    + thisSettings.title
                    + '</h2></div><div id="fpi_content">'
					+ '<div class="help-container">'
									+ '<div class="help-head">Guidelines</div>'
									+'<div class="help-inner">'
									+'<div class="help-inner">'
										+'<h3>Generate themes for ideators based on </h3>'
										+'<p>-market needs-markets that our customers are in and “one step ahead of our customer” approach.</p>'
										+'<p>-Customer problems-current problems faced by our customers.</p>'
										+'<p>-Delivery and engineering problems-target areas where we can improve delivery, reduce cost, improve quality etc.</p>'
										+'<p>-Business Problems- Themes that draw attention to the business scenarios that TechM is currently in -e.g., HR, Cost transformation, facilities, IT infrastructure, T&M versus fixed price, Brnding, etc.</p>'
									+'</div>'
									+'<div class="help-inner">'
										+'<h3>Provide Content </h3>'
										+'<p>-Provide material for the listed themes like videos, research articles, guidelines, industry trends.</p>'
									+'</div>'
									+'<div class="help-inner">'
										+'<h3>Guide Innovation mentors</h3>'
										+'<p>-Guide innovation mentors on how to evaluate ideas provided against their themes.</p>'
										+'<p>-Provide additional support to innovation mentors by pointing them to right people or content to refine the ideas.</p>'
									+'</div>'
									+'<div class="help-inner">'
										+'<h3>Act as catalysts</h3>'
										+'<p>-Get industry and academia inputs.</p>'
										+'<p>-Drive more ideas for their themes by conducting road shows.</p>'
										+'<p>-Explain the themes to all ideators by providing them the background of the theme.</p>'
									+'</div>'	
								+'</div>'
					+ '</div></div>');

                // remove error indication on text change
                $('#fpi_submit_username input').change(function () {
                    if ($(this).val() != '') {
                        $(this).removeClass('error');
                    }
                });
                $('#fpi_submit_message textarea').change(function () {
                    if ($(this).val() != '') {
                        $(this).removeClass('error');
                    }
                });

                // submit action
                $this.find('form').submit(function () {

                    // validate input fields
                    var haveErrors = false;
                    if ($('#fpi_submit_username input').val() == '' && typeof diableUsername == 'undefined') {
                        haveErrors = true;
                        $('#fpi_submit_username input').addClass('error');
                    }
                    if ($('#fpi_submit_message textarea').val() == '') {
                        haveErrors = true;
                        $('#fpi_submit_message textarea').addClass('error');
                    } 

                    // send ajax call
                    if (!haveErrors) {
                        // serialize all input fields
                        var disabled = $(this).find(':input:disabled').removeAttr('disabled');
                        var serialized = $(this).serialize();
                        disabled.attr('disabled', 'disabled');

                        // disable submit button
                        $('#fpi_submit_submit input').attr('disabled', 'disabled');

                        $.ajax({
                            type: 'POST',
                          
                            url: thisSettings.ajaxUrl,
                            data: serialized,
                            beforeSend: function () {
                                $('#fpi_submit_loading').show();
                            },
                            error: function (data) {
                                $('#fpi_content form').hide();
                                $('#fpi_content #fpi_ajax_message h2').html(thisSettings.errorMessage);
                            },
                            success: function () {
                                $('#fpi_content form').hide();
                                $('#fpi_content #fpi_ajax_message h2').html(thisSettings.successMessage);
                            }
                        });
                    }

                    return false;
                });

                // open and close animation
                var isOpen = false;
                $('#fpi_title').click(function () {
                    if (isOpen) {
                        $('#fpi_feedback').animate({ "width": "+=1%" }, "fast")
                        .animate({ "width": "4.4%" }, "slow");
                        
                        isOpen = !isOpen;
                    } else {
                        $('#fpi_feedback').animate({ "width": "-=1%" }, "fast")
                        .animate({ "width": "75%" }, "slow");
                      
						

                        // reset properties
                        $('#fpi_submit_loading').hide();
                        $('#fpi_content form').show()
                        $('#fpi_content form .error').removeClass("error");
                        $('#fpi_submit_submit input').removeAttr('disabled');
                        isOpen = !isOpen;
                    }
                });

            });
        }
    });
})(jQuery);
