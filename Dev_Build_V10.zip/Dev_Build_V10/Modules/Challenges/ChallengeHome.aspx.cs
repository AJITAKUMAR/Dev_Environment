﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Modules_Challenges_ChallengeHome : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //path = HttpContext.Current.Request.Url.AbsolutePath;
        //lblerrmessage.Visible = false;
        try
        {
            if (Session["UserId"] == null || Convert.ToString(Session["UserId"]) == "")
            {
                Response.Redirect("~/Login.aspx?r=" + CommonFunctions.GetRandomNumber(), false);
            }
            if (!IsPostBack)
            {
                
            }
            getRoles();
        }
        catch (Exception ex)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
                Session["Error"] = Session["Error"] + ex.ToString();
            else
                Session["Error"] = ex.ToString();
            Response.Redirect("~/ErrorPage.aspx");
        }
        finally
        {

        }
    }

    public void getRoles()
    {
        try
        {
            //string UserId=string.Empty;
            if (Session["UserId"] == null || Convert.ToString(Session["UserId"]) == "")
            {
                Response.Redirect("~/Login.aspx?r=" + CommonFunctions.GetRandomNumber(), false);
            }
            else
            {
                string UserId = Session["UserId"].ToString();
                string Admin = "";
                if (CommonFunctions.isSuperAdmin1(Session["UserId"].ToString()))
                {
                    Admin = Session["UserId"].ToString();                    
                }
                else
                {
                    
                }
                if (UserId == Admin)
                {
                    post_challenge.Visible = true;                    
                }
                else
                {
                    post_challenge.Visible = false;
                    view_challenge.Attributes.Add("style", "margin-left: 335px;");
                }
            }



        }
        catch (Exception ex)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }
        }
        finally
        {

        }

    }
}