﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OracleClient;
using OraAppBlock;
using System.Configuration;
using System.Text.RegularExpressions;

public partial class ViewPastchallenge : System.Web.UI.Page
{
    DataSet ds1 = null;
    //Start - 23th Oct 2017 - Bhakti
    BusinessLayer.IRIS_BusinessLayer objClass1_BL = new BusinessLayer.IRIS_BusinessLayer();
    //End - 23th Oct 2017 - Bhakti

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            getRoles();
        }
    }


    public void getRoles()
    {
        string UserId = "";
        string Admin = "";
        if (Session["UserId"] == null || Convert.ToString(Session["UserId"]) == "")
        {
            Response.Redirect("~/Login.aspx?r=" + CommonFunctions.GetRandomNumber(), false);
        }
        else
        {
            UserId = Session["UserId"].ToString();
        }

        if (CommonFunctions.isSuperAdmin1(Session["UserId"].ToString()))
        {
            Admin = Session["UserId"].ToString();
        }

        //if (UserId == Admin)
        //{
        //    btn_post.Visible = true;
        //}
        //else
        //{
        //    btn_post.Visible = false;
        //    btn_active.Style.Add("width", "25%");
        //    btn_upcomming.Style.Add("width", "25%");
        //    btn_past.Style.Add("width", "25%");
        //    btn_all.Style.Add("width", "25%");
        //}
    }
    public void printDiv(DataSet ds)
    {
        try
        {
            if (ds.Tables.Count > 0)
            {
                if (ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        string challengeName = string.Empty;
                        string challengeImage = string.Empty;

                        challengeName = Regex.Replace(row["CHALLENGE_TITLE"].ToString(), "<.*?>", string.Empty);
                        if (challengeName.Length < 200)
                        {
                            challengeName = challengeName.PadRight(200 - challengeName.Length);
                        }
                        if (!string.IsNullOrEmpty(row["CHALLENGE_IMAGE"].ToString()))
                        {
                            challengeImage = row["CHALLENGE_IMAGE"].ToString();
                        }
                        else
                        {
                            challengeImage = "IRIS_Innovation_1.jpg";
                        }
                        Response.Write("<div style='margin:10px 0px 0px 10px; text-align:center; width:24%; display:inline-block;  vertical-align: top; padding:0% 0% 1% 0%; overflow-wrap: break-word; word-wrap:break-word;' class='challenge-card'>");
                        Response.Write("<a href='../../modules/challenges/PostChallengeNew.aspx?ChlId=" + row["CHALLENGE_ID"].ToString() + "'>");
                        Response.Write("<img style='width:230px; height:210px'  src='../../images/icons/" + challengeImage + "'/><br />");
                        Response.Write("<span>" + challengeName + "</span>");
                        Response.Write("</a>");
                        Response.Write("</div>");
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Session["Error"] = ex.ToString();
            Response.Redirect("~/ErrorPage.aspx");
        }
    }
    public void AddDynamicDivs()
    {
        if (!IsPostBack)
        {
            try
            {
                string[] paramArray = new string[3];
                paramArray[0] = Session["UserId"].ToString();
                if (CommonFunctions.isSuperAdmin1(Session["UserId"].ToString()))
                {
                    paramArray[1] = "Y";
                }
                else
                {
                    paramArray[1] = "N";
                }

                if (!string.IsNullOrEmpty(Convert.ToString(Session["User_Type"])))
                    paramArray[2] = Session["User_Type"].ToString();
                else
                    paramArray[2] = "";
                //DataSet ds = objClass1_BL.getAllChallenges(paramArray);//
                DataSet ds = objClass1_BL.getAllChallenges1(paramArray);
                printDiv(ds);

            }
            catch (Exception ex)
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }
        }
        else
            printDiv(ds1);
    }
    
    
}

