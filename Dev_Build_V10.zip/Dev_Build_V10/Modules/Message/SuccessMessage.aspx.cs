﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SuccessMessage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["SuccessMessage"] != null || Convert.ToString(Session["SuccessMessage"]) != "")
        {
            lbldisplaymessage.Text = Session["SuccessMessage"].ToString();
        }
        else
        {
            lbldisplaymessage.Text = "Somthing Wronge..Contract System Admin.!!";
        }
    }

    protected void btn_home_Click(object sender, EventArgs e)
    {
        HttpContext.Current.Session["normaluser"] = "";
        HttpContext.Current.Session["normaluser"] = null;
        HttpContext.Current.Session["postbackurl"] = "";
        HttpContext.Current.Session["postbackurl"] = null;
        HttpContext.Current.Session["RequestPath"] = "";
        HttpContext.Current.Session["RequestPath"] = null;
        HttpContext.Current.Session["SuccessMessage"] = "";
        HttpContext.Current.Session["SuccessMessage"] = null;
        HttpContext.Current.Session["selectedideaid"] = "";
        HttpContext.Current.Session["selectedideaid"] = null;
        HttpContext.Current.Response.Redirect("~/HomePage.aspx", false);
    }
}