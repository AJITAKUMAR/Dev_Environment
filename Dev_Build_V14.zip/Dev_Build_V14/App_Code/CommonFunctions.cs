﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.Common;
using System.Configuration;
using System.Data.OracleClient;
using BusinessEntity;
using OraAppBlock;
using System.Web.UI.WebControls;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Text;
using System.Collections;
using System.IO;
using System.Text;
using System.Security.Cryptography;
using System.Data.SqlClient;

/// <summary>
/// Summary description for CommonFunctions
/// </summary>
public class CommonFunctions
{
    public CommonFunctions()
    {
        //
        // TODO: Add constructor logic here
        //

    }

    public static OracleConnection OpenConnetion()
    {
        string strConnectionString = getConnectionString();
        return new OracleConnection(strConnectionString);

    }
    public static SqlConnection OpenConnetion1()
    {
        string strConnectionString = getConnectionString1();
        return new SqlConnection(strConnectionString);

    }

    public static OracleConnection OpenConnetionUAT()
    {
        string strConnectionString = getUATConnectionString();
        return new OracleConnection(strConnectionString);

    }

    public static OracleConnection OpenConnetionDEV()
    {
        string strConnectionString = getDevConnectionString();
        return new OracleConnection(strConnectionString);

    }

    public static void FillDropdown(ListBox DropdownName, DataView SourceTable, string TextField, string ValueField, string DefaultItem, string NoData)
    {
        DropdownName.Items.Clear();
        if (SourceTable != null)
        {
            if (SourceTable.Table.Rows.Count > 0)
            {
                DropdownName.DataSource = SourceTable;
                DropdownName.DataTextField = TextField;
                DropdownName.DataValueField = ValueField;
                DropdownName.DataBind();
                //DropdownName.Items.Insert(0, new ListItem(DefaultItem, "-1"));
                return;
            }
            //DropdownName.Items.Insert(0, new ListItem(NoData, "-1"));
            //return;
        }
        //DropdownName.Items.Insert(0, new ListItem(NoData, "-1"));
        //return;
    }

    //added by vinayak
    public static void fillDDL(DataTable dt, DropDownList ddl, bool blIsAll)
    {
        string str = string.Empty;
        ddl.Items.Clear();
        if (dt.Rows.Count > 0)
        {
            foreach (DataRow dr in dt.Rows)
            {
                str = RpadNBSP(Convert.ToInt32(dr["Len_To_Add"].ToString()), "&nbsp;");
                //ListItem li = new ListItem(dr["codeValue"].ToString() + HttpServerUtility.UrlTokenDecode(str) + " - " + dr["codeDesc"].ToString(), dr["codeValue"].ToString());
                //ListItem li = new ListItem(dr["codeValue"].ToString() + System.Web.HttpUtility.HtmlDecode(str) + " - " + dr["codeDesc"].ToString(), dr["codeValue"].ToString());
                ListItem li = new ListItem(dr["codeValue"].ToString() + HttpContext.Current.Server.HtmlDecode(str) + " - " + dr["codeDesc"].ToString(), dr["codeValue"].ToString());
                ddl.Items.Add(li);
            }
        }

        ListItem lst = new ListItem("--Select--", " ");
        ddl.Items.Insert(0, lst);

        if (blIsAll && dt.Rows.Count > 0)
        {
            lst = new ListItem("ALL", "ALL");
            ddl.Items.Insert(1, lst);
        }
    }

    public static void fillCheckBoxList(DataTable dt, CheckBoxList chk)
    {
        string str = string.Empty;
        chk.Items.Clear();
        if (dt.Rows.Count > 0)
        {
            foreach (DataRow dr in dt.Rows)
            {
                str = RpadNBSP(Convert.ToInt32(dr["Len_To_Add"].ToString()), "&nbsp;");
                ListItem li = new ListItem(dr["codeValue"].ToString() + HttpContext.Current.Server.HtmlDecode(str) + " - " + dr["codeDesc"].ToString(), dr["codeValue"].ToString());
                chk.Items.Add(li);
            }
        }
    }

    public static string RpadNBSP(int iLen, string strToPad)
    {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < iLen; i++)
            sb.Append(strToPad);

        return sb.ToString();
    }

    public static void GetMailSubjectNBody(int status, out string Subject, out string Body)
    {
        Subject = string.Empty;
        Body = string.Empty;
        string strConnectionString = getConnectionString();
        OracleConnection pConn = new OracleConnection();
        pConn = OpenConnetion();
        pConn.Open();
        try
        {
            string strSql = "select * from IRIS_MAIL_MASTER WHERE STATUS_ID=" + status + "";
            DataSet ds = OracleHelper.ExecuteDataset(pConn, CommandType.Text, strSql);
            if (ds.Tables.Count > 0)
            {
                if (ds.Tables[0].Rows.Count > 0)
                {
                    Subject = ds.Tables[0].Rows[0]["MAIL_SUBJECT"].ToString();
                    Body = ds.Tables[0].Rows[0]["MAIL_BODY"].ToString();
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
            //HttpContext.Current.Session["Error"] = ex.ToString();
            //HttpContext.Current.Response.Redirect("~/ErrorPage.aspx");
        }
        finally
        {
            pConn.Close();
        }
    }

    public static string GetUSER_ID_CoIdeator(string User_MailID)
    {
        string UserID = string.Empty;

        string strConnectionString = getConnectionString();
        OracleConnection pConn = new OracleConnection();
        pConn = OpenConnetion();
        pConn.Open();

        try
        {
            foreach (string str in User_MailID.Split(';'))
            {
                string strSql = "select EMPCODE from IRIS_EMPLOYEE_MASTER where upper(EMAILID) ='" + str.ToUpper().Trim() + "' ";
                string User_ID = OracleHelper.ExecuteScalar(pConn, CommandType.Text, strSql).ToString();
                if (UserID == "")
                {
                    UserID = User_ID;
                }
                else
                {
                    UserID = UserID + ";" + User_ID;
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
            //HttpContext.Current.Session["Error"] = ex.ToString();
            //HttpContext.Current.Response.Redirect("~/ErrorPage.aspx");
        }
        finally
        {
            pConn.Close();
        }

        return UserID;
    }

    public static void SaveIRISPoints(int status, string User_ID, string sIdeaID)
    {
        string strConnectionString = getConnectionString();
        OracleConnection pConn = new OracleConnection();
        pConn = OpenConnetion();
        pConn.Open();
        try
        {

            int points = 0;

            string strSql = "select POINTS from IRIS_POINTS_MASTER where STATUS_ID = " + status + "";
            points = Convert.ToInt32(OracleHelper.ExecuteScalar(pConn, CommandType.Text, strSql));

            strSql = "insert into IRIS_POINTS values (" + status + ",'" + User_ID + "','" + DateTime.Now.ToString("dd-MMM-yy") + "'," + points + "," + sIdeaID + ")";
            OracleHelper.ExecuteNonQuery(pConn, CommandType.Text, strSql);

            //LOGGER FUNTIONALITY - SJ
            new Logger.LogWriter(401, Convert.ToDateTime(System.DateTime.Now.ToShortDateString()), HttpContext.Current.Session["UserId"].ToString(), "IRIS Points rewarded", Convert.ToInt32(points), "Status ID", Convert.ToInt32(status));
            //END - LOGGER FUNTIONALITY - SJ
        }
        catch (Exception ex)
        {
            throw ex;
            //HttpContext.Current.Session["Error"] = ex.ToString();
            //HttpContext.Current.Response.Redirect("~/ErrorPage.aspx");
        }
        finally
        {
            pConn.Close();
        }
    }

    public static string MailBody(string HTMLPageName, string User_ID, string ChallengeId, string IdeaId, string Round)
    {
        string strConnectionString = getConnectionString();
        OracleConnection pConn = new OracleConnection();
        pConn = OpenConnetion();
        pConn.Open();
        try
        {
            string body = string.Empty; string Ideator_Name = string.Empty; string Idea_Name = string.Empty; string Idea_ID = string.Empty; string Challenge_Name = string.Empty;
            string Challenge_ID = string.Empty; string Challenge_Owner_Name = string.Empty; string Idea_Count_R1 = string.Empty; string Winning_Idea_Table_R1 = string.Empty;
            string Mentor_List_R1 = string.Empty; string Shorlisted_Idea_Count_R2 = string.Empty; string Mentor_List_R2 = string.Empty; string Mentor_Name = string.Empty;
            string Last_Date_Review_R1 = string.Empty; string Last_Date_Review_R2 = string.Empty; string Challenge_Details_Table = string.Empty; string Winning_Idea_Table_R2 = string.Empty;
            string strSql = string.Empty; string Idea_Count_R2 = string.Empty;
            DataSet ds = new DataSet();

            using (StreamReader reader = new StreamReader(HttpContext.Current.Server.MapPath("~/Mail_Formats/" + HTMLPageName + "")))
            {
                body = reader.ReadToEnd();
            }

            if (User_ID != "")
            {

                strSql = "select * from IRIS_EMPLOYEE_MASTER where EMPCODE = '" + User_ID + "'";
                ds = OracleHelper.ExecuteDataset(pConn, CommandType.Text, strSql);

                if (ds.Tables[0].Rows.Count > 0)
                {
                    Ideator_Name = ds.Tables[0].Rows[0]["EMPNAME"].ToString();
                    Challenge_Owner_Name = ds.Tables[0].Rows[0]["EMPNAME"].ToString();
                    Mentor_Name = ds.Tables[0].Rows[0]["EMPNAME"].ToString();
                }
                else
                {
                    //if (!string.IsNullOrEmpty(Convert.ToString(HttpContext.Current.Session["User_Type"])))
                    {
                        //if (HttpContext.Current.Session["User_Type"].ToString().ToUpper() == "UNIVERSITY")
                        {
                            strSql = "select USER_NAME || ' ' || USER_SURNAME as EMPNAME from IRIS_UNIVERSITY_USERS where USER_ID = '" + User_ID + "'";
                            ds = OracleHelper.ExecuteDataset(pConn, CommandType.Text, strSql);

                            if (ds.Tables[0].Rows.Count > 0)
                            {
                                Ideator_Name = ds.Tables[0].Rows[0]["EMPNAME"].ToString();
                                Challenge_Owner_Name = ds.Tables[0].Rows[0]["EMPNAME"].ToString();
                                Mentor_Name = ds.Tables[0].Rows[0]["EMPNAME"].ToString();
                            }
                        }
                    }
                }
            }
            if (IdeaId != "")
            {
                strSql = "select * from IRIS_POST_IDEA where IDEA_ID = '" + IdeaId + "'";
                ds = OracleHelper.ExecuteDataset(pConn, CommandType.Text, strSql);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    Idea_ID = IdeaId;
                    Idea_Name = ds.Tables[0].Rows[0]["IDEA_NAME"].ToString();
                }
            }
            if (ChallengeId != "")
            {
                strSql = "select * from IRIS_POST_CHALLENGE where CHALLENGE_ID = '" + ChallengeId + "'";
                ds = OracleHelper.ExecuteDataset(pConn, CommandType.Text, strSql);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    Challenge_ID = ChallengeId;
                    Challenge_Name = ds.Tables[0].Rows[0]["CHALLENGE_NAME"].ToString();

                    //commented by Vinayak and made date format as dd-MMM-yy 27-NOV-15
                    //Last_Date_Review_R1 = ds.Tables[0].Rows[0]["ROUND1_EVAL_END_DATE"].ToString();
                    //Last_Date_Review_R2 = ds.Tables[0].Rows[0]["ROUND2_EVAL_END_DATE"].ToString();
                    Last_Date_Review_R1 = Convert.ToDateTime(ds.Tables[0].Rows[0]["ROUND1_EVAL_END_DATE"].ToString()).ToString("dd-MMM-yy");
                    Last_Date_Review_R2 = Convert.ToDateTime(ds.Tables[0].Rows[0]["ROUND2_EVAL_END_DATE"].ToString()).ToString("dd-MMM-yy");

                }

                strSql = "select count(*) cnt from IRIS_POST_IDEA where CHALLENGE_ID = '" + ChallengeId + "' ";
                ds = OracleHelper.ExecuteDataset(pConn, CommandType.Text, strSql);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    Idea_Count_R1 = ds.Tables[0].Rows[0]["cnt"].ToString();
                    Idea_Count_R2 = ds.Tables[0].Rows[0]["cnt"].ToString();
                }

                if (Round != "")
                {
                    //strSql = "select count(*) cnt from IRIS_REVIEW_IDEA where CHALLENGE_ID = '" + ChallengeId + "' and trim(upper(REVIEW_ROUND)) = '" + Round.Trim().ToUpper() + "'";
                    //ds = OracleHelper.ExecuteDataset(pConn, CommandType.Text, strSql);
                    //if (ds.Tables[0].Rows.Count > 0)
                    //{
                    //    Idea_Count_R1 = ds.Tables[0].Rows[0]["cnt"].ToString();
                    //    Idea_Count_R2 = ds.Tables[0].Rows[0]["cnt"].ToString();
                    //}

                    strSql = "select * from IRIS_WINNING_IDEAS where CHALLENGE_ID = '" + ChallengeId + "' and trim(upper(ROUND)) = '" + Round.Trim().ToUpper() + "' order by RANK";
                    ds = OracleHelper.ExecuteDataset(pConn, CommandType.Text, strSql);
                    if (ds.Tables.Count > 0)
                    {
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            string table = string.Empty;
                            table = "<table style=\"font-family: Calibri;\" cellspacing=\"0\" cellspadding=\"0\">";
                            table = table + "<tr><th style=\"border: 1px solid #ddd;line-height: 1.42857;padding: 8px;vertical-align: top;\">Idea ID</th><th style=\"border: 1px solid #ddd;line-height: 1.42857;padding: 8px;vertical-align: top;\">Idea Name</th><th style=\"border: 1px solid #ddd;line-height: 1.42857;padding: 8px;vertical-align: top;\">Rank</th></tr>";

                            string sCurrentIdeaID = "";
                            string sPreviousIdeaID = "";

                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {

                                if (dr["IDEA_NAME"].ToString() != "")
                                {
                                    sCurrentIdeaID = dr["IDEA_NAME"].ToString().ToUpper().Trim();
                                    if (sCurrentIdeaID != sPreviousIdeaID)
                                    {
                                        sPreviousIdeaID = "";
                                    }

                                    if (sPreviousIdeaID == "")
                                    {
                                        table = table + "<tr>";
                                        table = table + "<td style=\"border: 1px solid #ddd;line-height: 1.42857;padding: 8px;vertical-align: top;\">" + dr["IDEA_ID"].ToString() + "</td>";
                                        table = table + "<td style=\"border: 1px solid #ddd;line-height: 1.42857;padding: 8px;vertical-align: top;\">" + dr["IDEA_NAME"].ToString() + "</td>";
                                        table = table + "<td style=\"border: 1px solid #ddd;line-height: 1.42857;padding: 8px;vertical-align: top;\">" + dr["RANK"].ToString() + "</td>";
                                        table = table + "</tr>";
                                        sPreviousIdeaID = dr["IDEA_NAME"].ToString().ToUpper().Trim();
                                    }
                                }
                            }
                            table = table + "</table>";
                            Winning_Idea_Table_R1 = table;
                            Winning_Idea_Table_R2 = table;
                        }
                        else
                        {
                            Winning_Idea_Table_R1 = "0";
                            Winning_Idea_Table_R2 = "0";
                        }
                    }
                    else
                    {
                        Winning_Idea_Table_R1 = "0";
                        Winning_Idea_Table_R2 = "0";
                    }

                    strSql = "select LISTAGG(E.EMPNAME, ',') within group (order by E.EMPNAME) EMPNAME from IRIS_ADD_MENTOR M left join IRIS_EMPLOYEE_MASTER E on E.EMPCODE = M.MENTOR_ID  where CHALLENGE_ID =  '" + ChallengeId + "' and trim(upper(REVIEW_ROUND)) = 'ROUND1'";
                    ds = OracleHelper.ExecuteDataset(pConn, CommandType.Text, strSql);
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        Mentor_List_R1 = ds.Tables[0].Rows[0]["EMPNAME"].ToString();
                    }

                    strSql = "select LISTAGG(E.EMPNAME, ',') within group (order by E.EMPNAME) EMPNAME from IRIS_ADD_MENTOR M left join IRIS_EMPLOYEE_MASTER E on E.EMPCODE = M.MENTOR_ID  where CHALLENGE_ID =  '" + ChallengeId + "' and trim(upper(REVIEW_ROUND)) = 'ROUND2'";
                    ds = OracleHelper.ExecuteDataset(pConn, CommandType.Text, strSql);
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        Mentor_List_R2 = ds.Tables[0].Rows[0]["EMPNAME"].ToString();
                    }

                    strSql = "select count(distinct idea_id) cnt from IRIS_REVIEW_IDEA where CHALLENGE_ID =  '" + ChallengeId + "' and trim(upper(REVIEW_ROUND)) = 'ROUND2'";
                    ds = OracleHelper.ExecuteDataset(pConn, CommandType.Text, strSql);
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        Shorlisted_Idea_Count_R2 = ds.Tables[0].Rows[0]["cnt"].ToString();
                    }
                }

                strSql = " select M.REVIEW_ROUND, P.PANEL_NAME, LISTAGG(E.EMPNAME, ',') within group (order by E.EMPNAME) EMPNAME from IRIS_POST_CHALLENGE C " +
                         " left join IRIS_ADD_MENTOR M on M.CHALLENGE_ID = C.CHALLENGE_ID " +
                         " left join IRIS_ADD_PANEL P on P.CHALLENGE_ID = C.CHALLENGE_ID and P.PANEL_ID = M.PANEL_ID " +
                         " left join IRIS_EMPLOYEE_MASTER E on M.MENTOR_ID = E.EMPCODE " +
                         " where C.CHALLENGE_ID = '" + ChallengeId + "'  " +
                         " group by  M.REVIEW_ROUND, P.PANEL_NAME " +
                         " order by M.REVIEW_ROUND, P.PANEL_NAME";
                ds = OracleHelper.ExecuteDataset(pConn, CommandType.Text, strSql);
                if (ds.Tables.Count > 0)
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        string table = string.Empty;
                        table = "<table  style=\"font-family: Calibri;\" cellspacing=\"0\" cellspadding=\"0\">";
                        table = table + "<tr><th style=\"border: 1px solid #ddd;line-height: 1.42857;padding: 8px;vertical-align: top;\">Round</th><th style=\"border: 1px solid #ddd;line-height: 1.42857;padding: 8px;vertical-align: top;\">Panel Name</th><th style=\"border: 1px solid #ddd;line-height: 1.42857;padding: 8px;vertical-align: top;\">Mentor</th></tr>";
                        foreach (DataRow dr in ds.Tables[0].Rows)
                        {
                            if (dr["REVIEW_ROUND"].ToString() != "")
                            {
                                table = table + "<tr>";
                                table = table + "<td style=\"border: 1px solid #ddd;line-height: 1.42857;padding: 8px;vertical-align: top;\">" + dr["REVIEW_ROUND"].ToString() + "</td>";
                                table = table + "<td style=\"border: 1px solid #ddd;line-height: 1.42857;padding: 8px;vertical-align: top;\">" + dr["PANEL_NAME"].ToString() + "</td>";
                                table = table + "<td style=\"border: 1px solid #ddd;line-height: 1.42857;padding: 8px;vertical-align: top;\">" + dr["EMPNAME"].ToString() + "</td>";
                                table = table + "</tr>";
                            }
                        }
                        table = table + "</table>";
                        Challenge_Details_Table = table;
                    }
                }
            }

            body = body.Replace("{Ideator_Name}", Ideator_Name);//*****************Done
            body = body.Replace("{Idea_Name}", Idea_Name);//*****************Done
            body = body.Replace("{Idea_ID}", Idea_ID);//*****************Done
            body = body.Replace("{Challenge_Name}", Challenge_Name);//*****************Done
            body = body.Replace("{Challenge_ID}", Challenge_ID);//*****************Done
            body = body.Replace("{Challenge_Owner_Name}", Challenge_Owner_Name);//*****************Done
            body = body.Replace("{Mentor_Name}", Mentor_Name);//*****************Done
            body = body.Replace("{Last_Date_Review_R1}", Last_Date_Review_R1);//*****************Done
            body = body.Replace("{Last_Date_Review_R2}", Last_Date_Review_R2);//*****************Done
            body = body.Replace("{Idea_Count_R1}", Idea_Count_R1);//*****************Done
            body = body.Replace("{Idea_Count_R2}", Idea_Count_R2);//*****************Done
            body = body.Replace("{Winning_Idea_Table_R1}", Winning_Idea_Table_R1);//*****************Done
            body = body.Replace("{Winning_Idea_Table_R2}", Winning_Idea_Table_R2);//*****************Done
            body = body.Replace("{Mentor_List_R1}", Mentor_List_R1);//*****************Done
            body = body.Replace("{Mentor_List_R2}", Mentor_List_R2);//*****************Done
            body = body.Replace("{Shorlisted_Idea_Count_R2}", Shorlisted_Idea_Count_R2);//*****************Done
            body = body.Replace("{Challenge_Details_Table}", Challenge_Details_Table);//*****************Done

            return body;
        }
        catch (Exception ex)
        {
            throw ex;
            //HttpContext.Current.Session["Error"] = ex.ToString();
            //HttpContext.Current.Response.Redirect("~/ErrorPage.aspx");
        }
        finally
        {
            pConn.Close();
        }
    }

    public static void TriggerMail(int status, string User_ID, string TestMailSub, string TestMailBody)
    {
        string strConnectionString = getConnectionString();
        OracleConnection pConn = new OracleConnection();
        pConn = OpenConnetion();
        pConn.Open();
        try
        {
            string strFrom = string.Empty; string strTo = string.Empty; string strCC = string.Empty; string strBcc = string.Empty; string strSubject = string.Empty; string strBody = string.Empty;
            //Start - Bhakti - 12 sept 2019 - Periodic WAPT fix
            //string adminMailID = ConfigurationManager.AppSettings["AdminEmail"].ToString();
            //string CcMailID = ConfigurationManager.AppSettings["CCEmail"].ToString();
            //string BccMailID = ConfigurationManager.AppSettings["BCCEmail"].ToString();
            ////string SystemMailID = ConfigurationManager.AppSettings["SystemEmail"].ToString();


            DataLayer.IRIS_DataLayer objData = new DataLayer.IRIS_DataLayer();
            string adminMailID = objData.GetKeyFromDB("AdminEmail");
            string CcMailID = objData.GetKeyFromDB("CCEmail");
            string BccMailID = objData.GetKeyFromDB("BCCEmail"); 
            //End - Bhakti - 12 sept 2019 - Periodic WAPT fix

            string strSql = string.Empty;
            strSql = "select * from IRIS_EMPLOYEE_MASTER where EMPCODE = '" + User_ID + "'";
            DataSet dsMail = OracleHelper.ExecuteDataset(pConn, CommandType.Text, strSql);

            if (ConfigurationManager.AppSettings["SendMail"].ToString() == "N")
            {
                strFrom = adminMailID;
                strTo = adminMailID;
                strCC = CcMailID;
                strBcc = BccMailID;
                strSubject = TestMailSub;
                strBody = TestMailBody;
            }
            else
            {
                //Start - Bhakti - 12 sept 2019 - Periodic WAPT fix
                //strFrom = ConfigurationManager.AppSettings["SystemEmail"].ToString();
                strFrom = objData.GetKeyFromDB("SystemEmail");
                //End - Bhakti - 12 sept 2019 - Periodic WAPT fix

                if (dsMail.Tables[0].Rows.Count > 0)
                {
                    strTo = dsMail.Tables[0].Rows[0]["EMAILID"].ToString();
                    strCC = CcMailID;
                    strBcc = BccMailID;
                    strSubject = TestMailSub;
                    strBody = TestMailBody;
                    //CommonFunctions.GetMailSubjectNBody(status, out strSubject, out strBody);
                }
                else
                {
                    bool CheckElse = false;
                    if (!string.IsNullOrEmpty(Convert.ToString(HttpContext.Current.Session["User_Type"])))
                    {
                        if (HttpContext.Current.Session["User_Type"].ToString().ToUpper() == "UNIVERSITY")
                        {
                            strSql = "select USER_EMAIL_ID as EMAILID from IRIS_UNIVERSITY_USERS where USER_ID = " + User_ID + "";
                            dsMail = OracleHelper.ExecuteDataset(pConn, CommandType.Text, strSql);
                            if (dsMail.Tables[0].Rows.Count > 0)
                            {
                                if (ConfigurationManager.AppSettings["SendMailUniv"].ToString() == "N")
                                {
                                    strTo = adminMailID;
                                }
                                else
                                {
                                    strTo = dsMail.Tables[0].Rows[0]["EMAILID"].ToString();
                                }
                                strCC = CcMailID;
                                strBcc = BccMailID;
                                strSubject = TestMailSub;
                                strBody = TestMailBody;
                            }
                            else
                                CheckElse = true;
                        }
                        else
                            CheckElse = true;
                    }
                    else
                        CheckElse = true;

                    if (CheckElse)
                    {
                        strTo = adminMailID;
                        strCC = CcMailID;
                        strBcc = BccMailID;
                        strSubject = TestMailSub;
                        strBody = TestMailBody;
                        strSubject = "No records found for Employee ID : " + HttpContext.Current.Session["UserId"].ToString();
                        strBody = "No records found for Employee ID : " + HttpContext.Current.Session["UserId"].ToString();
                    }
                }
            }

            MailMessage mmMessage = new MailMessage();
            mmMessage.IsBodyHtml = true;

            AlternateView view = AlternateView.CreateAlternateViewFromString(strBody, null, MediaTypeNames.Text.Html);

            LinkedResource pic = new LinkedResource(HttpContext.Current.Server.MapPath("~/images/Banner_Mail.png"));
            pic.ContentId = "12345";

            LinkedResource pic2 = new LinkedResource(HttpContext.Current.Server.MapPath("~/images/Banner_mail_Foot.png"));
            pic2.ContentId = "123456";

            view.LinkedResources.Add(pic);
            view.LinkedResources.Add(pic2);

            mmMessage.AlternateViews.Add(view);

            mmMessage.From = new MailAddress(strFrom);
            mmMessage.CC.Add(new MailAddress(strCC));
            foreach (string str in strBcc.Split(';'))
            {
                mmMessage.Bcc.Add(new MailAddress(str));
            }
            foreach (string str in strTo.Split(';'))
            {
                mmMessage.To.Add(new MailAddress(str));
            }
            mmMessage.Body = strBody;
            mmMessage.Subject = strSubject;
            SmtpClient smtp = new SmtpClient();

            //Start - Bhakti - 12 sept 2019 - Periodic WAPT fix
            //smtp.Port = Convert.ToInt16(ConfigurationManager.AppSettings["PortMail"].ToString());
            //smtp.Host = ConfigurationManager.AppSettings["HostMail"].ToString();
            smtp.Port = Convert.ToInt16(objData.GetKeyFromDB("PortMail"));
            smtp.Host = objData.GetKeyFromDB("HostMail");
            //End - Bhakti - 12 sept 2019 - Periodic WAPT fix

            smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtp.Send(mmMessage);

            //LOGGER FUNTIONALITY - SJ
            new Logger.LogWriter(301, Convert.ToDateTime(System.DateTime.Now.ToShortDateString()), HttpContext.Current.Session["UserId"].ToString(), "Mail Sent", Convert.ToInt32(0), "Status ID", Convert.ToInt32(status));
            //END - LOGGER FUNTIONALITY - SJ

        }
        catch (Exception ex)
        {
            throw ex;
            //HttpContext.Current.Session["Error"] = ex.ToString();
            //HttpContext.Current.Response.Redirect("~/ErrorPage.aspx");
        }
        finally
        {
            pConn.Close();
        }
    }
    public static void TriggerMail(int status, string User_ID, string TestMailSub, string TestMailBody, string CcMailIDs)
    {
        string strConnectionString = getConnectionString();
        OracleConnection pConn = new OracleConnection();
        pConn = OpenConnetion();
        pConn.Open();
        try
        {
            string strFrom = string.Empty; string strTo = string.Empty; string strCC = string.Empty; string strBcc = string.Empty; string strSubject = string.Empty; string strBody = string.Empty;
            //Start - Bhakti - 12 sept 2019 - Periodic WAPT fix
            //string adminMailID = ConfigurationManager.AppSettings["AdminEmail"].ToString();
            //string CcMailID = ConfigurationManager.AppSettings["CCEmail"].ToString();

            //if (ConfigurationManager.AppSettings["SendMail"].ToString() != "N")
            //{
            //    if (CcMailIDs == "")
            //    {
            //        CcMailID = ConfigurationManager.AppSettings["CCEmail"].ToString();
            //    }
            //    else
            //    {
            //        CcMailID = ConfigurationManager.AppSettings["CCEmail"].ToString() + ";" + CcMailIDs;
            //    }
            //}

            //string BccMailID = ConfigurationManager.AppSettings["BCCEmail"].ToString();
            ////string SystemMailID = ConfigurationManager.AppSettings["SystemEmail"].ToString();

            DataLayer.IRIS_DataLayer objData = new DataLayer.IRIS_DataLayer();
            string adminMailID = objData.GetKeyFromDB("AdminEmail"); ;
            string CcMailID = objData.GetKeyFromDB("CCEmail"); ;
            if (ConfigurationManager.AppSettings["SendMail"].ToString() != "N")
            {
                if (CcMailIDs == "")
                {
                    CcMailID = objData.GetKeyFromDB("CCEmail");
                }
                else
                {
                    CcMailID = objData.GetKeyFromDB("CCEmail") + ";" + CcMailIDs;
                }
            }
            string BccMailID = objData.GetKeyFromDB("BCCEmail"); 
            //End - Bhakti - 12 sept 2019 - Periodic WAPT fix

            string strSql = "select * from IRIS_EMPLOYEE_MASTER where EMPCODE = '" + User_ID + "'";
            DataSet dsMail = OracleHelper.ExecuteDataset(pConn, CommandType.Text, strSql);

            if (ConfigurationManager.AppSettings["SendMail"].ToString() == "N")
            {
                strFrom = adminMailID;
                strTo = adminMailID;
                strCC = CcMailID;
                strBcc = BccMailID;
                strSubject = TestMailSub;
                strBody = TestMailBody;
            }
            else
            {
                //Start - Bhakti - 12 sept 2019 - Periodic WAPT fix
                //strFrom = ConfigurationManager.AppSettings["SystemEmail"].ToString();
                strFrom = objData.GetKeyFromDB("SystemEmail");
                //End - Bhakti - 12 sept 2019 - Periodic WAPT fix

                if (dsMail.Tables[0].Rows.Count > 0)
                {
                    strTo = dsMail.Tables[0].Rows[0]["EMAILID"].ToString();
                    strCC = CcMailID;
                    strBcc = BccMailID;
                    strSubject = TestMailSub;
                    strBody = TestMailBody;
                    //CommonFunctions.GetMailSubjectNBody(status, out strSubject, out strBody);
                }
                else
                {
                    bool CheckElse = false;
                    if (!string.IsNullOrEmpty(Convert.ToString(HttpContext.Current.Session["User_Type"])))
                    {
                        if (HttpContext.Current.Session["User_Type"].ToString().ToUpper() == "UNIVERSITY")
                        {
                            strSql = "select USER_EMAIL_ID as EMAILID from IRIS_UNIVERSITY_USERS where USER_ID = " + User_ID + "";
                            dsMail = OracleHelper.ExecuteDataset(pConn, CommandType.Text, strSql);
                            if (dsMail.Tables[0].Rows.Count > 0)
                            {
                                if (ConfigurationManager.AppSettings["SendMailUniv"].ToString() == "N")
                                {
                                    strTo = adminMailID;
                                }
                                else
                                {
                                    strTo = dsMail.Tables[0].Rows[0]["EMAILID"].ToString();
                                }
                                strCC = CcMailID;
                                strBcc = BccMailID;
                                strSubject = TestMailSub;
                                strBody = TestMailBody;
                            }
                            else
                                CheckElse = true;
                        }
                        else
                            CheckElse = true;
                    }
                    else
                        CheckElse = true;

                    if (CheckElse)
                    {
                        strTo = adminMailID;
                        strCC = CcMailID;
                        strBcc = BccMailID;
                        strSubject = TestMailSub;
                        strBody = TestMailBody;
                        strSubject = "No records found for Employee ID : " + HttpContext.Current.Session["UserId"].ToString();
                        strBody = "No records found for Employee ID : " + HttpContext.Current.Session["UserId"].ToString();
                    }
                }
            }

            MailMessage mmMessage = new MailMessage();
            mmMessage.IsBodyHtml = true;

            AlternateView view = AlternateView.CreateAlternateViewFromString(strBody, null, MediaTypeNames.Text.Html);

            LinkedResource pic = new LinkedResource(HttpContext.Current.Server.MapPath("~/images/Banner_Mail.png"));
            pic.ContentId = "12345";

            LinkedResource pic2 = new LinkedResource(HttpContext.Current.Server.MapPath("~/images/Banner_mail_Foot.png"));
            pic2.ContentId = "123456";

            view.LinkedResources.Add(pic);
            view.LinkedResources.Add(pic2);

            mmMessage.AlternateViews.Add(view);

            mmMessage.From = new MailAddress(strFrom);
            foreach (string str in strCC.Split(';'))
            {
                mmMessage.CC.Add(new MailAddress(str));
            }
            foreach (string str in strBcc.Split(';'))
            {
                mmMessage.Bcc.Add(new MailAddress(str));
            }
            foreach (string str in strTo.Split(';'))
            {
                mmMessage.To.Add(new MailAddress(str));
            }
            mmMessage.Body = strBody;
            mmMessage.Subject = strSubject;
            SmtpClient smtp = new SmtpClient();

            //Start - Bhakti - 12 sept 2019 - Periodic WAPT fix
            //smtp.Port = Convert.ToInt16(ConfigurationManager.AppSettings["PortMail"].ToString());
            //smtp.Host = ConfigurationManager.AppSettings["HostMail"].ToString();
            smtp.Port = Convert.ToInt16(objData.GetKeyFromDB("PortMail"));
            smtp.Host = objData.GetKeyFromDB("HostMail");
            //End - Bhakti - 12 sept 2019 - Periodic WAPT fix

            smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtp.Send(mmMessage);

            //LOGGER FUNTIONALITY - SJ
            new Logger.LogWriter(301, Convert.ToDateTime(System.DateTime.Now.ToShortDateString()), HttpContext.Current.Session["UserId"].ToString(), "Mail Sent", Convert.ToInt32(0), "Status ID", Convert.ToInt32(status));
            //END - LOGGER FUNTIONALITY - SJ

        }
        catch (Exception ex)
        {
            throw ex;
            //HttpContext.Current.Session["Error"] = ex.ToString();
            //HttpContext.Current.Response.Redirect("~/ErrorPage.aspx");
        }
        finally
        {
            pConn.Close();
        }
    }

    public static void FillDropdown(DropDownList DropdownName, DataView SourceTable, string TextField, string ValueField, string DefaultItem, string NoData)
    {
        DropdownName.Items.Clear();
        //if (SourceTable != null)
        //{
        //    if (SourceTable.Table.Rows.Count > 0)
        //    {
        //        DropdownName.DataSource = SourceTable;
        //        DropdownName.DataTextField = TextField;
        //        DropdownName.DataValueField = ValueField;
        //        DropdownName.DataBind();
        //        DropdownName.Items.Insert(0, new ListItem(DefaultItem, "-1"));
        //        return;
        //    }
        //    DropdownName.Items.Insert(0, new ListItem(NoData, "-1"));
        //    return;
        //}
        //DropdownName.Items.Insert(0, new ListItem(NoData, "-1"));
        //return;

        if (SourceTable.Table.Rows.Count > 0)
        {
            DropdownName.DataSource = SourceTable;
            DropdownName.DataTextField = TextField;
            DropdownName.DataValueField = ValueField;
            DropdownName.DataBind();
            //return;
        }
        DropdownName.Items.Insert(0, new ListItem(DefaultItem, " "));

    }


    public static string getConnectionString()
    {
        //string strConnectionString = ConfigurationManager.ConnectionStrings["constr"].ToString();
        string strConnectionString = EnCryptDecrypt.CryptorEngine.Decrypt(ConfigurationManager.ConnectionStrings["ConString"].ToString(), true);
        return strConnectionString;
    }
    //McCain

    public static string getConnectionString1()
    {
        string strConnectionString = ConfigurationManager.ConnectionStrings["constr"].ToString();
        //string strConnectionString = EnCryptDecrypt.CryptorEngine.Decrypt(ConfigurationManager.ConnectionStrings["ConString"].ToString(), true);
        return strConnectionString;
    }

    public static string getUATConnectionString()
    {
        //string strConnectionString = ConfigurationManager.ConnectionStrings["ConString"].ToString();
        string strConnectionString = EnCryptDecrypt.CryptorEngine.Decrypt(ConfigurationManager.ConnectionStrings["ConString"].ToString(), true);
        return strConnectionString;
    }

    public static string getDevConnectionString()
    {
        //string strConnectionString = ConfigurationManager.ConnectionStrings["ConString"].ToString();
        string strConnectionString = EnCryptDecrypt.CryptorEngine.Decrypt(ConfigurationManager.ConnectionStrings["ConString"].ToString(), true);
        return strConnectionString;
    }

    public static DataSet getDataSet(string sProcName)
    {
        string strConnectionString = CommonFunctions.getConnectionString();
        OracleParameter[] oraParamArray;
        oraParamArray = OracleHelperParameterCache.GetSpParameterSet(strConnectionString, sProcName);
        return OracleHelper.ExecuteDataset(strConnectionString, CommandType.StoredProcedure, sProcName, oraParamArray);
    }

    public static DataSet getParamMaster()
    {
        string strConnectionString = CommonFunctions.getConnectionString();
        OracleParameter[] oraParamArray;
        oraParamArray = OracleHelperParameterCache.GetSpParameterSet(strConnectionString, "IRIS_GET_PARAMETERS");
        return OracleHelper.ExecuteDataset(strConnectionString, CommandType.StoredProcedure, "IRIS_GET_PARAMETERS", oraParamArray);
    }

    //commented by Vinayak - 10-Sep-15
    //public static DataSet getDataSetChallengeOtherDetails()
    //{
    //    string strConnectionString = CommonFunctions.getConnectionString();
    //    OracleParameter[] oraParamArray;
    //    oraParamArray = OracleHelperParameterCache.GetSpParameterSet(strConnectionString, "IRIS_GET_CHLNG_OTHER_DETAILS");
    //    oraParamArray[0].Value = Convert.ToInt32(HttpContext.Current.Session["ChallengeId"]);
    //    return OracleHelper.ExecuteDataset(strConnectionString, CommandType.StoredProcedure, "IRIS_GET_CHLNG_OTHER_DETAILS", oraParamArray);

    //}

    //Added by Vinayak - 10-Sep-15
    public static DataSet getDataSetByChallenge(int iChallengeID, string sPROC)
    {
        string strConnectionString = CommonFunctions.getConnectionString();
        OracleParameter[] oraParamArray;
        oraParamArray = OracleHelperParameterCache.GetSpParameterSet(strConnectionString, sPROC);
        oraParamArray[0].Value = iChallengeID;
        return OracleHelper.ExecuteDataset(strConnectionString, CommandType.StoredProcedure, sPROC, oraParamArray);

    }

    public static EmployeeDetails EmployeeDetails(string pEmpcode)
    {
        string strConnectionString = getConnectionString();
        OracleConnection pConn = new OracleConnection();
        pConn = OpenConnetion();
        pConn.Open();

        EmployeeDetails oEmpDetails = new EmployeeDetails();
        string strSql = "select * from SOME_DB_TABLE WHERE EMPCODE='" + pEmpcode + "'";
        DataSet ds = OracleHelper.ExecuteDataset(pConn, CommandType.Text, strSql);
        if (ds.Tables.Count > 0)
        {
            if (ds.Tables[0].Rows.Count > 0)
            {
                oEmpDetails.EmployeeID = ds.Tables[0].Rows[0]["EMPCODE"].ToString();
                oEmpDetails.EmployeeName = ds.Tables[0].Rows[0]["EMPNAME"].ToString();
                oEmpDetails.SupervisorCode = ds.Tables[0].Rows[0]["SUPERVISOR"].ToString();
                oEmpDetails.FunctionCode = ds.Tables[0].Rows[0]["FUNCTIONCODE"].ToString();
                if (!string.IsNullOrEmpty(ds.Tables[0].Rows[0]["ROLE_ID"].ToString()) || !string.IsNullOrEmpty(ds.Tables[0].Rows[0]["DISABLED"].ToString()))
                {
                    oEmpDetails.RoleID = Convert.ToInt32(ds.Tables[0].Rows[0]["ROLE_ID"]);
                    oEmpDetails.UserDisabled = ds.Tables[0].Rows[0]["DISABLED"].ToString();
                }
                else
                {
                    oEmpDetails.RoleID = 0;
                    oEmpDetails.UserDisabled = "Y";
                }
            }
        }

        strSql = "select * from SOME_DB_TABLE where ROLE_ID =" + oEmpDetails.RoleID + "";
        ds = OracleHelper.ExecuteDataset(pConn, CommandType.Text, strSql);
        if (ds.Tables.Count > 0)
        {
            if (ds.Tables[0].Rows.Count > 0)
            {
                if (!string.IsNullOrEmpty(ds.Tables[0].Rows[0]["DISABLED"].ToString()))
                {
                    oEmpDetails.RoleDisabled = ds.Tables[0].Rows[0]["DISABLED"].ToString();
                }
                else
                {
                    oEmpDetails.RoleDisabled = "Y";
                }
            }
        }

        pConn.Close();
        pConn.Dispose();

        return oEmpDetails;
    }

    //added VY - 05-Oct-15
    //modified for validate from database instead of web.config by NP - 03-Mar-16
    public static bool isSuperAdmin(string sEmpID)
    {
        if (isAdmin(sEmpID))
            return true;

        return false;
    }
    //McCain
    public static bool isSuperAdmin1(string sEmpID)
    {
        if (isAdmin1(sEmpID))
            return true;

        return false;
    }

    //McCain
    private static bool isAdmin1(string sEmpID)
    {
        string strSql;
        string strConnectionString = CommonFunctions.getConnectionString1();
        SqlConnection pConn = new SqlConnection();
        pConn = CommonFunctions.OpenConnetion1();
        pConn.Open();
        try
        {
            strSql = "SELECT EMPCODE,EMPNAME,EMPEMAIL FROM iris_admin_master where EMPEMAIL='" + sEmpID + "' ";
            DataSet ds = OracleHelper.ExecuteDataset1(pConn, CommandType.Text, strSql);
            if (ds.Tables[0].Rows.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
                
            
        }
        catch (Exception ex)
        {
            throw ex;
            //HttpContext.Current.Session["Error"] = ex.ToString();
            //HttpContext.Current.Response.Redirect("~/ErrorPage.aspx");
        }
        finally
        {
            pConn.Close();
        }
    }


    private static bool isAdmin(string sEmpID)
    {
        string strSql;
        string strConnectionString = CommonFunctions.getConnectionString();
        OracleConnection pConn = new OracleConnection();
        pConn = CommonFunctions.OpenConnetion();
        pConn.Open();
        try
        {
            strSql = "SELECT EMPCODE,EMPNAME FROM iris_admin_master where EMPCODE='" + sEmpID + "' ";
            DataSet ds = OracleHelper.ExecuteDataset(pConn, CommandType.Text, strSql);
            if (ds.Tables[0].Rows.Count > 0)
                return true;
            return false;
        }
        catch (Exception ex)
        {
            throw ex;
            //HttpContext.Current.Session["Error"] = ex.ToString();
            //HttpContext.Current.Response.Redirect("~/ErrorPage.aspx");
        }
        finally
        {
            pConn.Close();
        }
    }

    


    //added VY - 05-Oxt-15
    public static bool isStringInString(string sMainStringCommaSeparated, string sSubString)
    {
        ArrayList al = new ArrayList();
        al.AddRange(sMainStringCommaSeparated.Split(','));
        if (al.IndexOf(sSubString) > -1)
            return true;

        return false;
    }

    public static string GetRandomNumber()
    {
        RandomNumberGenerator rng = new RNGCryptoServiceProvider();
        byte[] tokenData = new byte[32];
        rng.GetBytes(tokenData);
        return Convert.ToBase64String(tokenData);
    }
}