﻿using System.Web;
using System.Web.SessionState;

namespace WebApplication1
{
    /// <summary>
    /// Summary description for TestingHandler
    /// </summary>
    public class TestingHandler : IHttpHandler, IReadOnlySessionState
    {

        bool IHttpHandler.IsReusable
        {
            get { return false; }
        }

        void IHttpHandler.ProcessRequest(HttpContext context)
        {

            if (context.Session["UserId"] == null)
                context.Response.Redirect("~/login.aspx");

            var filExtension = GettingExtension(context.Request.RawUrl);
            try
            {
                context.Response.ClearContent();
                context.Response.ClearHeaders();
                context.Response.ContentType = ASP.MimeTypes.GetMimeType(filExtension);
                context.Response.AddHeader("Content-Disposition", "attachment");
                context.Response.WriteFile(context.Request.RawUrl);
                context.Response.Flush();
            }
            catch { HttpContext.Current.Response.Write(filExtension); }

        }
        public string GettingExtension(string rawUrl)
        {
            return rawUrl.Substring(rawUrl.LastIndexOf(".", System.StringComparison.Ordinal));
        }
    }
}
