﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OracleClient;
using OraAppBlock;
using System.Data;
using System.IO;
using System.Configuration;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Net.Mail;
using System.Net.Mime;
using System.Net;
using System.Net.Http;

public partial class Modules_Ideas_PostIdea : System.Web.UI.Page
{
    BusinessLayer.IRIS_BusinessLayer objClass1_BL = new BusinessLayer.IRIS_BusinessLayer();  

    string isValidCoIdeator = "N";
    string ideaid = "";
    string updateideaid = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        string path = HttpContext.Current.Request.Url.AbsolutePath;
        //btnSubmit.Visible=false;
        btnapprove.Visible = false;
        btnreject.Visible = false;
        selectchallenge.Visible=false;
        try
        {
            if (!IsPostBack)
            {
                Load_Leadership();
                divrequestid.Visible = false;
                if (Session["UserId"] == null || Convert.ToString(Session["UserId"]) == "")
                {
                    Response.Redirect("~/Login.aspx?r=" + CommonFunctions.GetRandomNumber(), false);
                }
                if (HttpContext.Current.Session["selectedideaid"] != null || Convert.ToString(Session["selectedideaid"]) != "")
                {
                    //btnapprove.Visible = true;
                    //btnreject.Visible = true;
                    ideaid = Session["selectedideaid"].ToString();                     
                    LoadSingleIdea(ideaid);
                }
               
            }
            //txtstartdate.Enabled = false;
            //txtstartdate.Text = DateTime.Now.ToString();
            getRoles();


        }
        catch (Exception ex)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }
        }
        finally
        {
        }
    }

    public void getRoles()
    {
        try
        {
            //string UserId=string.Empty;
            if (Session["UserId"] == null || Convert.ToString(Session["UserId"]) == "")
            {
                Response.Redirect("~/Login.aspx?r=" + CommonFunctions.GetRandomNumber(), false);
            }
            else
            {
                string UserId = Session["UserId"].ToString();
                string Admin = "";
                if (CommonFunctions.isSuperAdmin1(Session["UserId"].ToString()))
                {
                    Admin = Session["UserId"].ToString();
                    HttpContext.Current.Session["normaluser"] = "";
                    HttpContext.Current.Session["normaluser"] = null;
                }
                else
                {
                    HttpContext.Current.Session["normaluser"] = "NU";
                }
                if (UserId == Admin)
                {
                    if (HttpContext.Current.Session["selectedideaid"] != null || Convert.ToString(Session["selectedideaid"]) != "")
                    {
                        btnapprove.Visible = true;
                        btnreject.Visible = true;
                    }
                    else
                    {
                        btnapprove.Visible = false;
                        btnreject.Visible = false;
                    }
                }
                else
                {
                    btnapprove.Visible = false;
                    btnreject.Visible = false;
                }
                if (lbl_status.Text=="Approved")
                {
                    btnapprove.Visible = false;
                    btnreject.Visible = false;
                }
                if (lbl_status.Text == "Rejected")
                {
                    btnapprove.Visible = false;
                    btnreject.Visible = false;
                }

            }



        }
        catch (Exception ex) 
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }
        }
        finally
        {

        }
        
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {


        if (Session["postbackurl"] != null || Convert.ToString(Session["postbackurl"]) != "")
        {
            HttpContext.Current.Session["selectedideaid"] = "";
            HttpContext.Current.Session["selectedideaid"] = null;
            HttpContext.Current.Response.Redirect(Session["postbackurl"].ToString());
        }

        if (Session["selectedideaid"] != null || Convert.ToString(Session["selectedideaid"]) != "")
        {
            if (Session["normaluser"] != null || Convert.ToString(Session["normaluser"]) != "")
            {
                HttpContext.Current.Session["selectedideaid"] = "";
                HttpContext.Current.Session["selectedideaid"] = null;
                HttpContext.Current.Response.Redirect("~/Modules/Ideas/IdeaHome.aspx");
            }
            else
            {
                HttpContext.Current.Session["selectedideaid"] = "";
                HttpContext.Current.Session["selectedideaid"] = null;
                HttpContext.Current.Response.Redirect("~/Modules/AdminSR/IdeaDashBoard.aspx");
            }

        }
        else
        {
            HttpContext.Current.Session["selectedideaid"] = "";
            HttpContext.Current.Session["selectedideaid"] = null;
            HttpContext.Current.Response.Redirect("~/Modules/Ideas/IdeaHome.aspx");
        }

    }
    public void LoadSingleIdea(string ideaid)
    {
        try
        {
            DataSet Ideads = objClass1_BL.GET_IDEA_DETAILS(ideaid);
            DataTable dt = Ideads.Tables[0];
            if (dt.Rows.Count > 0)
            {                
                divrequestid.Visible = true;
                HiddenField1.Value = dt.Rows[0]["IDEA_ID"].ToString();
                lbl_status.Text = dt.Rows[0]["IDEA_STATUS"].ToString();
                idea_id.Text = dt.Rows[0]["IDEA_ID"].ToString();
                HiddenField2.Value = dt.Rows[0]["IDEA_EMPID"].ToString();

                if (dt.Rows[0]["IDEA_STATUS"].ToString() == "602")
                {
                    lbl_status.Text = "Pending";
                    lbl_status.ForeColor = Color.Orange;
                }
                if (dt.Rows[0]["IDEA_STATUS"].ToString() == "601")
                {
                    lbl_status.Text = "Rejected";
                    lbl_status.ForeColor = Color.Red;
                }
                if (dt.Rows[0]["IDEA_STATUS"].ToString() == "600")
                {
                    lbl_status.Text = "Approved";
                    lbl_status.ForeColor = Color.Green;
                    btnapprove.Visible = true;
                    btnreject.Visible = true;
                }
                //string sb_id = dt.Rows[0]["SUB_LEADERSHIP_PRINCIPLE"].ToString();
                txtIdeaName.Text = dt.Rows[0]["IDEA_NAME"].ToString();
                txtContent.Text = dt.Rows[0]["IDEA_DESCRIPTION"].ToString();
                ddllocation.SelectedItem.Text = dt.Rows[0]["LOCATION"].ToString();
                ddlbusinessunit.SelectedItem.Text = dt.Rows[0]["BUSINESS_UNIT"].ToString();
                txtprojectsponser.Text = dt.Rows[0]["PROJECT_SPONSOR"].ToString();
                //txtteammember.Text = dt.Rows[0]["TEAM_MEMBER"].ToString();
                ddlpurpose.SelectedItem.Text = dt.Rows[0]["PURPOSE"].ToString();
                txtstartdate.Text = dt.Rows[0]["START_DATE"].ToString();
                txtEnddate.Text = dt.Rows[0]["END_DATE"].ToString();
                noofpeople.Text = dt.Rows[0]["NO_OF_PEOPLE"].ToString();
                nameofthepeople.Text = dt.Rows[0]["PEOPLE_NAME"].ToString();
                noofexternalpeople.Text = dt.Rows[0]["EXTERNAL_PEOPLE_NAME"].ToString();
                rdldatasource.SelectedValue = dt.Rows[0]["DATA_SOURCE"].ToString();
                //ddlleadership.SelectedItem.Text = dt.Rows[0]["LEADERSHIP_PRINCIPLE"].ToString();                
                //ddlsubleadership.SelectedItem.Text = dt.Rows[0]["SUB_LEADERSHIP_PRINCIPLE"].ToString();
                ddlleadership.SelectedValue = dt.Rows[0]["LEADERSHIP_PRINCIPLE"].ToString();
                Load_Sub_Leadership(dt.Rows[0]["LEADERSHIP_PRINCIPLE"].ToString());
                ddlsubleadership.SelectedValue = dt.Rows[0]["SUB_LEADERSHIP_PRINCIPLE"].ToString();
                ddlChallenge.SelectedValue = dt.Rows[0]["CHALLENGE_ID"].ToString();
                //btnapprove.Visible = true;
                //btnreject.Visible = true;
                clotroldisable();
            }
            else
            {
                divrequestid.Visible = false;
            }
        }
        catch (Exception ex)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }
        }
        finally
        {

        }
    }

    public void clotroldisable()
    {
        txtIdeaName.Enabled = false;
        txtContent.Enabled = false;
        ddllocation.Enabled = false;
        ddlbusinessunit.Enabled = false;
        txtprojectsponser.Enabled = false;
        //txtteammember.Enabled = false;
        ddlpurpose.Enabled = false;
        txtstartdate.Enabled = false;
        txtEnddate.Enabled = false;
        noofpeople.Enabled = false;
        nameofthepeople.Enabled = false;
        noofexternalpeople.Enabled = false;
        rdldatasource.Enabled = false;
        ddlleadership.Enabled = false;
        ddlsubleadership.Enabled = false;
        ddlChallenge.Enabled = false;
        btnSubmit.Visible = false;
        btnCancel.Text = "Back";
        Session["selectedideaid"] = "";
        ideaid = "";
    }

    //GET_Leadership
    private void Load_Leadership()
    {
        try
        {            
            DataSet ds = objClass1_BL.GET_Leadership();
            DataTable dt = ds.Tables[0];
            if (ds.Tables.Count > 0)            {
                if (ds.Tables[0].Rows.Count > 0)
                {
                    ddlleadership.DataSource = ds;
                    ddlleadership.DataTextField = "LP_NAME";
                    ddlleadership.DataValueField = "LP_ID";
                    ddlleadership.DataBind();
                    ddlleadership.Items.Insert(0, new ListItem("-- Select --", "0")); //mccain.
                    //ddlChallenge.Items.Insert(0, new ListItem("-- Select Challenge --", " ")); //modified by vinayak value was zero, now made as space
                }
            }
        }
        catch (Exception ex)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }


        }
        finally
        {
        }
    }

    private void Load_Sub_Leadership(string lp_id)
    {
        try
        {
            DataSet ds = objClass1_BL.GET_Sub_Leadership(lp_id);
            DataTable dt = ds.Tables[0];
            if (ds.Tables.Count > 0)
            {
                if (ds.Tables[0].Rows.Count > 0)
                {
                    ddlsubleadership.DataSource = ds;
                    ddlsubleadership.DataTextField = "SLP_NAME";
                    ddlsubleadership.DataValueField = "SLP_ID";
                    ddlsubleadership.DataBind();
                    ddlsubleadership.Items.Insert(0, new ListItem("-- Select --", "0")); //mccain.
                    //ddlChallenge.Items.Insert(0, new ListItem("-- Select Challenge --", " ")); //modified by vinayak value was zero, now made as space
                }
            }
        }
        catch (Exception ex)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }


        }
        finally
        {
        }
    }


    private void LoadChallenge()
    {
        try
        {
            //set session uid
            //Session["UserId"] = "755065";
            string[] paramarray = new string[3];
            paramarray[0] = Session["UserId"].ToString();
            //if (CommonFunctions.isSuperAdmin(Session["UserId"].ToString()))//mccain
            if (CommonFunctions.isSuperAdmin1(Session["UserId"].ToString()))
            {
                paramarray[1] = "Y";
            }
            else
            {
                paramarray[1] = "N";
            }

            if (!string.IsNullOrEmpty(Convert.ToString(Session["User_Type"])))
                paramarray[2] = Session["User_Type"].ToString();
            else
                paramarray[2] = "";

            //DataSet ds = objClass1_BL.IRIS_GET_CHALLENGES_BY_FILTERI(paramarray);//mccain
            DataSet ds = objClass1_BL.IRIS_GET_CHALLENGES_BY_FILTERI1(paramarray);

            DataTable dt = ds.Tables[0];
            if (ds.Tables.Count > 0)
            {
                if (ds.Tables[0].Rows.Count > 0)
                {
                    ddlChallenge.DataSource = ds;
                    ddlChallenge.DataTextField = "CHALLENGE_NAME";
                    ddlChallenge.DataValueField = "CHALLENGE_ID";
                    ddlChallenge.DataBind();
                    ddlChallenge.Items.Insert(0, new ListItem("-- Select Challenge --", "0")); //mccain.
                    //ddlChallenge.Items.Insert(0, new ListItem("-- Select Challenge --", " ")); //modified by vinayak value was zero, now made as space
                }
            }
        }
        catch (Exception ex)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }


        }
        finally
        {
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        btnSubmit.Enabled = false;
        btnCancel.Enabled = false;

        string strExtension = string.Empty;

        try
        {
            //Session["UserId"] = "ajit.rath075@mccain.ca";
            if (ddlChallenge.SelectedValue == null || Convert.ToString(ddlChallenge.SelectedValue) == "")
            {
                ddlChallenge.SelectedValue = "";
            }
            
            string IdeaAlreadyExist = "";            
            IdeaAlreadyExist = objClass1_BL.get_IDEA_NAME1(txtIdeaName.Text, ddlChallenge.SelectedValue);

            if (IdeaAlreadyExist == "")
            {
                //txtteammember.Text
                SaveDataPostIdea(txtIdeaName.Text,
                    txtContent.Text,
                    ddllocation.SelectedItem.Text,
                    ddlbusinessunit.SelectedItem.Text,
                    txtprojectsponser.Text,
                    "Null",
                    ddlpurpose.SelectedItem.Text,
                    txtstartdate.Text,
                    txtEnddate.Text,
                    noofpeople.Text,
                    nameofthepeople.Text,
                    noofexternalpeople.Text,
                    rdldatasource.SelectedValue,
                    ddlleadership.SelectedValue,
                    ddlsubleadership.SelectedValue,
                    "602", ddlChallenge.SelectedValue, Session["UserId"].ToString());
            }
            else
            {
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('Idea with the same name already exist !'); ", true);
            }
        }
        catch (Exception ex)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }
        }
        finally
        {
            btnSubmit.Enabled = true;
            btnCancel.Enabled = true;
        }
    }
    private void SaveDataPostIdea(string pIDEA_NAME, string pIDEA_DESCRIPTION, string pLOCATION, string pBUSINESS_UNIT, string pPROJECT_SPONSOR, string pTEAM_MEMBER, string pPURPOSE, string pSTART_DATE, string pEND_DATE, string pNO_OF_PEOPLE, string pPEOPLE_NAME, string pEXTERNAL_PEOPLE_NAME, string pDATA_SOURCE, string pLEADERSHIP_PRINCIPLE, string pSUB_LEADERSHIP_PRINCIPLE, string pIDEA_STATUS, string pCHALLENGE,string pEMPID)
    {
        try
        {
            DataSet ds = null;
            DataSet ds1 = null;
            DataSet ds2 = null;
            string status = "";
            string strSql = "";
            isValidCoIdeator = "Y";
            string error = string.Empty;
            if (isValidCoIdeator != "N")
            {
                string[] paramarray = new string[21];
                paramarray[0] = pIDEA_NAME;
                paramarray[1] = pIDEA_DESCRIPTION;
                paramarray[2] = pLOCATION;
                paramarray[3] = pBUSINESS_UNIT;
                paramarray[4] = pPROJECT_SPONSOR;
               
                paramarray[5] = pTEAM_MEMBER;
                paramarray[6] = pPURPOSE;
                paramarray[7] = pSTART_DATE;
                paramarray[8] = pEND_DATE;
                paramarray[9] = pNO_OF_PEOPLE;
                paramarray[10] = pPEOPLE_NAME;                
                paramarray[11] = pEXTERNAL_PEOPLE_NAME;
                paramarray[12] = pDATA_SOURCE;
                paramarray[13] = pLEADERSHIP_PRINCIPLE;
                paramarray[14] = pSUB_LEADERSHIP_PRINCIPLE;
                paramarray[15] = pIDEA_STATUS;
                paramarray[16] = pCHALLENGE;
                paramarray[17] = pEMPID;
                int value = objClass1_BL.IRIS_INSERT_POST_IDEA1(paramarray);
                if (value > 0)
                {
                    try
                    {
                        string listemail = nameofthepeople.Text;
                        string main_list = listemail.Replace(" ", string.Empty).Replace(",", ";");

                        int ideaId = value;
                        string ideaname = txtIdeaName.Text;
                        objClass1_BL.Mail_IdeaSubmitted_TheMix(ideaname,ideaId, HttpContext.Current.Session["UserId"].ToString(), "Your Idea is In! Let’s Get Ready to Innovate", "Idea_submission.html", main_list.Trim());
                        string msg = "Your idea has been sent to the admin for approval. You shall be updated about the status via mail.";

                        HttpContext.Current.Session["SuccessMessage"] = msg;
                        HttpContext.Current.Response.Redirect("~/Modules/Message/SuccessMessage.aspx", false);
                    }
                    catch (Exception e) 
                    {
                        string msg = "Your idea has been sent to the admin for approval. Email send fail Contract System Admin!.";
                        HttpContext.Current.Session["SuccessMessage"] = msg;
                        HttpContext.Current.Response.Redirect("~/Modules/Message/SuccessMessage.aspx", false);
                    }                                       

                }
                else
                {
                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('Contract System Admin';", true);
                }
            }

        }
        catch (Exception ex)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }
        }
        finally
        {

        }
    }

   

    protected void btnapprove_Click(object sender, EventArgs e)
    {
        if (HiddenField1.Value != "")
        {
            try
            {
                int getvalue = 0;
                //getvalue = updateapprovedata("600", HiddenField1.Value, getvalue);

                getvalue = objClass1_BL.Update_Idea_Status("600", HiddenField1.Value, getvalue);
                if (getvalue > 0) 
                {
                    try
                    {
                        string listemail = HiddenField2.Value + "," + nameofthepeople.Text;
                        string main_list = listemail.Replace(" ", string.Empty).Replace(",", ";");

                        int ideaId = Convert.ToInt32(HiddenField1.Value);
                        string ideaname = txtIdeaName.Text;
                        objClass1_BL.Mail_IdeaSubmitted_TheMix(ideaname,ideaId, HttpContext.Current.Session["UserId"].ToString(), "Congratulations! Your Idea Has Been Approved!", "Idea_Approved.html", main_list.Trim());
                        
                        HttpContext.Current.Session["SuccessMessage"] = "Idea Approved!! The idea owner shall receive a e-mail informing them that their idea has been approved and a form for them to fill their space allocation requirements.";
                        HttpContext.Current.Response.Redirect("~/Modules/Message/SuccessMessage.aspx", false);
                    }
                    catch (Exception ex) 
                    {
                        HttpContext.Current.Session["SuccessMessage"] = "Idea Approved! Email send fail Contract System Admin!.";
                        HttpContext.Current.Response.Redirect("~/Modules/Message/SuccessMessage.aspx", false);
                    }
                }

               
                //ScriptManager.RegisterStartupScript(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('Idea Approved!! The idea owner shall receive a e-mail informing them that their idea has been approved and a form for them to fill their space allocation requirements'); location.href='PostIdea.aspx';", true);
            }
            catch (Exception ex) 
            {
                if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
                {
                    Session["Error"] = Session["Error"] + ex.ToString();
                }
                else
                {
                    Session["Error"] = ex.ToString();
                    Response.Redirect("~/ErrorPage.aspx");
                }
            }

        }
            
      
    }

   
    protected void btnreject_Click(object sender, EventArgs e)
    {
        if (HiddenField1.Value != "")
        {
            //Rejectidea("601", HiddenField1.Value);
            int getvalue = 0;
            getvalue = objClass1_BL.Update_Idea_Status("601", HiddenField1.Value, getvalue);
            if (getvalue > 0)
            {
                try
                {
                    string listemail = HiddenField2.Value + "," + nameofthepeople.Text;
                    string main_list = listemail.Replace(" ", string.Empty).Replace(",", ";");

                    int ideaId = Convert.ToInt32(HiddenField1.Value);
                    string ideaname = txtIdeaName.Text;
                    objClass1_BL.Mail_IdeaSubmitted_TheMix(ideaname,ideaId, HttpContext.Current.Session["UserId"].ToString(), "Feedback on Your Idea Submission", "Idea_Rejected.html", main_list.Trim());
                    HttpContext.Current.Session["SuccessMessage"] = "Idea Rejected. The idea owner shall receive a e-mail informing them that their idea has been rejected.";
                    HttpContext.Current.Response.Redirect("~/Modules/Message/SuccessMessage.aspx", false);
                }
                catch (Exception ex)
                {
                    HttpContext.Current.Session["SuccessMessage"] = "Idea Rejected. Email send fail Contract System Admin!.";
                    HttpContext.Current.Response.Redirect("~/Modules/Message/SuccessMessage.aspx", false);
                }

                
                //ScriptManager.RegisterStartupScript(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('Idea Rejected. The idea owner shall receive a e-mail informing them that their idea has been rejected.'); location.href='PostIdea.aspx';", true);
            }

        }
    }
    //public void Rejectidea(string status, string ideaid)
    //{
    //    try
    //    {            
    //        //objClass1_BL.Update_Idea_Status(status, ideaid);
    //    }
    //    catch (Exception ex)
    //    {
    //        if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
    //        {
    //            Session["Error"] = Session["Error"] + ex.ToString();
    //        }
    //        else
    //        {
    //            Session["Error"] = ex.ToString();
    //            Response.Redirect("~/ErrorPage.aspx");
    //        }
    //    }       

    //}


    //public static void TriggerMail(string User_ID, string TestMailSub, string TestMailBody)
    //{
    //    BusinessLayer.IRIS_BusinessLayer objClass1_BL1 = new BusinessLayer.IRIS_BusinessLayer();

    //    try
    //    {
    //        string strFrom; string strTo; string strCC; string strBcc; string strSubject; string strBody;

    //        DataLayer.IRIS_DataLayer objData = new DataLayer.IRIS_DataLayer();
    //        string adminMailID = objData.GetKeyFromDB1("AdminEmail");
    //        string CcMailID = objData.GetKeyFromDB1("CCEmail");
    //        string BccMailID = objData.GetKeyFromDB1("BCCEmail");

    //        //DataSet dsMail = objClass1_BL1.getExternalUserDetails(User_ID);

    //        //if (ConfigurationManager.AppSettings["SendMailUniv"].ToString() == "N")
    //        //{
    //        //    strFrom = adminMailID;
    //        //    strTo = adminMailID;
    //        //    strCC = CcMailID;
    //        //    strBcc = BccMailID;
    //        //    strSubject = TestMailSub;
    //        //    strBody = TestMailBody;
    //        //}
    //        //else
    //        //{
    //        //    strFrom = objData.GetKeyFromDB("SystemEmail");

    //        //    if (dsMail.Tables[0].Rows.Count > 0)
    //        //    {
    //        //        strTo = "AR00755065@techmahindra.com;rath.ajit075@gmail.com";//dsMail.Tables[0].Rows[0]["USER_EMAIL_ID"].ToString();
    //        //        strCC = CcMailID;
    //        //        strBcc = BccMailID;
    //        //        strSubject = TestMailSub;
    //        //        strBody = TestMailBody;
    //        //    }
    //        //    else
    //        //    {
    //        //        strTo = adminMailID;
    //        //        strCC = CcMailID;
    //        //        strBcc = BccMailID;
    //        //        strSubject = TestMailSub;
    //        //        strBody = TestMailBody;
    //        //        strSubject = "No records found for Employee ID : " + HttpContext.Current.Session["UserId"].ToString();
    //        //        strBody = "No records found for Employee ID : " + HttpContext.Current.Session["UserId"].ToString();
    //        //    }
    //        //}

    //        strFrom = adminMailID;
    //        strTo = "AR00755065@techmahindra.com;rath.ajit075@gmail.com";
    //        strCC = CcMailID;
    //        strBcc = BccMailID;
    //        strSubject = TestMailSub;
    //        strBody = TestMailBody;

    //        MailMessage mmMessage = new MailMessage();
    //        mmMessage.IsBodyHtml = true;

    //        AlternateView view = AlternateView.CreateAlternateViewFromString(strBody, null, MediaTypeNames.Text.Html);

    //        LinkedResource pic = new LinkedResource(HttpContext.Current.Server.MapPath("~/images/Banner_Mail.png"));
    //        pic.ContentId = "12345";

    //        LinkedResource pic2 = new LinkedResource(HttpContext.Current.Server.MapPath("~/images/Banner_mail_Foot.png"));
    //        pic2.ContentId = "123456";

    //        view.LinkedResources.Add(pic);
    //        view.LinkedResources.Add(pic2);

    //        mmMessage.AlternateViews.Add(view);

    //        mmMessage.From = new MailAddress(strFrom);
    //        mmMessage.CC.Add(new MailAddress(strCC));
    //        foreach (string str in strBcc.Split(';'))
    //        {
    //            mmMessage.Bcc.Add(new MailAddress(str));
    //        }
    //        foreach (string str in strTo.Split(';'))
    //        {
    //            mmMessage.To.Add(new MailAddress(str));
    //        }
    //        mmMessage.Body = strBody;
    //        mmMessage.Subject = strSubject;
    //        SmtpClient smtp = new SmtpClient();

            

    //        smtp.Port = Convert.ToInt16(objData.GetKeyFromDB1("PortMail"));
    //        smtp.Host = objData.GetKeyFromDB1("HostMail");

    //        //smtp.Credentials = new NetworkCredential(strFrom, "cbwf bwlt frwh wvth");
    //        //smtp.EnableSsl = true;
    //        //smtp.UseDefaultCredentials = false;

    //        smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
    //        smtp.Send(mmMessage);

    //    }
    //    catch (Exception ex)
    //    {
    //        throw ex;

    //    }
    //    finally
    //    {

    //    }
    //}

    //public static string MailBody(string HTMLPageName, string User_ID, string User_Name)
    //{
    //    string body = string.Empty;
    //    string IRISSiteName = string.Empty;
    //    string SystemEmail = string.Empty;

    //    BusinessLayer.IRIS_BusinessLayer objClass1_BL1 = new BusinessLayer.IRIS_BusinessLayer();

    //    try
    //    {
    //        IRISSiteName = ConfigurationManager.AppSettings["IRISSiteURL"].ToString();

    //        //string activationCode = Guid.NewGuid().ToString();

    //        //objClass1_BL1.UPDATE_ExternalUser(User_ID, activationCode);

    //        //activationCode = EnCryptDecrypt.CryptorEngine.Encrypt(activationCode + ":" + User_ID.ToString(), true);

    //        //DataSet ds = new DataSet();

    //        using (StreamReader reader = new StreamReader(HttpContext.Current.Server.MapPath("~/Mail_Formats/" + HTMLPageName + "")))
    //        {
    //            body = reader.ReadToEnd();
    //        }

    //        //string Link = "<a href = '" + HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority) + HttpContext.Current.Request.ApplicationPath + "" + "/User_Activation.aspx?ActivationCode=" + activationCode + "'>Click here to activate your account.</a>";

    //        body = body.Replace("{IRISSiteName}", IRISSiteName);
    //        body = body.Replace("{User_Name}", User_Name);//*****************Done
    //        //body = body.Replace("{URL}", Link);//*****************Done

    //        return body;
    //    }
    //    catch (Exception ex)
    //    {
    //        throw ex;
    //    }
    //    finally
    //    {
    //    }
    //}

    protected void ddlleadership_SelectedIndexChanged(object sender, EventArgs e)
    {
        Load_Sub_Leadership(ddlleadership.SelectedItem.Value);
    }
}
