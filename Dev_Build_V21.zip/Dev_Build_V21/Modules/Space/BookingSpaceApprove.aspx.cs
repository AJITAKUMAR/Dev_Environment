﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Modules_Space_BookingSpaceApprove : System.Web.UI.Page
{
    BusinessLayer.IRIS_BusinessLayer objClass1_BL = new BusinessLayer.IRIS_BusinessLayer();
    string activityid = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        lblerrmessage.Visible = false;
        spacestatus.Visible = false;
        try
        {
            if (Session["UserId"] == null || Convert.ToString(Session["UserId"]) == "")
            {
                Response.Redirect("~/Login.aspx?r=" + CommonFunctions.GetRandomNumber(), false);
            }
            if (!IsPostBack)
            {
                activityid = Session["RequestSpacebookingId"].ToString();
                LoadActivityDetails();

            }
        }
        catch (Exception ex)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
                Session["Error"] = Session["Error"] + ex.ToString();
            else
                Session["Error"] = ex.ToString();
            Response.Redirect("~/ErrorPage.aspx");
        }
        finally
        {

        }

        txtactvityid.Enabled = false;
        txtactivatyname.Enabled = false;
    }


    public void LoadActivityDetails()
    {
        try
        {
            //string EmpId = Session["UserId"].ToString();
            activityid = Session["RequestSpacebookingId"].ToString();            
            DataSet ds = objClass1_BL.GET_SPACE_BOOKING_DETAILS(activityid);
            if (ds.Tables[0].Rows.Count > 0)
            {
                HiddenField1.Value= ds.Tables[0].Rows[0]["SB_ID"].ToString();
                txtactvityid.Text = ds.Tables[0].Rows[0]["ACTIVITY_ID"].ToString();
                txtactivatyname.Text = ds.Tables[0].Rows[0]["ACTIVITY_NAME"].ToString();
                txttypeofactivity.Text= ds.Tables[0].Rows[0]["ACTIVITY_TYPE"].ToString();
                txtContent.Text= ds.Tables[0].Rows[0]["DESCRIPTION"].ToString();
                ddlspacebooking.SelectedItem.Text= ds.Tables[0].Rows[0]["SPACE"].ToString();
                txtstartdate.Text = ds.Tables[0].Rows[0]["START_DATE"].ToString();
                txtEnddate.Text= ds.Tables[0].Rows[0]["END_DATE"].ToString();
                txtparticipants.Text= ds.Tables[0].Rows[0]["PARTICIPANTS"].ToString();
                lblstatusresult.Text = ds.Tables[0].Rows[0]["STATUS"].ToString();
                string geteventid = ds.Tables[0].Rows[0]["EVENT_ID"].ToString();
                
                if (lblstatusresult.Text == "600")
                {
                    lblstatusresult.Text = "Space Allocated";
                    lblstatusresult.ForeColor = Color.Green;
                    spacestatus.Visible = true;
                    btnapprove.Visible = false;
                    btnreject.Visible = false;
                }
                if (lblstatusresult.Text == "601")
                {
                    lblstatusresult.Text = "Space Allocation Rejected";
                    lblstatusresult.ForeColor = Color.Green;
                    spacestatus.Visible = true;
                    btnapprove.Visible = false;
                    btnreject.Visible = false;
                }
                if (geteventid != "")
                {
                    btnapprove.Visible = false;
                    btnreject.Visible = false;
                }
                
                controldisable();

            }
        }
        catch (Exception ex)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }

        }
        finally
        {

        }
    }


    public void controldisable()
    {
        txtactvityid.Enabled = false;
        txtactivatyname.Enabled = false;
        txttypeofactivity.Enabled = false;
        txtContent.Enabled = false;
        ddlspacebooking.Enabled = false;
        txtstartdate.Enabled = false;
        txtEnddate.Enabled = false;
        txtparticipants.Enabled = false;
    }

    public void clearcontrol()
    {
        txttypeofactivity.Text = "";
        txtContent.Text = "";
        txtstartdate.Text = "";
        txtEnddate.Text = "";
        ddlspacebooking.SelectedValue = "0";
        txtparticipants.Text = "";
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        if (Session["postbackurl"] != null || Convert.ToString(Session["postbackurl"]) != "")
        {
            Session["selectedideaid"] = "";
            Session["RequestSpaceId"] = "";
            Session["RequestSpacebookingId"] = "";
            Session["selectedideaid"] = null;
            Session["RequestSpaceId"] = null;
            Session["RequestSpacebookingId"] = null;
            HttpContext.Current.Response.Redirect(Session["postbackurl"].ToString());
            
        }
        
    }

    

    protected void btnapprove_Click(object sender, EventArgs e)
    {
        if (HiddenField1.Value != "")
        {

            //updateapprovedata("600", HiddenField1.Value);
            int getid = 0;
            getid = objClass1_BL.Update_SpaceBooking_Status("600", HiddenField1.Value, getid);
            if (getid > 0)
            {
                try
                {
                    DataSet ds = objClass1_BL.GET_IIDEADETAILS(txtactvityid.Text);
                    DataTable dt = ds.Tables[0];
                    string requesteremail = dt.Rows[0]["IDEA_EMPID"].ToString();
                    string listemail = dt.Rows[0]["PEOPLE_NAME"].ToString();
                    listemail = HttpContext.Current.Session["UserId"].ToString() + "," + listemail;

                    string main_list = listemail.Replace(" ", string.Empty).Replace(",", ";");

                    int ideaId = Convert.ToInt32(HiddenField1.Value);
                    string activity_name = dt.Rows[0]["IDEA_NAME"].ToString();

                    objClass1_BL.Mail_IdeaSubmitted_TheMix(activity_name, ideaId, requesteremail, "Space Secured! Your Idea is Moving Forward!", "Space_Allocation_Approval.html", main_list.Trim());
                    HttpContext.Current.Session["SuccessMessage"] = "Booking Space Approved!.";
                    HttpContext.Current.Response.Redirect("~/Modules/Message/SuccessMessage.aspx", false);
                }
                catch (Exception ex)
                {
                    HttpContext.Current.Session["SuccessMessage"] = "Booking Space Approved.! Email send fail Contract System Admin.!";
                    HttpContext.Current.Response.Redirect("~/Modules/Message/SuccessMessage.aspx", false);
                }

            }
            //ScriptManager.RegisterStartupScript(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('Idea Approved!! The idea owner shall receive a e-mail informing them that their idea has been approved and a form for them to fill their space allocation requirements'); location.href='PostIdea.aspx';", true);
        }
    }
    //public void updateapprovedata(string status, string id)
    //{
    //    try
    //    {
    //        int getid = 0;
    //        getid = objClass1_BL.Update_SpaceBooking_Status(status, id, getid);
    //        if (getid > 0)
    //        {
    //            try
    //            {
    //                //string listemail = nameofthepeople.Text;
    //                //string main_list = listemail.Replace(" ", string.Empty).Replace(",", ";");

    //                //int ideaId = value;
    //                //objClass1_BL.Mail_IdeaSubmitted_TheMix(ideaId, HttpContext.Current.Session["UserId"].ToString(), "TheMix : Your Idea is submitted.!", "Idea_submission.html", main_list.Trim());
    //            }
    //            catch (Exception ex) 
    //            { 
    //            }
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
    //        {
    //            Session["Error"] = Session["Error"] + ex.ToString();
    //        }
    //        else
    //        {
    //            Session["Error"] = ex.ToString();
    //            Response.Redirect("~/ErrorPage.aspx");
    //        }
    //    }


    //}

    protected void btnreject_Click(object sender, EventArgs e)
    {
        if (HiddenField1.Value != "")
        {
            //Rejectidea("601", HiddenField1.Value);
            int getid = 0;
            getid = objClass1_BL.Update_SpaceBooking_Status("601", HiddenField1.Value, getid);
            if (getid > 0)
            {
                try
                {
                    DataSet ds = objClass1_BL.GET_IIDEADETAILS(txtactvityid.Text);
                    DataTable dt = ds.Tables[0];
                    string requesteremail = dt.Rows[0]["IDEA_EMPID"].ToString();
                    string listemail = dt.Rows[0]["PEOPLE_NAME"].ToString();
                    listemail = HttpContext.Current.Session["UserId"].ToString() + "," + listemail;
                    string main_list = listemail.Replace(" ", string.Empty).Replace(",", ";");

                    int ideaId = Convert.ToInt32(HiddenField1.Value);
                    string activity_name = dt.Rows[0]["IDEA_NAME"].ToString();

                    objClass1_BL.Mail_IdeaSubmitted_TheMix(activity_name, ideaId, requesteremail, "The Mix : Your Space Booking is Rejected.!", "Space_Allocation_Rejected.html", main_list.Trim());
                    HttpContext.Current.Session["SuccessMessage"] = "Booking Space Rejected !.";
                    HttpContext.Current.Response.Redirect("~/Modules/Message/SuccessMessage.aspx", false);
                }
                catch (Exception ex)
                {
                    HttpContext.Current.Session["SuccessMessage"] = "Booking Space Rejected !. Email send fail Contract System Admin.!";
                    HttpContext.Current.Response.Redirect("~/Modules/Message/SuccessMessage.aspx", false);
                }

            }            
            //ScriptManager.RegisterStartupScript(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('Idea Rejected. The idea owner shall receive a e-mail informing them that their idea has been rejected.'); location.href='PostIdea.aspx';", true);
        }
    }
    public void Rejectidea(string status, string id)
    {
        try
        {
            //objClass1_BL.Update_SpaceBooking_Status(status, id);
        }
        catch (Exception ex)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }
        }

    }
}