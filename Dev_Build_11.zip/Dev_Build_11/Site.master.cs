﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayer;
using System.Text;
using System.Data.OracleClient;
using System.Data;
using System.Data.Common;
using OraAppBlock;
using System.Configuration;
using System.IO;
using System.Security.Principal;
using System.Runtime.InteropServices;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Net;
using BusinessLayer;
using System.Web.Security;



public partial class SiteMaster : System.Web.UI.MasterPage
{
    //Start - 13th Nov  2017 - Bhakti
    BusinessLayer.IRIS_BusinessLayer objClass1_BL = new BusinessLayer.IRIS_BusinessLayer();
    //End - 13th Nov 2017 - Bhakti

    string LoggedUser;
    const int LOGON32_PROVIDER_DEFAULT = 0;
    const int LOGON32_LOGON_NEW_CREDENTIALS = 9;
    const int SECURITY_IMPERSONATION_LEVEL = 2;
    private const string AntiXsrfTokenKey = "__AntiXsrfToken";
    private const string AntiXsrfUserNameKey = "__AntiXsrfUserName";
    private string _antiXsrfTokenValue;

    protected void Page_Init(object sender, EventArgs e)
    
    {
        // The code below helps to protect against XSRF attacks
        var requestCookie = Request.Cookies[AntiXsrfTokenKey];
        Guid requestCookieGuidValue;        
        if (requestCookie != null && Guid.TryParse(requestCookie.Value, out requestCookieGuidValue))
        {
            // Use the Anti-XSRF token from the cookie
            _antiXsrfTokenValue = requestCookie.Value;
            Page.ViewStateUserKey = _antiXsrfTokenValue;
        }
        else
        {
            // Generate a new Anti-XSRF token and save to the cookie
            _antiXsrfTokenValue = Guid.NewGuid().ToString("N");
            Page.ViewStateUserKey = _antiXsrfTokenValue;

            var responseCookie = new HttpCookie(AntiXsrfTokenKey)
            {
                HttpOnly = true,
                Value = _antiXsrfTokenValue
            };
            if (FormsAuthentication.RequireSSL && Request.IsSecureConnection)
            {
                responseCookie.Secure = true;
            }
            Response.Cookies.Set(responseCookie);
        }

        Page.PreLoad += master_Page_PreLoad;
    }
    protected void master_Page_PreLoad(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            // Set Anti-XSRF token
            ViewState[AntiXsrfTokenKey] = Page.ViewStateUserKey;
            ViewState[AntiXsrfUserNameKey] = Context.User.Identity.Name ?? String.Empty;
        }
        else
        {
            // Validate the Anti-XSRF token
            if ((string)ViewState[AntiXsrfTokenKey] != _antiXsrfTokenValue
                || (string)ViewState[AntiXsrfUserNameKey] != (Context.User.Identity.Name ?? String.Empty))
            {
                throw new InvalidOperationException("Validation of Anti-XSRF token failed.");
            }
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {       
        try
        {
            LoadSideBarStyle();
            Page.Header.DataBind();
            if (Session["UserId"] == null || Convert.ToString(Session["UserId"]) == "")
            {
                Response.Redirect("~/Login.aspx?r=" + CommonFunctions.GetRandomNumber(), false);
            }
            if (!IsPostBack)
            {

                getRoles();

            }
        }
        catch (Exception ex)
        {
            if (string.IsNullOrEmpty(Convert.ToString(Session["UserId"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }

        }
        finally
        {

        }


    }

    

    #region Loading User Image
    private void GetProfileImage()
    {
        if (Session["LanID"] != null)
        {
            string CompleteImagePath = string.Empty;
            string[] arrResult = new string[5];
            string strDomain = "";
            int j = 0;
            arrResult[0] = Session["LanID"].ToString();

            //Start - Bhakti - 12 sept 2019 - Periodic WAPT fix
            //CompleteImagePath = ConfigurationManager.AppSettings["UserImagePath"].ToString() + arrResult[0] + "_LThumb.jpg";
            DataLayer.IRIS_DataLayer objData = new DataLayer.IRIS_DataLayer();
            CompleteImagePath = objData.GetKeyFromDB("UserImagePath") + arrResult[0] + "_LThumb.jpg";
            //End - Bhakti - 12 sept 2019 - Periodic WAPT fix

            try
            {
                var client = new WebClient();
                //ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };
                client.UseDefaultCredentials = true;
                byte[] data = client.DownloadData(CompleteImagePath);
                using (MemoryStream mem = new MemoryStream(data))
                {
                    System.Drawing.Image i = System.Drawing.Image.FromStream(mem);
                    Size s = new Size(170, 170);
                    i = resizeImage(i, s);

                    //Response.Buffer = true;
                    //Response.Charset = "";
                    //Response.Cache.SetCacheability(HttpCacheability.NoCache);
                    //Response.ContentType = "image/jpeg";
                    //Response.BinaryWrite(imageToByteArray(i));
                    //Response.Flush();
                    //imgUser.Src = "data:image/jpeg;base64," + System.Convert.ToBase64String(imageToByteArray(i), Base64FormattingOptions.None);
                }
            }
            catch (Exception ex)
            {
                CompleteImagePath = Server.MapPath("~/images/user.png");
                using (FileStream filestream = new FileStream(CompleteImagePath, FileMode.Open, FileAccess.Read))
                {

                    //imgUser.Src = "data:image/jpeg;base64," + System.Convert.ToBase64String(GetBytes(filestream), Base64FormattingOptions.None);
                }
            }
        }
    }

    public byte[] imageToByteArray(System.Drawing.Image imageIn)
    {
        MemoryStream ms = new MemoryStream();
        imageIn.Save(ms, System.Drawing.Imaging.ImageFormat.Gif);
        return ms.ToArray();
    }

    private static System.Drawing.Image resizeImage(System.Drawing.Image imgToResize, Size size)
    {
        int sourceWidth = imgToResize.Width;
        int sourceHeight = imgToResize.Height;

        float nPercent = 0;
        float nPercentW = 0;
        float nPercentH = 0;

        nPercentW = ((float)size.Width / (float)sourceWidth);
        nPercentH = ((float)size.Height / (float)sourceHeight);

        if (nPercentH < nPercentW)
            nPercent = nPercentH;
        else
            nPercent = nPercentW;

        int destWidth = (int)(sourceWidth * nPercent);
        int destHeight = (int)(sourceHeight * nPercent);

        Bitmap b = new Bitmap(destWidth, destHeight);
        Graphics g = Graphics.FromImage((System.Drawing.Image)b);
        g.InterpolationMode = InterpolationMode.HighQualityBicubic;

        g.DrawImage(imgToResize, 0, 0, destWidth, destHeight);
        g.Dispose();

        return (System.Drawing.Image)b;
    }
    //Added method for loading user image by NP00365439 on 20 Aug 2015
    protected void GetImage()
    {
        string CompleteImagePath = string.Empty;
        String EmpID = Convert.ToString(Session["UserId"]);

        //Start - Bhakti - 12 sept 2019 - Periodic WAPT fix
        //DirectoryInfo dir = new DirectoryInfo(ConfigurationManager.AppSettings["UserImagePath"].ToString());
        DataLayer.IRIS_DataLayer objData = new DataLayer.IRIS_DataLayer();
        DirectoryInfo dir = new DirectoryInfo(objData.GetKeyFromDB("UserImagePath"));
        //End - Bhakti - 12 sept 2019 - Periodic WAPT fix

        FileInfo[] SearchFiles = dir.GetFiles(EmpID + ".jpg", SearchOption.TopDirectoryOnly);

        if (SearchFiles.Length == 1)
        {
            CompleteImagePath = SearchFiles[0].FullName;
        }
        else if (SearchFiles.Length == 0)
        {
            CompleteImagePath = Server.MapPath("~/images/user.png");
        }
        if (!string.IsNullOrEmpty(CompleteImagePath))
        {
            using (FileStream filestream = new FileStream(CompleteImagePath, FileMode.Open, FileAccess.Read))
            {

                //imgUser.Src = "data:image/jpeg;base64," + System.Convert.ToBase64String(GetBytes(filestream), Base64FormattingOptions.None);
            }
        }


    }
    protected byte[] GetBytes(FileStream filestream)
    {
        using (MemoryStream ms = new MemoryStream())
        {
            filestream.CopyTo(ms);
            return ms.ToArray();
        }
    }
    [DllImport("advapi32.dll", SetLastError = true)]
    private static extern bool LogonUser(string lpszUsername, string lpszDomain, string lpszPassword, int dwLogonType, int dwLogonProvider, ref IntPtr phToken);
    [DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    public extern static bool DuplicateToken(IntPtr existingTokenHandle, int impersonationLevel, ref IntPtr duplicateTokenHandle);
    [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    private static extern bool CloseHandle(IntPtr handle);
    [DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    public static extern bool RevertToSelf();
    [DllImport("userenv.dll", SetLastError = true, CharSet = CharSet.Auto)]
    public static extern bool LoadUserProfile(IntPtr hToken, ref ProfileInfo lpProfileInfo);

    [DllImport("Userenv.dll", CallingConvention =
        CallingConvention.Winapi, SetLastError = true, CharSet = CharSet.Auto)]
    public static extern bool UnloadUserProfile
        (IntPtr hToken, IntPtr lpProfileInfo);

    [DllImport("ole32.dll")]
    public static extern int CoInitializeSecurity(IntPtr pVoid, int
        cAuthSvc, IntPtr asAuthSvc, IntPtr pReserved1, RpcAuthnLevel level,
        RpcImpLevel impers, IntPtr pAuthList, EoAuthnCap dwCapabilities, IntPtr
        pReserved3);

    [StructLayout(LayoutKind.Sequential)]
    public struct ProfileInfo
    {
        ///
        /// Specifies the size of the structure, in bytes.
        ///
        public int dwSize;

        ///
        /// This member can be one of the following flags: 
        /// PI_NOUI or PI_APPLYPOLICY
        ///
        public int dwFlags;

        ///
        /// Pointer to the name of the user.
        /// This member is used as the base name of the directory 
        /// in which to store a new profile.
        ///
        public string lpUserName;

        ///
        /// Pointer to the roaming user profile path.
        /// If the user does not have a roaming profile, this member can be NULL.
        ///
        public string lpProfilePath;

        ///
        /// Pointer to the default user profile path. This member can be NULL.
        ///
        public string lpDefaultPath;

        ///
        /// Pointer to the name of the validating domain controller, in NetBIOS format.
        /// If this member is NULL, the Windows NT 4.0-style policy will not be applied.
        ///
        public string lpServerName;

        ///
        /// Pointer to the path of the Windows NT 4.0-style policy file. 
        /// This member can be NULL.
        ///
        public string lpPolicyPath;

        ///
        /// Handle to the HKEY_CURRENT_USER registry key.
        ///
        public IntPtr hProfile;
    }

    public enum RpcAuthnLevel
    {
        Default = 0,
        None = 1,
        Connect = 2,
        Call = 3,
        Pkt = 4,
        PktIntegrity = 5,
        PktPrivacy = 6
    }

    public enum RpcImpLevel
    {
        Default = 0,
        Anonymous = 1,
        Identify = 2,
        Impersonate = 3,
        Delegate = 4
    }

    public enum EoAuthnCap
    {
        None = 0x00,
        MutualAuth = 0x01,
        StaticCloaking = 0x20,
        DynamicCloaking = 0x40,
        AnyAuthority = 0x80,
        MakeFullSIC = 0x100,
        Default = 0x800,
        SecureRefs = 0x02,
        AccessControl = 0x04,
        AppID = 0x08,
        Dynamic = 0x10,
        RequireFullSIC = 0x200,
        AutoImpersonate = 0x400,
        NoCustomMarshal = 0x2000,
        DisableAAA = 0x1000
    }

    public void RunOperationAsUser(Action operation, string userName, string domain, string password)
    {
        IntPtr token = IntPtr.Zero;
        IntPtr dupToken = IntPtr.Zero;

        //Impersonate the user
        if (LogonUser(userName, domain, password, LOGON32_LOGON_NEW_CREDENTIALS, LOGON32_PROVIDER_DEFAULT, ref token))
        {
            if (DuplicateToken(token, SECURITY_IMPERSONATION_LEVEL, ref dupToken))
            {

                WindowsIdentity newIdentity = new WindowsIdentity(dupToken);
                WindowsImpersonationContext impersonatedUser = newIdentity.Impersonate();

                int retCode = CoInitializeSecurity(IntPtr.Zero, -1, IntPtr.Zero, IntPtr.Zero,
                    RpcAuthnLevel.PktPrivacy, RpcImpLevel.Impersonate, IntPtr.Zero, EoAuthnCap.DynamicCloaking, IntPtr.Zero);

                if (impersonatedUser != null)
                {
                    var username = WindowsIdentity.GetCurrent(TokenAccessLevels.MaximumAllowed).Name;
                    var sid = WindowsIdentity.GetCurrent(TokenAccessLevels.MaximumAllowed).User.Value;

                    ProfileInfo profileInfo = new ProfileInfo();
                    profileInfo.dwSize = Marshal.SizeOf(profileInfo);
                    profileInfo.lpUserName = userName;
                    profileInfo.dwFlags = 1;

                    Boolean loadSuccess = LoadUserProfile(dupToken, ref profileInfo);
                }

                operation();

                impersonatedUser.Undo();
            }
        }
        if (token != IntPtr.Zero)
        {
            CloseHandle(token);
        }
        if (dupToken != IntPtr.Zero)
        {
            try
            {
                CloseHandle(token);
            }
            catch
            { }
        }
    }
    #endregion

    //Event added by Vinayak on 21 oct 2015 for textchange event.
    
    public void LoadSideBarStyle()
    {
        try
        {
            string url = HttpContext.Current.Request.Url.AbsoluteUri;
            string path = HttpContext.Current.Request.Url.AbsolutePath;
            string host = HttpContext.Current.Request.Url.Host;
            if (path == "/HomePage.aspx")
            {                
                div_welcomemix.InnerText = "Welcome to the";                
                div_mccain.InnerText = "McCain Innovation Xchange";                
                span_dot.InnerText = ".";
            }
            if (path == "/AboutMix.aspx")
            {
                div_spaceallocation.Attributes.Add("style", "position: relative;right: 1040px;top: 0px;");
                div_welcomemix.InnerText = "Know";
                div_welcomemix.Attributes.Add("style", "top: 30px;");
                div_mccain.InnerText = "About the Mix";
                div_mccain.Attributes.Add("style", "left: 65px;");
                span_dot.InnerText = ".";
                span_dot.Attributes.Add("style", "left: 275px;");                
            }
            if (path == "/Wayofworking.aspx")
            {
                div_welcomemix.InnerText = "Welcome to the";
                div_mccain.InnerText = "McCain Innovation Xchange";
                span_dot.InnerText = ".";
            }
            if (path == "/FAQs.aspx")
            {
                div_welcomemix.InnerText = "Frequently Asked Questions";
                div_mccain.InnerText = "McCain Innovation Xchange";
                span_dot.InnerText = ".";
            }
           
            if (path == "/Help.aspx")
            {
                //div_spaceallocation.Attributes.Add("style", "top: 0px;");
                div_welcomemix.InnerText = "Need ";
                div_welcomemix.Attributes.Add("style", "right: 365px;top: 30px;");
                div_mccain.InnerText = "Help";
                div_mccain.Attributes.Add("style", "right: 300px;");
                span_dot.InnerText = "?";
                span_dot.Attributes.Add("style", "left: -230px;");
            }
            if (path == "/Modules/Ideas/PostIdea.aspx")
            {
                if (Session["selectedideaid"] != null || Convert.ToString(Session["selectedideaid"]) != "")
                {
                    //lblheaderstatus.Text = "Idea Information";
                }
                else
                {
                    //lblheaderstatus.Text = "Post Idea";
                }
                div_spaceallocation.Attributes.Add("style", "position: relative;right: 1095px;top: 0px;");
                div_welcomemix.InnerText = "Post";
                div_welcomemix.Attributes.Add("style", "top: 30px;");
                div_mccain.InnerText = "Your Ideas";
                div_mccain.Attributes.Add("style", "left: 55px;");
                span_dot.InnerText = ".";
                span_dot.Attributes.Add("style", "left: 210px;");


            }
            else if (path == "/Modules/Ideas/IdeaHome.aspx")
            {
                clearSeeeion();
                div_spaceallocation.Attributes.Add("style", "position: relative;right: 1095px;top: 0px;");
                div_welcomemix.InnerText = "Submit";
                div_welcomemix.Attributes.Add("style", "top: 30px;");
                div_mccain.InnerText = "Your Ideas";
                div_mccain.Attributes.Add("style", "left: 85px;");
                span_dot.InnerText = ".";
                span_dot.Attributes.Add("style", "left: 240px;");
                //lblheaderstatus.Text = "These are the innovative ideas which McCain associates can post to implement a change in business as usual or to provide innovative<br/> ideas for different products.";
                //lblheaderstatus.Attributes.Add("style", "color: #000;font-family: 'Red Hat Display';font-size: 25px;font-style: normal;font-weight: 900;line-height: normal;");
                //A2.Attributes.Add("style", "background-color:#FFFF;border-top-left-radius: 20%;border-bottom-left-radius: 20%;margin-left: 0px;color: #000;text-align: center;font-family: Montserrat;font-size: 46.487px;font-style: normal;font-weight: 600;line-height: normal;");
            }
            else if(path== "/Modules/Ideas/ViewMyIdea.aspx")
            {
                div_spaceallocation.Attributes.Add("style", "position: relative;right: 1115px;top: 0px;");
                div_welcomemix.InnerText = "View";
                div_welcomemix.Attributes.Add("style", "top: 30px;");
                div_mccain.InnerText = "All Ideas";
                div_mccain.Attributes.Add("style", "left: 60px;");
                span_dot.InnerText = ".";
                span_dot.Attributes.Add("style", "left: 185px;");
                //lblheaderstatus.Text = "View Ideas";
                //A2.Attributes.Add("style", "background-color:#FFFF;border-top-left-radius: 20%;border-bottom-left-radius: 20%;margin-left: 0px;color: #000;text-align: center;font-family: Montserrat;font-size: 46.487px;font-style: normal;font-weight: 600;line-height: normal;");
            }
            else if (path == "/Modules/Ideas/ViewMyIdeas.aspx")
            {
                div_spaceallocation.Attributes.Add("style", "position: relative;right: 1090px;top: 0px;");
                div_welcomemix.InnerText = "View";
                div_welcomemix.Attributes.Add("style", "top: 30px;");
                div_mccain.InnerText = "Your Ideas";
                div_mccain.Attributes.Add("style", "left: 55px;");
                span_dot.InnerText = ".";
                span_dot.Attributes.Add("style", "left: 210px;");
                //lblheaderstatus.Text = "My Ideas";
                //A2.Attributes.Add("style", "background-color:#FFFF;border-top-left-radius: 20%;border-bottom-left-radius: 20%;margin-left: 0px;color: #000;text-align: center;font-family: Montserrat;font-size: 46.487px;font-style: normal;font-weight: 600;line-height: normal;");
            }
            if (path == "/Modules/Events/EventHome.aspx")
            {
                clearSeeeion();
                div_spaceallocation.Attributes.Add("style", "position: relative;right: 1140px;top: 0px;");
                div_welcomemix.InnerText = "Check";
                div_welcomemix.Attributes.Add("style", "top: 30px;");
                div_mccain.InnerText = "Events";
                div_mccain.Attributes.Add("style", "left: 75px;");
                span_dot.InnerText = ".";
                span_dot.Attributes.Add("style", "left: 180px;");
            }
            if (path == "/Modules/Events/PostEvents.aspx")
            {
                if (Session["selectedideaid"] != null || Convert.ToString(Session["selectedideaid"]) != "")
                {
                    //lblheaderstatus.Text = "Event Information";
                }
                else
                {
                    //lblheaderstatus.Text = "Request Event";
                }
                div_spaceallocation.Attributes.Add("style", "position: relative;right: 1095px;top: 0px;");
                div_welcomemix.InnerText = "Post";
                div_welcomemix.Attributes.Add("style", "top: 30px;");
                div_mccain.InnerText = "Your Event";
                div_mccain.Attributes.Add("style", "left: 55px;");
                span_dot.InnerText = ".";
                span_dot.Attributes.Add("style", "left: 215px;");
            }
            if (path == "/Modules/Events/viewevent.aspx")
            {
                div_spaceallocation.Attributes.Add("style", "position: relative;right: 1140px;top: 0px;");
                div_welcomemix.InnerText = "View";
                div_welcomemix.Attributes.Add("style", "top: 30px;");
                div_mccain.InnerText = "Events";
                div_mccain.Attributes.Add("style", "left: 55px;");
                span_dot.InnerText = ".";
                span_dot.Attributes.Add("style", "left: 160px;");
            }
            if (path == "/Modules/Events/YourEvent.aspx")
            {
                div_spaceallocation.Attributes.Add("style", "position: relative;right: 1140px;top: 0px;");
                div_welcomemix.InnerText = "Your";
                div_welcomemix.Attributes.Add("style", "top: 30px;");
                div_mccain.InnerText = "Events";
                div_mccain.Attributes.Add("style", "left: 55px;");
                span_dot.InnerText = ".";
                span_dot.Attributes.Add("style", "left: 160px;");
            }
            
            if (path == "/Modules/Space/BookingSpace.aspx")
            {

            }
            if (path == "/Modules/Challenges/ChallengeHome.aspx")
            {
                clearSeeeion();
                div_spaceallocation.Attributes.Add("style", "position: relative;right: 1090px;top: 0px;");
                div_welcomemix.InnerText = "View";
                div_welcomemix.Attributes.Add("style", "top: 30px;");
                div_mccain.InnerText = "Challenges";
                div_mccain.Attributes.Add("style", "left: 60px;");
                span_dot.InnerText = ".";
                span_dot.Attributes.Add("style", "left: 225px;");
            }
            if (path == "/Modules/Challenges/ChallengeHomeNew.aspx")
            {
                clearSeeeion();
                div_spaceallocation.Attributes.Add("style", "position: relative;right: 1090px;top: 0px;");
                div_welcomemix.InnerText = "View";
                div_welcomemix.Attributes.Add("style", "top: 30px;");
                div_mccain.InnerText = "Challenges";
                div_mccain.Attributes.Add("style", "left: 60px;");
                span_dot.InnerText = ".";
                span_dot.Attributes.Add("style", "left: 225px;");

            }
            if (path == "/Modules/Challenges/PostChallengeNew.aspx")
            {
                clearSeeeion();
                div_spaceallocation.Attributes.Add("style", "position: relative;right: 1090px;top: 0px;");
                div_welcomemix.InnerText = "Post";
                div_welcomemix.Attributes.Add("style", "top: 30px;");
                div_mccain.InnerText = "Challenge";
                div_mccain.Attributes.Add("style", "left: 55px;");
                span_dot.InnerText = ".";
                span_dot.Attributes.Add("style", "left: 205px;");
            }
            if (path == "/Modules/Challenges/ViewUpcomingchallenge.aspx")
            {
                clearSeeeion();
                div_spaceallocation.Attributes.Add("style", "position: relative;right: 1090px;top: 0px;");
                div_welcomemix.InnerText = "View";
                div_welcomemix.Attributes.Add("style", "top: 30px;");
                div_mccain.InnerText = "Challenges";
                div_mccain.Attributes.Add("style", "left: 60px;");
                span_dot.InnerText = ".";
                span_dot.Attributes.Add("style", "left: 225px;");
            }
            if (path == "/Modules/Challenges/ViewPastchallenge.aspx")
            {
                clearSeeeion();
                div_spaceallocation.Attributes.Add("style", "position: relative;right: 1090px;top: 0px;");
                div_welcomemix.InnerText = "View";
                div_welcomemix.Attributes.Add("style", "top: 30px;");
                div_mccain.InnerText = "Challenges";
                div_mccain.Attributes.Add("style", "left: 60px;");
                span_dot.InnerText = ".";
                span_dot.Attributes.Add("style", "left: 225px;");
            }
            if (path == "/Modules/Challenges/ViewAllchallenges.aspx")
            {
                clearSeeeion();
                div_spaceallocation.Attributes.Add("style", "position: relative;right: 1090px;top: 0px;");
                div_welcomemix.InnerText = "View";
                div_welcomemix.Attributes.Add("style", "top: 30px;");
                div_mccain.InnerText = "Challenges";
                div_mccain.Attributes.Add("style", "left: 60px;");
                span_dot.InnerText = ".";
                span_dot.Attributes.Add("style", "left: 225px;");
            }
            if (path == "/Modules/AdminSR/IdeaDashBoard.aspx")
            {
                clearSeeeion();
                //lblheaderstatus.Text = "View DashBoard";
                //A4.Attributes.Add("style", "background-color:#FFF;border-top-left-radius: 25%;border-bottom-left-radius: 25%;margin-left: 1px;color: #000;text-align: center;font-family: Montserrat;font-size: 46.487px;font-style: normal;font-weight: 600;line-height: normal;");
            }
            if (path == "/Modules/AdminSR/EventDashboard.aspx")
            {
                clearSeeeion();
                //lblheaderstatus.Text = "View DashBoard";
                //A4.Attributes.Add("style", "background-color:#FFF;border-top-left-radius: 25%;border-bottom-left-radius: 25%;margin-left: 1px;color: #000;text-align: center;font-family: Montserrat;font-size: 46.487px;font-style: normal;font-weight: 600;line-height: normal;");
            }
            if (path == "/Modules/AdminSR/ChallengeDashboard.aspx")
            {
                clearSeeeion();
                //lblheaderstatus.Text = "View DashBoard";
                //A4.Attributes.Add("style", "background-color:#FFF;border-top-left-radius: 25%;border-bottom-left-radius: 25%;margin-left: 1px;color: #000;text-align: center;font-family: Montserrat;font-size: 46.487px;font-style: normal;font-weight: 600;line-height: normal;");
            }
            if (path == "/Modules/AdminSR/SpaceallocationDashboard.aspx")
            {
                clearSeeeion();
                //lblheaderstatus.Text = "View DashBoard";
                //A4.Attributes.Add("style", "background-color:#FFF;border-top-left-radius: 25%;border-bottom-left-radius: 25%;margin-left: 1px;color: #000;text-align: center;font-family: Montserrat;font-size: 46.487px;font-style: normal;font-weight: 600;line-height: normal;");
            }
        }
        catch (Exception ex) 
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }

        }
        finally
        {

        }
    }
    public void getRoles()
    {
        try
        {            
            if (Session["UserId"] == null || Convert.ToString(Session["UserId"]) == "")
            {
                Response.Redirect("~/Login.aspx?r=" + CommonFunctions.GetRandomNumber(), false);
            }
            else
            {
                string UserId = Session["UserId"].ToString();
                string Admin = "";
                if (CommonFunctions.isSuperAdmin1(Session["UserId"].ToString()))
                {
                    Admin = Session["UserId"].ToString();
                }

                if (UserId == Admin)
                {
                    //div_ideas.Visible = true;
                    //div_events.Visible = true;
                    //div_challenge.Visible = true;
                    //div_dashboard.Visible = true;
                }
                else
                {
                    //div_ideas.Visible = true;
                    //div_events.Visible = true;
                    //div_challenge.Visible = true;
                    //div_dashboard.Visible = false;
                }
            }
            //if (Session["UserId"] != null || Convert.ToString(Session["UserId"]) != "")
            //{
            //    UserId = Session["UserId"].ToString();
            //}


            
        }
        catch (Exception ex)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }

        }
        finally
        {
        }
        
    }
    


    //protected void lnkBtnLgOut_Click(object sender, EventArgs e)
    //{
    //    HttpContext.Current.Session["UserId"] = "";
    //    Session.Clear();
    //    Session.Abandon();
    //    Session.RemoveAll();

    //    HttpContext.Current.Session.Clear();
    //    HttpContext.Current.Session.RemoveAll();
    //    HttpContext.Current.Session.Abandon();

    //    FormsAuthentication.SignOut();
    //    Response.Redirect("~/Login.aspx");
        
    //}

    public void clearSeeeion()
    {
        HttpContext.Current.Session["normaluser"] = "";
        HttpContext.Current.Session["normaluser"] = null;
        HttpContext.Current.Session["postbackurl"] = "";
        HttpContext.Current.Session["postbackurl"] = null;
        HttpContext.Current.Session["RequestPath"] = "";
        HttpContext.Current.Session["RequestPath"] = null;
        HttpContext.Current.Session["SuccessMessage"] = "";
        HttpContext.Current.Session["SuccessMessage"] = null;
        HttpContext.Current.Session["selectedideaid"] = "";
        HttpContext.Current.Session["selectedideaid"] = null;
    }








    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        HttpContext.Current.Session["UserId"] = "";
        HttpContext.Current.Session["UserId"] = null;
        Session.Clear();
        Session.Abandon();
        Session.RemoveAll();

        HttpContext.Current.Session.Clear();
        HttpContext.Current.Session.RemoveAll();
        HttpContext.Current.Session.Abandon();

        FormsAuthentication.SignOut();
        Response.Redirect("~/Login.aspx");
    }
}
