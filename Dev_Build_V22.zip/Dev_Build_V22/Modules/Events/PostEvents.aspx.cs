﻿using AjaxControlToolkit.HTMLEditor.ToolbarButton;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Modules_Events_PostEvents : System.Web.UI.Page
{
    string Flag = "";
    int EventId;
    string Eventtype = string.Empty;
    BusinessLayer.IRIS_BusinessLayer objClass1_BL = new BusinessLayer.IRIS_BusinessLayer();
    string path = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        path = HttpContext.Current.Request.Url.AbsolutePath;
        btnspacerequest.Visible = false;
        btnapprove.Visible = false;
        btnreject.Visible = false;
        divrequestid.Visible = false;
        lstBoxTest.Visible = true;
        txtaccessoryitem.Visible = false;
        if (Session["UserId"] == null || Convert.ToString(Session["UserId"]) == "")
        {
            Response.Redirect("~/Login.aspx?r=" + CommonFunctions.GetRandomNumber(), false);
        }
        if (Request.QueryString["ChlId"] != null)
        {
            EventId = int.Parse(Request.QueryString["ChlId"].ToString());            
        }
        if (!IsPostBack)
        {
            Session["EventRequestPath"] = "";
            Session["EventRequestPath"] = null;
            if (Session["selectedideaid"] != null || Convert.ToString(Session["selectedideaid"]) != "")
            {                
                HiddenField1.Value = Session["selectedideaid"].ToString();
            }

            PopulateData();
        }
        getRoles();
        




    }

    public void getRoles()
    {
        try
        {
            //string UserId=string.Empty;
            if (Session["UserId"] == null || Convert.ToString(Session["UserId"]) == "")
            {
                Response.Redirect("~/Login.aspx?r=" + CommonFunctions.GetRandomNumber(), false);
            }
            else
            {
                string UserId = Session["UserId"].ToString();
                string Admin = "";
                if (CommonFunctions.isSuperAdmin1(Session["UserId"].ToString()))
                {
                    Admin = Session["UserId"].ToString();
                    HttpContext.Current.Session["normaluser"] = "";
                    HttpContext.Current.Session["normaluser"] = null;
                }
                else
                {
                    HttpContext.Current.Session["normaluser"] = "NU";
                }
                if (UserId == Admin)
                {
                    if (Request.QueryString["ChlId"] != null)
                    {
                        EventId = int.Parse(Request.QueryString["ChlId"].ToString());
                        HttpContext.Current.Session["selectedideaid"] = EventId;
                    }

                    if (HttpContext.Current.Session["selectedideaid"] != null || Convert.ToString(Session["selectedideaid"]) != "")
                    {
                        if (lbl_status.Text == "Approved")
                        {
                            btnapprove.Visible = false;
                            btnreject.Visible = false;
                        }
                        else
                        {
                            btnapprove.Visible = true;
                            btnreject.Visible = true;
                        }
                        
                    }
                    else
                    {
                        
                        btnapprove.Visible = false;
                        btnreject.Visible = false;
                    }
                }
                else
                {
                    
                    btnapprove.Visible = false;
                    btnreject.Visible = false;
                }
            }



        }
        catch (Exception ex)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }
        }
        finally
        {

        }

    }
    
    private void PopulateData()
    {
        try
        {
            if (HiddenField1.Value != "")
            {
                EventId = Convert.ToInt32(HiddenField1.Value);
            }
            DataSet ds = null;
            DataSet ds1 = null;

            

            ds = objClass1_BL.IRIS_GET_EVENT_DETAILS(EventId, Eventtype);
            if (ds.Tables[0].Rows.Count > 0)
            {
                divrequestid.Visible = true;
                HiddenField1.Value = ds.Tables[0].Rows[0]["EVENT_ID"].ToString();
                HiddenField2.Value = ds.Tables[0].Rows[0]["EMP_ID"].ToString();
                lbl_status.Text = ds.Tables[0].Rows[0]["EVENT_STATUS"].ToString();
                idea_id.Text = ds.Tables[0].Rows[0]["EVENT_ID"].ToString();

                ddleventtype.SelectedItem.Text = ds.Tables[0].Rows[0]["EVENT_TYPE"].ToString();
                txtContent.Text = ds.Tables[0].Rows[0]["EVENT_DESCRIPTION"].ToString();
                ddlspace.SelectedItem.Text= ds.Tables[0].Rows[0]["EVENT_SPACE"].ToString();
                txtStartDate.Text= ds.Tables[0].Rows[0]["EVENT_START_DATE"].ToString();
                txtEndDate.Text= ds.Tables[0].Rows[0]["EVENT_END_DATE"].ToString();
                txtparticipants.Text= ds.Tables[0].Rows[0]["PARTICIPANTS"].ToString();
                //lstBoxTest.SelectedItem.Text = ds.Tables[0].Rows[0]["EVENT_ACCESSORY"].ToString();
                lstBoxTest.Items.Add(ds.Tables[0].Rows[0]["EVENT_ACCESSORY"].ToString());
                lstBoxTest.Visible = false;
                txtaccessoryitem.Text = ds.Tables[0].Rows[0]["EVENT_ACCESSORY"].ToString();
                txtaccessoryitem.Visible = true;
                txtaccessoryitem.Enabled = false;
                Session["EmpId"] = ds.Tables[0].Rows[0]["EMP_ID"].ToString();
                string EmployeeEmail = ds.Tables[0].Rows[0]["EMP_ID"].ToString();
                controldisable();
                string EventStatus = ds.Tables[0].Rows[0]["EVENT_STATUS"].ToString();
                string signinEmail = Session["UserId"].ToString();                

                if (EventStatus == "602")
                {
                    lbl_status.Text = "Pending";
                    lbl_status.ForeColor = Color.Orange;
                }
                if (EventStatus == "601")
                {
                    lbl_status.Text = "Rejected";
                    lbl_status.ForeColor = Color.Red;
                }
                if (EventStatus == "600") //600 is approved status
                {
                    lbl_status.Text = "Approved";
                    lbl_status.ForeColor = Color.Green;
                    if (signinEmail == EmployeeEmail.Trim())
                    {
                        btnspacerequest.Visible = true;
                    }
                    else
                    {
                        btnspacerequest.Visible = false;
                    }
                    
                                       
                }
                else
                {
                    btnspacerequest.Visible = false;
                }
                ds1 = objClass1_BL.GetBookingSpaceDetails(ds.Tables[0].Rows[0]["EVENT_ID"].ToString());
                if (ds1.Tables[0].Rows.Count > 0)
                {
                    btnspacerequest.Visible = false;
                }




            }
        }
        catch (Exception ex)
        {
            Session["Error"] = ex.ToString();
            Response.Redirect("~/ErrorPage.aspx");
        }
        finally
        {
        }
    }
    public void controldisable()
    {
        ddleventtype.Enabled= false;
        txtContent.Enabled = false;
        ddlspace.Enabled = false;
        txtStartDate.Enabled = false;
        txtEndDate.Enabled = false;
        txtparticipants.Enabled = false;
        lstBoxTest.Enabled = false;
        btnSubmit.Enabled = false;        
        btnSubmit.Visible = false;
    }

    public DateTime[] GetDatesBetween(DateTime startDate, DateTime endDate)
    {
        List<DateTime> allDates = new List<DateTime>();
        for (DateTime date = startDate; date <= endDate; date = date.AddDays(1))
            allDates.Add(date);
        return allDates.ToArray();
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
       
        string strExtension = string.Empty;
        try
        {
            string EventAlreadyExist = "";
            //EventAlreadyExist = objClass1_BL.get_IDEA_NAME1(txtIdeaName.Text, ddlChallenge.SelectedValue);

            if (EventAlreadyExist == "")
            {
                if (ddleventtype.SelectedValue.Trim() == "0")
                {
                    objClass1_BL.AlertBox("Enter Types Of Events.", this);
                    return;
                }
                if (txtContent.Text.Trim() == "")
                {
                    objClass1_BL.AlertBox("Enter Description.", this);
                    return;
                }
                if (ddlspace.SelectedValue.Trim() == "0")
                {
                    objClass1_BL.AlertBox("Please Select Space.", this);
                    return;
                }
                if (txtStartDate.Text.Trim() == "")
                {
                    objClass1_BL.AlertBox("Please Enter Start Date.", this);
                    return;
                }
                if (txtEndDate.Text.Trim() == "")
                {
                    objClass1_BL.AlertBox("Please Enter End Date.", this);
                    return;
                }
                if (txtparticipants.Text.Trim() == "")
                {
                    objClass1_BL.AlertBox("Please Enter No. Of Participants.", this);
                    return;
                }
                //if (ddlaccessory.SelectedItem.Text.Trim() == "0")
                //{
                //    objClass1_BL.AlertBox("Please Enter Accessory Items For Events.", this);
                //    return;
                //}



                string strImagepath = string.Empty;
                if (ddleventtype.SelectedValue == "1")
                {
                    strImagepath = "Event.png";
                }
                if (ddleventtype.SelectedValue == "2")
                {
                    strImagepath = "Event.png";
                }
                if (ddleventtype.SelectedValue == "3")
                {
                    strImagepath = "Event.png";
                }
                if (ddleventtype.SelectedValue == "4")
                {
                    strImagepath = "Event.png";
                }
                if (ddleventtype.SelectedValue == "5")
                {
                    strImagepath = "Event.png";
                }
                if (ddleventtype.SelectedValue == "6")
                {
                    strImagepath = "Event.png";
                }
                string AccessoryItemsList = "";
                foreach (ListItem li in lstBoxTest.Items)
                {
                    if (li.Selected == true)
                    {
                        AccessoryItemsList += li.Text + ",";
                    }
                }

                if (AccessoryItemsList == "")
                {
                    objClass1_BL.AlertBox("Please Select AccessoryItems.", this);
                    return;
                }
               


                string sdate = DateTime.ParseExact(txtStartDate.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture)
                        .ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                string edate = DateTime.ParseExact(txtEndDate.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture)
                        .ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);

                DataSet ds1 = new DataSet();
                string space = "";
                ds1 = objClass1_BL.CHECK_SPACE_ALREADY_BOOKING(sdate, edate, ddlspace.SelectedItem.Text);

                if (ds1.Tables[0].Rows.Count > 0)
                {
                    int count = 0;

                    foreach (DataRow row in ds1.Tables[0].Rows)
                    {
                        DateTime d1, d2, id1, id2;
                        string db_startdate1 = DateTime.ParseExact(ds1.Tables[0].Rows[count]["START_DATE"].ToString(), "dd/MM/yyyy", CultureInfo.InvariantCulture)
                            .ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                        string db_enddate2 = DateTime.ParseExact(ds1.Tables[0].Rows[count]["END_DATE"].ToString(), "dd/MM/yyyy", CultureInfo.InvariantCulture)
                            .ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);

                        string inp_startdate1 = sdate;
                        string inp_enddate1 = edate;


                        d1 = DateTime.ParseExact(db_startdate1, "MM/dd/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                        d2 = DateTime.ParseExact(db_enddate2, "MM/dd/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                        id1 = DateTime.ParseExact(inp_startdate1, "MM/dd/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                        id2 = DateTime.ParseExact(inp_enddate1, "MM/dd/yyyy", System.Globalization.CultureInfo.InvariantCulture);

                        DateTime starting = new DateTime();
                        starting = DateTime.ParseExact(id1.ToString("dd-MM-yyyy"), "dd-MM-yyyy", null);
                        DateTime ending = new DateTime();
                        ending = DateTime.ParseExact(id2.ToString("dd-MM-yyyy"), "dd-MM-yyyy", null);

                        DateTime[] dates = GetDatesBetween(starting, ending).ToArray();
                        if (id1 > d2)// check condition input start date and database end date // insert willk happen??????????
                        {
                            string str = "do not check any condition";
                        }
                        else
                        {
                            if (dates.Length > 0)
                            {
                                objClass1_BL.AlertBox("Space Not available for same date. Please Change the date.", this);
                                return;
                            }
                            //if (id1 == d2) //raise error
                            //{
                            //    objClass1_BL.AlertBox("Space Not available please change the date.", this);
                            //    return;
                            //}

                        }

                        count++;
                    }
                }
               
                string[] paramArray = new string[10];
                paramArray[0] = ddleventtype.SelectedItem.Text;
                paramArray[1] = txtContent.Text;
                paramArray[2] = ddlspace.SelectedItem.Text;
                paramArray[3] = txtStartDate.Text;
                paramArray[4] = txtEndDate.Text;
                paramArray[5] = txtparticipants.Text;
                paramArray[6] = AccessoryItemsList;//ddlaccessory.SelectedItem.Text;
                paramArray[7] = Session["UserId"].ToString();
                paramArray[8] = strImagepath;
                paramArray[9] = "602"; //status 602 for post Events pending



                if (Flag == "Update")
                {
                    //objClass1_BL.updateChallenge(paramArray);
                }
                else
                {
                    int Eventid = objClass1_BL.insertpost_event(paramArray);
                    if (Eventid > 0)
                    {
                        string[] paramArraySpace = new string[9];
                        paramArraySpace[0] = Convert.ToString(Eventid);
                        paramArraySpace[1] = ddleventtype.SelectedItem.Text;
                        paramArraySpace[2] = "Event";
                        paramArraySpace[3] = txtContent.Text;
                        paramArraySpace[4] = txtStartDate.Text;
                        paramArraySpace[5] = txtEndDate.Text;
                        paramArraySpace[6] = ddlspace.SelectedItem.Text;
                        paramArraySpace[7] = txtparticipants.Text;
                        paramArraySpace[8] = "602";
                        int getid = objClass1_BL.INSERT_POST_BOOKING_SPACE(paramArraySpace);

                        try
                        {
                            //string listemail = txtparticipants.Text;
                            //string main_list = listemail.Replace(" ", string.Empty).Replace(",", ";");

                            int ideaId = Eventid;
                            string event_type = ddleventtype.SelectedItem.Text;
                            string event_location = ddlspace.SelectedItem.Text;
                            objClass1_BL.Mail_Submitted_TheMix_Event("","",event_type, event_location,  ideaId, HttpContext.Current.Session["UserId"].ToString(), "It's Official! Your Event is Booked!", "Event_Submission.html", "");

                            string msg = "Your Event has been sent to the admin for approval. You shall be updated about the status via Email.";
                            HttpContext.Current.Session["SuccessMessage"] = msg;
                            HttpContext.Current.Response.Redirect("~/Modules/Message/SuccessMessage.aspx", false);
                            //objClass1_BL.Mail_IdeaSubmitted_TheMix(Eventid, HttpContext.Current.Session["UserId"].ToString(), "TheMix : Your Event is submitted!", "Event_Submission.html");

                        }
                        catch (Exception ex)
                        {
                            string msg = "Your Event has been sent to the admin for approval. Email send fail Contract System Admin!.";
                            HttpContext.Current.Session["SuccessMessage"] = msg;
                            HttpContext.Current.Response.Redirect("~/Modules/Message/SuccessMessage.aspx", false);
                        }

                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('Contract System Admin';", true);
                    }

                }

            }
        }
        catch (Exception ex)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }
        }
        finally{ }
    }


    protected void btnCancel_Click(object sender, EventArgs e)
    {
        if (Session["RequestPath"] != null || Convert.ToString(Session["RequestPath"]) != "")
        {
            HttpContext.Current.Session["selectedideaid"] = "";
            HttpContext.Current.Session["selectedideaid"] = null;
            HttpContext.Current.Response.Redirect(Session["RequestPath"].ToString());
        }
        if (Session["postbackurl"] != null || Convert.ToString(Session["postbackurl"]) != "")
        {
            HttpContext.Current.Session["selectedideaid"] = "";
            HttpContext.Current.Session["selectedideaid"] = null;
            HttpContext.Current.Response.Redirect(Session["postbackurl"].ToString());
        }

        if (Session["selectedideaid"] != null || Convert.ToString(Session["selectedideaid"]) != "")
        {
            if (Session["normaluser"] != null || Convert.ToString(Session["normaluser"]) != "")
            {
                HttpContext.Current.Session["selectedideaid"] = "";
                HttpContext.Current.Session["selectedideaid"] = null;
                HttpContext.Current.Response.Redirect("~/Modules/Events/EventHome.aspx");
            }
            else
            {
                HttpContext.Current.Session["selectedideaid"] = "";
                HttpContext.Current.Session["selectedideaid"] = null;
                HttpContext.Current.Response.Redirect("~/Modules/AdminSR/EventDashboard.aspx");
            }

        }
        else
        {
            HttpContext.Current.Session["selectedideaid"] = "";
            HttpContext.Current.Session["selectedideaid"] = null;
            HttpContext.Current.Response.Redirect("~/Modules/Events/EventHome.aspx");
        }
    }

    protected void btnspacerequest_Click(object sender, EventArgs e)
    {
        //Session["RequestSpaceId"] = EventId;        
        HttpContext.Current.Response.Redirect("~/Modules/Space/BookingSpace.aspx?ChlId=" + EventId + "");
    }

    protected void btnapprove_Click(object sender, EventArgs e)
    {
        try
        {
            if (HiddenField1.Value != "")
            {
                //updateapproveEvent("600", HiddenField1.Value);
                int geteventid = 0;
                geteventid = objClass1_BL.Update_Event_Status("600", HiddenField1.Value, geteventid);
                if (geteventid > 0)
                {
                    try
                    {

                        string listemail = HttpContext.Current.Session["UserId"].ToString();
                        //string main_list = listemail.Replace(" ", string.Empty).Replace(",", ";");

                        int ideaId = Convert.ToInt32(HiddenField1.Value);
                        string event_type = ddleventtype.SelectedItem.Text;
                        string event_location = ddlspace.SelectedItem.Text;
                       

                        
                        objClass1_BL.Mail_Submitted_TheMix_Event(txtStartDate.Text,txtEndDate.Text, event_type, event_location,ideaId, HiddenField2.Value, "The Mix : Your Event is Approved", "Events_Approval.html", listemail.Trim());
                        
                        HttpContext.Current.Session["SuccessMessage"] = "The Event has been Approved and the Owner will be Informed via Email";
                        HttpContext.Current.Response.Redirect("~/Modules/Message/SuccessMessage.aspx", false);
                    }
                    catch (Exception ex)
                    {
                        HttpContext.Current.Session["SuccessMessage"] = "The Event has been Approved. Email send fail Contract System Admin";
                        HttpContext.Current.Response.Redirect("~/Modules/Message/SuccessMessage.aspx", false);
                    }
                }

            }
        }
        catch(Exception ex)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }
        }
        
    }
    //public void updateapproveEvent(string status, string ideaid)
    //{
    //    try
    //    {     

    //        //objClass1_BL.Update_Event_Status(status, ideaid);            
    //    }
    //    catch (Exception ex)
    //    {

    //    }


    //}

    protected void btnreject_Click(object sender, EventArgs e)
    {
        try
        {
            if (HiddenField1.Value != "")
            {
                //RejectEvent("601", HiddenField1.Value);
                int geteventid = 0;
                geteventid = objClass1_BL.Update_Event_Status("601", HiddenField1.Value, geteventid);
                if (geteventid > 0)
                {
                    try
                    {
                        string listemail = HttpContext.Current.Session["UserId"].ToString();
                        //string main_list = listemail.Replace(" ", string.Empty).Replace(",", ";");

                        int ideaId = Convert.ToInt32(HiddenField1.Value);
                        string event_type = ddleventtype.SelectedItem.Text;
                        string event_location = ddlspace.SelectedItem.Text;
                        objClass1_BL.Mail_Submitted_TheMix_Event(txtStartDate.Text,txtEndDate.Text, event_type, event_location,ideaId, HiddenField2.Value, "The Mix : Your Event is Rejected", "Event_Rejected.html", listemail.Trim());
                        HttpContext.Current.Session["SuccessMessage"] = "The Event has been Rejected and the Owner will be Informed via Email";
                        HttpContext.Current.Response.Redirect("~/Modules/Message/SuccessMessage.aspx", false);
                    }
                    catch (Exception ex)
                    {
                        HttpContext.Current.Session["SuccessMessage"] = "The Event has been Rejected. Email send fail Contract System Admin";
                        HttpContext.Current.Response.Redirect("~/Modules/Message/SuccessMessage.aspx", false);
                    }
                }
                //HttpContext.Current.Session["SuccessMessage"] = "The Event has been Rejected and the Owner will be Informed via Email";            
                //HttpContext.Current.Response.Redirect("~/Modules/Message/SuccessMessage.aspx", false);            
            }
        }
        catch (Exception ex)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }
        }

    }
    //public void RejectEvent(string status, string ideaid)
    //{
    //    try
    //    {
    //        //objClass1_BL.Update_Event_Status(status, ideaid);
    //    }
    //    catch (Exception ex)
    //    {
    //        if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
    //        {
    //            Session["Error"] = Session["Error"] + ex.ToString();
    //        }
    //        else
    //        {
    //            Session["Error"] = ex.ToString();
    //            Response.Redirect("~/ErrorPage.aspx");
    //        }
    //    }

    //}
}