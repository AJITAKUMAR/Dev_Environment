﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
//using System.Data.OracleClient;
using System.Data;
using OraAppBlock;
using BusinessEntity;
using System.Globalization;
using System.Configuration;
using System.Threading;
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;

public partial class HomePage : System.Web.UI.Page
{
    
    BusinessLayer.IRIS_BusinessLayer objClass1_BL = new BusinessLayer.IRIS_BusinessLayer();  
    //string UserId;
    //ResourceManager rm;
    //CultureInfo ci;
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["UserId"] == null || Convert.ToString(Session["UserId"]) == "")
            {
                Response.Redirect("Login.aspx?r=" + CommonFunctions.GetRandomNumber(), false);
            }
        }
        catch(Exception ex) 
        {
            if(!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }
        }
        finally
        {

        }
        getRoles();
        

    }
    public void getRoles()
    {
        try
        {
            //string UserId=string.Empty;
            if (Session["UserId"] == null || Convert.ToString(Session["UserId"]) == "")
            {
                Response.Redirect("~/Login.aspx?r=" + CommonFunctions.GetRandomNumber(), false);
            }
            else
            {
                string UserId = Session["UserId"].ToString();
                string Admin = "";
                if (CommonFunctions.isSuperAdmin1(Session["UserId"].ToString()))
                {
                    Admin = Session["UserId"].ToString();

                }
                else
                {
                    HttpContext.Current.Session["normaluser"] = "NU";
                }
                if (UserId == Admin)
                {
                    btn_dashboard.Visible = true;
                }
                else
                {
                    btn_dashboard.Visible = false;
                }

            }

        }
        catch (Exception ex)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }
        }
        finally
        {

        }

    }
    protected void btn_idea_Click(object sender, EventArgs e)
    {
        HttpContext.Current.Response.Redirect("~/Modules/Ideas/IdeaHome.aspx");
    }
    protected void btn_events_Click(object sender, EventArgs e)
    {
        HttpContext.Current.Response.Redirect("~/Modules/Events/EventHome.aspx");
    }

    protected void btn_challenges_Click(object sender, EventArgs e)
    {
        HttpContext.Current.Response.Redirect("~/Modules/Challenges/ChallengeHome.aspx"); 
    }

    protected void btn_getstarted_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Wayofworking.aspx");
    }
    protected void btn_dashboard_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Modules/AdminSR/IdeaDashBoard.aspx");
    }
}
