﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Modules_AdminSR_SpaceallocationDashboard : System.Web.UI.Page
{
    BusinessLayer.IRIS_BusinessLayer objClass1_BL = new BusinessLayer.IRIS_BusinessLayer();
    string path = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        path = HttpContext.Current.Request.Url.AbsolutePath;
        try
        {
            
            if (!IsPostBack)
            {
                if (Session["UserId"] == null || Convert.ToString(Session["UserId"]) == "")
                {
                    Response.Redirect("~/Login.aspx?r=" + CommonFunctions.GetRandomNumber(), false);
                }
                grViewIdea.PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["ViewMyIdea_grViewIdea"].ToString());
                BindGrid();
                Session["EarlierPage"] = null;
                Session["PreviousPage"] = null;
            }
        }
        catch (Exception ex)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }
        }
    }

    private void BindGrid()
    {
        try
        {
            string[] paramarray = new string[2];
            paramarray[0] = "";

            DataSet ds = objClass1_BL.IRIS_GET_ACTIVITY_DETAILS(paramarray);
            //string Empid = "";//Session["UserId"].ToString();
            //DataSet ds = objClass1_BL.IRIS_GET_IDEAS_BY_FILTER_21(Empid);
            //DataSet ds = objClass1_BL.IRIS_GET_DASHBOARD(Empid);
            grViewIdea.DataSource = ds.Tables[0];
            grViewIdea.DataBind();


        }
        catch (Exception ex)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }

        }
        finally
        {
        }

    }



    protected void grViewIdea_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grViewIdea.PageIndex = e.NewPageIndex;
        BindGrid();
    }


    protected void grViewIdea_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        Session["selectedideaid"] = "";
        Session["RequestSpaceId"] = "";
        Session["RequestSpacebookingId"] = "";
        Session["selectedideaid"] = null;
        Session["RequestSpaceId"] = null;
        Session["RequestSpacebookingId"] = null;
        int rowIndexId = Convert.ToInt32(e.CommandArgument);
        if (e.CommandName == "Select")
        {            
            Session["postbackurl"] = path;
            HttpContext.Current.Session["RequestSpacebookingId"] = rowIndexId;
            Response.Redirect("~/Modules/Space/BookingSpaceApprove.aspx");
        }
        else if (e.CommandName == "SpaceRequest")
        {
            HttpContext.Current.Session["RequestSpaceId"] = rowIndexId;
            HttpContext.Current.Session["Admin"] = "A";
            Response.Redirect("~/Modules/Space/BookingSpace.aspx");
        }

    }
    protected void grViewIdea_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                LinkButton lblstr = (LinkButton)e.Row.FindControl("lnkSTSTUS");
                string statustext = ((LinkButton)(e.Row.Cells[5].FindControl("lnkSTSTUS"))).Text;

                //LinkButton lnkspacerequestid = (LinkButton)e.Row.FindControl("lblSB_ID");


                if (statustext == "600")
                {
                    lblstr.Text = "Space Allocated";
                    //e.Row.Cells[7].BackColor = Color.Green;
                    //e.Row.Cells[7].ForeColor = Color.Green;
                    lblstr.Enabled = false;
                    lblstr.ForeColor = Color.Green;
                    //lnkspacerequestid.Visible = true;
                }
                else if (statustext == "601")
                {
                    lblstr.Text = "Space Rejected";
                    //e.Row.Cells[7].BackColor = Color.Red;
                    //e.Row.Cells[7].ForeColor = Color.Red;
                    lblstr.Enabled = false;
                    lblstr.ForeColor = Color.Red;
                    //lnkspacerequestid.Enabled = false;
                    //lnkspacerequestid.Text = "NA";
                }
                else if (statustext == "602")
                {
                    lblstr.Text = "Approval Pending";
                    //e.Row.Cells[7].BackColor = Color.Orange;
                    e.Row.Cells[7].ForeColor = Color.Blue;
                    lblstr.Enabled = true;
                    lblstr.ForeColor = Color.Blue;

                    //lnkspacerequestid.Enabled = false;
                    //lnkspacerequestid.Text = "NA";
                }
                else
                {
                    //e.Row.Cells[7].BackColor = Color.Orange;
                    //e.Row.Cells[7].ForeColor = Color.White;
                    //lnkspacerequestid.Visible = false;
                    //lnkspacerequestid.Text = "NA";
                }


            }
        }
        catch (Exception ex)
        {
            Session["Error"] = ex.ToString();
            Response.Redirect("~/ErrorPage.aspx");
        }
    }

    
}