﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OracleClient;
using System.Data;
using OraAppBlock;
using System.Collections;
using System.Configuration;
using System.Drawing;
using System.IO;

public partial class Modules_Ideas_ViewMyIdeas : System.Web.UI.Page
{
    
    BusinessLayer.IRIS_BusinessLayer objClass1_BL = new BusinessLayer.IRIS_BusinessLayer();

    string path = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            path = HttpContext.Current.Request.Url.AbsolutePath;
            if (!IsPostBack)
            {
                if (Session["UserId"] == null || Convert.ToString(Session["UserId"]) == "")
                {
                    Response.Redirect("~/Login.aspx?r=" + CommonFunctions.GetRandomNumber(), false);
                }
                grViewIdea.PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["ViewMyIdea_grViewIdea"].ToString());
                BindGrid();
                Session["EarlierPage"] = null;
                Session["PreviousPage"] = null;
            }
        }
        catch (Exception ex)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }
        }

    }

   
    private void BindGrid()
    {
        try
        {

            string Empid = Session["UserId"].ToString();            
            DataSet ds = objClass1_BL.IRIS_GET_IDEAS_BY_FILTER_21(Empid);
            grViewIdea.DataSource = ds.Tables[0];
            grViewIdea.DataBind();

          
        }
        catch (Exception ex)
        {
            Session["Error"] = ex.ToString();
            Response.Redirect("~/ErrorPage.aspx");
        }
        finally
        {
        }

    }



    protected void grViewIdea_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grViewIdea.PageIndex = e.NewPageIndex;
        BindGrid();
    }


    protected void grViewIdea_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        Session["selectedideaid"] = "";
        Session["RequestSpaceId"] = "";
        Session["selectedideaid"] = null;
        Session["RequestSpaceId"] = null;
        HttpContext.Current.Session["postbackurl"] = "";
        HttpContext.Current.Session["postbackurl"] = null;
        int rowIndexId = Convert.ToInt32(e.CommandArgument);
        if (e.CommandName == "Select")
        {            
            //int rowIndexId = Convert.ToInt32(e.CommandArgument);
            HttpContext.Current.Session["selectedideaid"] = rowIndexId;
            HttpContext.Current.Session["postbackurl"] = path;
            Response.Redirect("~/Modules/Ideas/PostIdea.aspx");
        }
        else if(e.CommandName == "SpaceRequest")
        {
            HttpContext.Current.Session["postbackurl"] = path;
            HttpContext.Current.Session["RequestSpaceId"] = rowIndexId;
            Response.Redirect("~/Modules/Space/BookingSpace.aspx?ChlId=" + rowIndexId + "");
        }

    }
    protected void grViewIdea_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                Label lblstr = (Label)e.Row.FindControl("lblStatus");
                string statustext = ((Label)(e.Row.Cells[4].FindControl("lblStatus"))).Text;

                Label lblact = (Label)e.Row.FindControl("lblactivity");
                string activityid = ((Label)(e.Row.Cells[6].FindControl("lblactivity"))).Text;

                LinkButton lnkspacerequestid = (LinkButton)e.Row.FindControl("lnkspacerequestid");

                if (activityid == "")
                {

                }
                else
                {
                    e.Row.Cells[7].Text = "Approval Pending";
                    e.Row.Cells[7].ForeColor = Color.Green;
                }
                

                if (statustext == "Approved")
                {
                    e.Row.Cells[6].BackColor = Color.Green;
                    e.Row.Cells[6].ForeColor = Color.White;
                    lnkspacerequestid.Visible = true;
                }
                else if (statustext == "Pending")
                {
                    e.Row.Cells[6].BackColor = Color.Orange;
                    e.Row.Cells[6].ForeColor = Color.White;
                    lnkspacerequestid.Enabled = false;
                    lnkspacerequestid.Text = "NA";
                }
                else if (statustext == "Rejected")
                {
                    e.Row.Cells[6].BackColor = Color.Red;
                    e.Row.Cells[6].ForeColor = Color.White;
                    lnkspacerequestid.Enabled = false;
                    lnkspacerequestid.Text = "NA";
                }
                else
                {
                    e.Row.Cells[6].BackColor = Color.Orange;
                    e.Row.Cells[6].ForeColor = Color.White;
                    lnkspacerequestid.Visible = false;
                    lnkspacerequestid.Text = "NA";
                }


            }
        }
        catch (Exception ex)
        {
            Session["Error"] = ex.ToString();
            Response.Redirect("~/ErrorPage.aspx");
        }
    }

    protected void btn_back_Click(object sender, EventArgs e)
    {
        //HttpContext.Current.Session["RequestPath"] = "";
        //HttpContext.Current.Session["RequestPath"] = null;
        //Session["selectedideaid"] = "";
        //Session["selectedideaid"] = null;
        //Session["postbackurl"] = "";
        //Session["postbackurl"] = null;
        Response.Redirect("~/Modules/Ideas/IdeaHome.aspx");
    }


}