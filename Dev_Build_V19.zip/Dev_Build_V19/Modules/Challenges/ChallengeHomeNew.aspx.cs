﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Modules_Challenges_ChallengeHomeNew : System.Web.UI.Page
{
    BusinessLayer.IRIS_BusinessLayer objClass1_BL = new BusinessLayer.IRIS_BusinessLayer();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserId"] == null || Convert.ToString(Session["UserId"]) == "")
        {
            Response.Redirect("~/Login.aspx?r=" + CommonFunctions.GetRandomNumber(), false);
        }
        if(!IsPostBack)
        {
            getRoles();
        }
    }

    public void getRoles()
    {
        try
        {
            string UserId = "";
            string Admin = "";
            if (Session["UserId"] == null || Convert.ToString(Session["UserId"]) == "")
            {
                Response.Redirect("~/Login.aspx?r=" + CommonFunctions.GetRandomNumber(), false);
            }
            else
            {
                UserId = Session["UserId"].ToString();
            }

            if (CommonFunctions.isSuperAdmin1(Session["UserId"].ToString()))
            {
                Admin = Session["UserId"].ToString();
            }

        }
        catch (Exception ex) 
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }
        }
        finally
        {

        }
        
    }
    public void AddDynamicDivs()
    {       
        try
        {            
            string status = "A";
            DataSet ds = objClass1_BL.IRIS_GET_CHALLENGE_DASHBOARD(status);            
            if (ds.Tables.Count > 0)
            {
                if (ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        string challengeName = string.Empty;
                        string challengeImage = string.Empty;

                        challengeName = Regex.Replace(row["CHALLENGE_TITLE"].ToString(), "<.*?>", string.Empty);
                        if (challengeName.Length < 200)
                        {
                            //challengeName = challengeName.PadRight(200 - challengeName.Length);
                            //challengeName=challengeName+new string(' ', 200 - challengeName.Length);
                            challengeName = challengeName + new string(' ', 1);
                            int i = 200 - challengeName.Length;
                            while (i > 0)
                            {
                                //challengeName = challengeName + "&nbsp;";
                                challengeName = challengeName + "";
                                i--;
                            }
                        }
                        if (!string.IsNullOrEmpty(row["CHALLENGE_IMAGE"].ToString()))
                        {
                            challengeImage = row["CHALLENGE_IMAGE"].ToString();
                        }
                        else
                        {
                            challengeImage = "IRIS_Innovation_1.png";
                        }
                        Response.Write("<div style='margin:10px 0px 0px 10px; text-align:center; width:24%; display:inline-block; vertical-align: top; overflow-wrap: break-word; word-wrap:break-word;' class='challenge-card'>");
                        Response.Write("<a href='../../modules/challenges/PostChallengeNew.aspx?ChlId=" + row["CHALLENGE_ID"].ToString() + "'>");
                        //Response.Write("<div style='height:264px;'>");
                        Response.Write("<img style='width:120px;'  src='../../images/icons/" + challengeImage + "'/><br />");
                        Response.Write("<span style='color:var(--McCain-Grey, #3B393D);text-align: justify;font-size: 24px;font-style: normal;font-weight: 900;line-height: normal;'>" + challengeName + "</span><br />");
                        //Response.Write("<span style='color:var(--McCain-Grey, #3B393D);text-align: justify;font-size: 12px;font-style: normal;font-weight: 900;line-height: normal;'>Subtitles lorem ipsem  lorem ipsem</span><br />");
                        Response.Write("<div style='position: relative;width: 12vh;border-radius: 0.5vh;justify-content: center;align-items: center;border: 1.341px solid var(--Primary-60, #0F62FE);background: var(--Primary-60, #0F62FE);'><a style='color:#FFF;' href='../../modules/challenges/PostChallengeNew.aspx?ChlId=" + row["CHALLENGE_ID"].ToString() + "'>Active"); 
                        Response.Write("</a></div>");
                        Response.Write("</a>");
                        Response.Write("</div>");
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Session["Error"] = ex.ToString();
            Response.Redirect("~/ErrorPage.aspx");
        }
    }

    protected void btn_back_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Modules/Challenges/ChallengeHome.aspx");
    }
}