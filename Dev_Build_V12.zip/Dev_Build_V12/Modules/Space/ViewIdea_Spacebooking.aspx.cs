﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Modules_Space_ViewIdea_Spacebooking : System.Web.UI.Page
{
    string IdeaId = ""; // change ideaid ="2"
    
    BusinessLayer.IRIS_BusinessLayer objClass1_BL = new BusinessLayer.IRIS_BusinessLayer();
    protected void Page_Load(object sender, EventArgs e)
    {
        Session["UserId"] = "ajit.rath075@gmail.com";
        try
        {
            //IdeaId = Regex.Replace(Request.QueryString["IdeaId"].ToString().Trim(), "[^ 0-9a-zA-Z]", "");
            if (!IsPostBack)
            {
                grViewIdea.PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["ViewMyIdea_grViewIdea"].ToString());
                BindGrid();
            }
        }
        catch (Exception ex) 
        {
            Session["Error"] = ex.ToString();
            Response.Redirect("~/ErrorPage.aspx");
        }
        finally
        {

        }
        

    }

    protected void ddlChallenge_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindGrid();
    }
    private void BindGrid()
    {
        try
        {
            string[] paramarray = new string[2];
            paramarray[0] = Session["UserId"].ToString();
            paramarray[1] = "602";//600 is approved status code
            //paramarray[2] = "Y";
            //paramarray[3] = "N";

            //if (CommonFunctions.isSuperAdmin1(Session["UserId"].ToString()))
            //{
            //    paramarray[3] = "Y";
            //}

            //if (!string.IsNullOrEmpty(Convert.ToString(Session["User_Type"])))
            //{
            //    paramarray[4] = Session["User_Type"].ToString();
            //}

            //else
            //{
            //    paramarray[4] = "";
            //}
            //paramarray[5] = "";
            
            DataSet ds = objClass1_BL.IRIS_GET_APPROVE_IDEA(paramarray);
            grViewIdea.DataSource = ds.Tables[0];
            grViewIdea.DataBind();

            
        }
        catch (Exception ex)
        {
            Session["Error"] = ex.ToString();
            Response.Redirect("~/ErrorPage.aspx");
        }
        finally
        {
        }
    }
    protected void grViewIdea_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                LinkButton lnkbtn = (LinkButton)e.Row.FindControl("lblIdeaId");
                IdeaId = ((LinkButton)(e.Row.Cells[0].FindControl("lblIdeaId"))).Text;
                string url = "~/Modules/Space/BookingSpace.aspx?IdeaId=" + IdeaId;
                lnkbtn.PostBackUrl = url;
                //
                //LinkButton lnkbtn_space = (LinkButton)e.Row.FindControl("lnkbtn_space");
                //IdeaId = ((LinkButton)(e.Row.Cells[0].FindControl("lblIdeaId"))).Text;
                //string url = "~/Modules/Space/BookingSpace.aspx?IdeaId=" + IdeaId;
            }
        }
        catch (Exception ex)
        {
            Session["Error"] = ex.ToString();
            Response.Redirect("~/ErrorPage.aspx");
        }
    }
    protected void grViewIdea_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grViewIdea.PageIndex = e.NewPageIndex;
        BindGrid();
    }
}