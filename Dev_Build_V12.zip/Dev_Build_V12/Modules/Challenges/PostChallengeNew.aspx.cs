﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

public partial class Modules_Challenges_PostChallengeNew : System.Web.UI.Page
{
    BusinessLayer.IRIS_BusinessLayer objClass1_BL = new BusinessLayer.IRIS_BusinessLayer();
    string challengeid = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                if (Session["UserId"] == null || Convert.ToString(Session["UserId"]) == "")
                {
                    Response.Redirect("~/Login.aspx?r=" + CommonFunctions.GetRandomNumber(), false);
                }
                if ((Request.QueryString["ChlId"] != null))
                {
                    challengeid = Request.QueryString["ChlId"].ToString();
                }
                if (HttpContext.Current.Session["selectedideaid"] != null)
                {
                    btn_submit.Visible = false;
                    challengeid = Session["selectedideaid"].ToString();                
                }
                LoadSingleIdea();
            }


        }
        catch (Exception ex)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }
        }
        finally
        {
        }
    }

    public void LoadSingleIdea()
    {
        try
        {
            if (challengeid != "")
            {
                DataSet challengeds = objClass1_BL.IRIS_GET_CHALLENGE_DASHBOARD(challengeid);
                DataTable dt = challengeds.Tables[0];
                if (dt.Rows.Count > 0)
                {
                    //HiddenField1.Value = dt.Rows[0]["IDEA_ID"].ToString();
                    txtchallengetitle.Text = dt.Rows[0]["CHALLENGE_TITLE"].ToString();
                    //txtdomain.Text = dt.Rows[0]["DOMAIN"].ToString();
                    ddlpurpose.SelectedItem.Text = dt.Rows[0]["DOMAIN"].ToString();
                    txtDescrptn.Text = dt.Rows[0]["DESCRIPTION"].ToString();
                    chkAudience.SelectedValue = dt.Rows[0]["TARGET_AUDIENCE"].ToString();
                    txtstartdate.Text = dt.Rows[0]["START_DATE"].ToString();
                    txtEnddate.Text = dt.Rows[0]["END_DATE"].ToString();
                    //txtpurpose.Text = dt.Rows[0]["STATUS"].ToString();                
                    txtEnddate.Text = dt.Rows[0]["END_DATE"].ToString();
                    clotroldisable();
                }
            }
            
            
        }
        catch (Exception ex)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }
        }
        finally
        {

        }
    }
    public void clotroldisable()
    {
        //HiddenField1.Value = dt.Rows[0]["IDEA_ID"].ToString();
        txtchallengetitle.Enabled = false;
        ddlpurpose.Enabled = false;
        txtDescrptn.Enabled = false;
        chkAudience.Enabled = false;
        txtstartdate.Enabled = false;
        txtEnddate.Enabled = false;
        //txtpurpose.Text = dt.Rows[0]["STATUS"].ToString();                
        txtEnddate.Enabled = false;
        
        
    }

    protected void btn_submit_Click(object sender, EventArgs e)
	{

        string strExtension = string.Empty;
        try
        {
            string EventAlreadyExist = "";
            //EventAlreadyExist = objClass1_BL.get_IDEA_NAME1(txtIdeaName.Text, ddlChallenge.SelectedValue);

            if (EventAlreadyExist == "")
            {
                if (txtchallengetitle.Text.Trim() == "")
                {
                    objClass1_BL.AlertBox("Enter Challenge Title.", this);
                    return;
                }

                string strImagepath = string.Empty;
                if (chkAudience.SelectedValue == "Internal")
                {
                    strImagepath = "IRIS_Finance_1.jpg";
                }
                if (chkAudience.SelectedValue == "External")
                {
                    strImagepath = "IRIS_mobility.jpg";
                }
                if (chkAudience.SelectedValue == "Both")
                {
                    strImagepath = "IRIS_Innovation_1.jpg";
                }

                string[] paramArray = new string[9];
                paramArray[0] = txtchallengetitle.Text;
                //paramArray[1] = txtdomain.Text;
                paramArray[1] = ddlpurpose.SelectedItem.Text;
                paramArray[2] = txtDescrptn.Text;
                paramArray[3] = chkAudience.SelectedItem.Text;
                paramArray[4] = txtstartdate.Text;
                paramArray[5] = txtEnddate.Text;
                paramArray[6] = "602";
                paramArray[7] = strImagepath;

                //paramArray[7] = Session["EmpId"].ToString();
                int id = objClass1_BL.insertpost_challenge(paramArray);
                if (id > 0)
                {
                    HttpContext.Current.Session["SuccessMessage"] = "Your Challenge has been Submitted. Status Updated via Email.";
                    // "Your Challenge has been Submitted. You shall be updated about the status via mail.";
                    HttpContext.Current.Response.Redirect("~/Modules/Message/SuccessMessage.aspx", false);
                    //ScriptManager.RegisterStartupScript(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('Your Idea has been sent to admin for approval,You shall be informed about approval status via mail'); location.href='PostEvents.aspx';", true);
                    //btn_submit.Enabled = false;
                    //btn_cancel.Enabled = false;
                }
                else
                {
                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('Contract System Admin';", true);
                }



            }
        }
        catch (Exception ex)
        {
            strExtension = ex.Message;
            Session["Error"] = ex.ToString();
            Response.Redirect("~/ErrorPage.aspx");
        }
        finally
        {


        }


    }

    protected void btn_cancel_Click(object sender, EventArgs e)
    {
        HttpContext.Current.Response.Redirect("~/Modules/Challenges/ChallengeHome.aspx");
    }
}