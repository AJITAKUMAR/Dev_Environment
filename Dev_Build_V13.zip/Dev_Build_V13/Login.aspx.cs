﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Web.Security;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using BusinessLayer;
using BusinessEntity;
using System.Text;
using System.DirectoryServices;
using System.Text.RegularExpressions;
using System.Data.OracleClient;
using OraAppBlock;
using System.IO;
using System.Net.Mail;
using System.Net.Mime;
using System.Net.NetworkInformation;



public partial class Login : System.Web.UI.Page
{
    //Start - 13th Nov  2017 - Bhakti
    BusinessLayer.IRIS_BusinessLayer objClass1_BL = new BusinessLayer.IRIS_BusinessLayer();
    //End - 13th Nov 2017 - Bhakti

    string UserId;
    protected void Page_Load(object sender, EventArgs e)    
    {

        //if (!Request.IsAuthenticated)
        //{
        //    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
        //    HttpContext.Current.GetOwinContext().Authentication.Challenge(
        //    new AuthenticationProperties { RedirectUri = "~/Login.aspx" },
        //    OpenIdConnectAuthenticationDefaults.AuthenticationType);
        //}
        //else
        //{
        //    Loginauthenticate();
        //}



        if (Page.Request.QueryString.AllKeys.Length > 0)
        {
            if (Request.QueryString["r"] == null)
            {
                string EmpID = string.Empty; // Variable defined to store PS returned output
                string AppName = string.Empty; // Variable defined to store Application Name
                string ID = string.Empty; // Query String
                try
                {
                    ID = Page.Request.QueryString["ID"].ToString(); //Retrieve the query string

                    string strID = Page.Request.QueryString["ID"].ToString();
                    SSOServiceNew.Service objSSO = new SSOServiceNew.Service();
                    objSSO.Url = ConfigurationManager.AppSettings["SSOServiceNew.Service"].ToString();
                    string[] ReturnInsertID = objSSO.GetEmployeeCode(strID);                    

                    Session["UserName"] = ReturnInsertID[1].Trim().ToString();
                    if (objClass1_BL.getEmpID(ReturnInsertID[0].Trim(), objClass1_BL.getUser_Type(off.Text)) != "0")
                    {
                        if (Session["UserId"] != null)                        {
                            
                            Session["LanID"] = ReturnInsertID[2].Trim();//added by np00365439
                           
                            objClass1_BL.IMRedirect();                            

                            Response.Redirect("HomePage.aspx?r=" + CommonFunctions.GetRandomNumber(), false);
                        }
                        else
                        {
                            Errr.Text = "Sorry you don't have access to the portal. Contact Legal team if access is required.";
                            Errr.Visible = true;
                        }
                    }
                    else
                    {
                        Errr.Text = "Sorry you don't have access to the portal. Contact Legal team if access is required.";
                        Errr.Visible = true;
                    }

                }

                catch (Exception ex)
                {
                    Errr.Visible = true;
                    Errr.Text = "Authentication failed. Please try later.";
                }
            }
            else
            {
                off.Focus();
            }
        }
        else
        {            
            off.Focus();
        }
    }
    //public void Loginauthenticate()
    //{
    //    ClaimsIdentity identity = this.User.Identity as ClaimsIdentity; string empid = identity.Claims.FirstOrDefault(x => x.Type == "Emp ID").Value;
    //    Session["UserId"] = empid;   

    //}

    protected void went_for(object sender, EventArgs e)
    {
        Errr.Visible = false;
        string[] Result = new string[5]; 
        try
        {
            Session["LanID"] = off.Text.Trim();//added by np00365439
            if (ConfigurationManager.AppSettings["Web_Config"].ToString().Equals("Yes"))
            {
                string flagUserType = string.Empty;
                if (off.Text.Contains('@'))
                {
                    string[] Arr = off.Text.Split('@');
                    string[] CheckEmailID = Arr[1].Split('.');
                    string[] domains = ConfigurationManager.AppSettings["EmailDomain"].ToString().Split(',');
                   
                    foreach (string str in domains)
                    {
                        if (CheckEmailID[0].ToString().ToUpper().Equals(str))
                        {
                            flagUserType = "DomainUser";
                            Session["User_Type"] = "";                            
                            break;
                        }
                    }
                    if (string.IsNullOrEmpty(flagUserType))
                    {
                        DataSet ds = new DataSet();                        
                        ds = objClass1_BL.AuthenticateUser1(off.Text.Trim());
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            Session["User_Type"] = "";
                        }
                        else
                        {
                            Session["User_Type"] = "UNIVERSITY";
                        }
                            
                    }
                }
                else
                {
                    Session["User_Type"] = "";
                }               

                if (string.IsNullOrEmpty(Convert.ToString(Session["User_Type"])))
                {                    
                    //AuthService.Service objAuthService = new AuthService.Service();
                    //objAuthService.Url = System.Configuration.ConfigurationManager.AppSettings["AuthService.service"].ToString();
                    //Result = objAuthService.LDAP_Authenticate(off.Text.Trim(), onn.Text.Trim());

                    //======Remove this code put LDAP Login is success 
                    string Admin = "";
                    if (CommonFunctions.isSuperAdmin1(off.Text.Trim())) //FOR ADMIN ROLE
                    {
                        if (onn.Text == "denish**123")
                        {
                            Result[0] = off.Text; //"ajit.rath075@mccain.co";
                            Result[1] = "denish";
                        }
                        else if(onn.Text == "samantha321123")
                        {
                            Result[0] = off.Text; //"ajit.rath075@mccain.co";
                            Result[1] = "samantha";
                        }
                        else if (onn.Text == "oleg987789")
                        {
                            Result[0] = off.Text; //"ajit.rath075@mccain.co";
                            Result[1] = "oleg";
                        }
                        else if (onn.Text == "ajit..123")
                        {
                            Result[0] = off.Text; //"ajit.rath075@mccain.co";
                            Result[1] = "Ajita";
                        }
                        else
                        {
                            Result[0] = "ERROR";
                        }

                    }
                    else  //FOR USER ROLE
                    {
                        if (off.Text == "denish@mccain.ca" && onn.Text == "denish**123")
                        {
                            Result[0] = off.Text;
                            Result[1] = "denish";
                        }
                        else if (off.Text == "samantha@mccain.ca" && onn.Text == "samantha321123")
                        {
                            Result[0] = off.Text; //"ajit.rath075@mccain.co";
                            Result[1] = "samantha";
                        }
                        else if (off.Text == "oleg@mccain.ca" && onn.Text == "oleg987789")
                        {
                            Result[0] = off.Text; //"ajit.rath075@mccain.co";
                            Result[1] = "oleg";
                        }
                        else if (off.Text == "ajit@mccain.ca" && onn.Text == "ajit..123")
                        {
                            Result[0] = off.Text; //"ajit.rath075@mccain.co";
                            Result[1] = "Ajita";
                        }
                        else if (off.Text == "alyssa.brown@mccain.ca" && onn.Text == "alyssa#123")
                        {
                            Result[0] = off.Text; //"ajit.rath075@mccain.co";
                            Result[1] = "alyssa";
                        }
                        else if (off.Text == "sandra.nunes@mccain.ca" && onn.Text == "sandra#123")
                        {
                            Result[0] = off.Text; //"ajit.rath075@mccain.co";
                            Result[1] = "sandra";
                        }
                        else if (off.Text == "jess.hovey@mccain.ca" && onn.Text == "jess#123")
                        {
                            Result[0] = off.Text; //"ajit.rath075@mccain.co";
                            Result[1] = "jess";
                        }
                        else if (off.Text == "claire.fieldhouse@mccain.co.uk" && onn.Text == "claire#123")
                        {
                            Result[0] = off.Text; //"ajit.rath075@mccain.co";
                            Result[1] = "claire";
                        }
                        else if (off.Text == "jane.duffy@mccain.ca" && onn.Text == "jane#123")
                        {
                            Result[0] = off.Text; //"ajit.rath075@mccain.co";
                            Result[1] = "jane";
                        }
                        else if (off.Text == "hadeel.alsayyed@mccain.ca" && onn.Text == "hadeel#123")
                        {
                            Result[0] = off.Text; //"ajit.rath075@mccain.co";
                            Result[1] = "hadeel";
                        }
                        else
                        {
                            Result[0] = "ERROR";
                        }


                        //Result[0] = off.Text;// "ajit.rath@mccain.co";
                        //Result[1] = "Ajita Kumar";
                    }
                    //======Remove this code put LDAP Login is success
                    
                    
                    Result[2] = "";
                    Result[3] = "";
                    Result[4] = "";


                    if (Result[0].Trim().ToUpper() == "ERROR")
                    {
                        Errr.Text = "Invalid LAN ID Or Password";

                        Errr.Visible = true;

                        onn.Text = string.Empty;

                        onn.Focus();
                        Session.Abandon();
                        Session.RemoveAll();
                        Response.Cache.SetCacheability(HttpCacheability.NoCache);
                        Response.Cache.SetExpires(System.DateTime.Now.AddSeconds(-1));
                        Response.Cache.SetNoStore();
                        Response.AddHeader("Pragma", "no-cache");
                    }
                    else
                    {
                        Session["UserName"] = Result[1].ToString();
                        Session["UserId"] = Result[0].ToString();
                        


                        if (Session["UserId"] != null)
                        {
                            if (Session["UserId"] != null)
                            { 
                                if (onn.Text.Trim() != "")
                                {
                                    Response.Redirect("HomePage.aspx?r=" + CommonFunctions.GetRandomNumber(), false);
                                }
                                else
                                {
                                    Errr.Visible = true;
                                    Errr.Text = "Authentication failed. Please try later.";
                                }
                            }
                            else
                            {
                                Errr.Text = "Sorry you don't have access to the portal. Contact Legal team if access is required.";
                                Errr.Visible = true;
                            }
                        }
                        else
                        {
                            Errr.Text = "Sorry you don't have access to the portal. Contact Legal team if access is required.";
                            Errr.Visible = true;
                        }
                    }
                }
                else
                {
                    Errr.Visible = true;
                    Errr.Text = "Please enter valid password.";                    
                }
            }
            else
            {
                Errr.Visible = true;
                Errr.Text = "Sorry you don't have access to the portal. Contact IRIS team if access is required.";

            }
        }
        catch (Exception ex)
        {
            Errr.Visible = true;
            Errr.Text = "Authentication failed. Please try later.";
        }
    }

    
}